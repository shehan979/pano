// Garden Gnome Software - Skin
// Pano2VR 7.1.4/20938
// Filename: 3DWiseMedia.ggsk
// Generated 2024-10-09T21:26:08

function pano2vrSkin(player,base) {
	player.addVariable('info', 2, false, { ignoreInState: 1  });
	player.addVariable('opt_3d_preview', 2, true, { ignoreInState: 0  });
	player.addVariable('ht_ani', 2, true, { ignoreInState: 0  });
	player.addVariable('ht_node_var', 2, true, { ignoreInState: 0  });
	player.addVariable('Hotspotbaslik', 2, false, { ignoreInState: 0  });
	player.addVariable('Sosyalmedya', 2, false, { ignoreInState: 0  });
	player.addVariable('infoklasor', 2, false, { ignoreInState: 0  });
	player.addVariable('altmenu', 2, false, { ignoreInState: 0  });
	player.addVariable('menu', 2, false, { ignoreInState: 0  });
	player.addVariable('solmenuklasor', 2, false, { ignoreInState: 0  });
	player.addVariable('solmenu', 2, false, { ignoreInState: 1  });
	player.addVariable('logo_img', 0, "logo150.png", { ignoreInState: 1  });
	player.addVariable('google_map', 0, "", { ignoreInState: 1  });
	player.addVariable('addr', 0, "", { ignoreInState: 1  });
	player.addVariable('tel', 0, "", { ignoreInState: 1  });
	player.addVariable('insta', 0, "", { ignoreInState: 1  });
	player.addVariable('face', 0, "", { ignoreInState: 1  });
	player.addVariable('mail', 0, "", { ignoreInState: 1  });
	player.addVariable('web_site', 0, "", { ignoreInState: 1  });
	player.addVariable('opt_hotspot_preview', 2, true, { ignoreInState: 1  });
	player.addVariable('Hotspotbasli', 2, false, { ignoreInState: 0  });
	var me=this;
	var skin=this;
	var flag=false;
	var hotspotTemplates={};
	var skinKeyPressedKey = 0;
	var skinKeyPressedText = '';
	this.player=player;
	player.setApiVersion(7);
	this.player.skinObj=this;
	this.divSkin=player.divSkin;
	this.ggUserdata=player.userdata;
	this.lastSize={ w: -1,h: -1 };
	var basePath="";
	var cssPrefix="";
	// auto detect base path
	if (base=='?') {
		var scripts = document.getElementsByTagName('script');
		for(var i=0;i<scripts.length;i++) {
			var src=scripts[i].src;
			if (src.indexOf('skin.js')>=0) {
				var p=src.lastIndexOf('/');
				if (p>=0) {
					basePath=src.substr(0,p+1);
				}
			}
		}
	} else
	if (base) {
		basePath=base;
	}
	this.elementMouseDown={};
	this.elementMouseOver={};
	var i;
	var hs,el,els,elo,ela,elHorScrollFg,elHorScrollBg,elVertScrollFg,elVertScrollBg,elCornerBg;
	var prefixes='Webkit,Moz,O,ms,Ms'.split(',');
	for(var i=0;i<prefixes.length;i++) {
		if (typeof document.body.style[prefixes[i] + 'Transform'] !== 'undefined') {
			cssPrefix='-' + prefixes[i].toLowerCase() + '-';
		}
	}
	
	player.setMargins(0,0,0,0);
	
	this.updateSize=function(startElement) {
		var stack=[];
		stack.push(startElement);
		while(stack.length>0) {
			var e=stack.pop();
			if (e.ggUpdatePosition) {
				e.ggUpdatePosition();
			}
			if (e.hasChildNodes()) {
				for(var i=0;i<e.childNodes.length;i++) {
					stack.push(e.childNodes[i]);
				}
			}
		}
	}
	
	player.addListener('changenode', function() { me.ggUserdata=player.userdata; });
	
	var parameterToTransform=function(p) {
		return p.def + 'translate(' + p.rx + 'px,' + p.ry + 'px) rotate(' + p.a + 'deg) scale(' + p.sx + ',' + p.sy + ')';
	}
	
	this.findElements=function(id,regex) {
		var r=[];
		var stack=[];
		var pat=new RegExp(id,'');
		stack.push(me.divSkin);
		while(stack.length>0) {
			var e=stack.pop();
			if (regex) {
				if (pat.test(e.ggId)) r.push(e);
			} else {
				if (e.ggId==id) r.push(e);
			}
			if (e.hasChildNodes()) {
				for(var i=0;i<e.childNodes.length;i++) {
					stack.push(e.childNodes[i]);
				}
			}
		}
		return r;
	}
	
	this._=function(text, params) {
		return player._(text, params);
	}
	
	this.languageChanged=function() {
		var stack=[];
		stack.push(me.divSkin);
		while(stack.length>0) {
			var e=stack.pop();
			if (e.ggUpdateText) {
				e.ggUpdateText();
			}
			if (e.ggUpdateAria) {
				e.ggUpdateAria();
			}
			if (e.hasChildNodes()) {
				for(var i=0;i<e.childNodes.length;i++) {
					stack.push(e.childNodes[i]);
				}
			}
		}
	}
	player.addListener('sizechanged', function () { me.updateSize(me.divSkin);});
	player.addListener('languagechanged', this.languageChanged);
	
	this.addSkin=function() {
		var hs='';
		this.ggCurrentTime=new Date().getTime();
		el=me._node_hareket=document.createElement('div');
		el.ggTimestamp=skin.ggCurrentTime;
		el.ggLastIsActive=true;
		el.ggTimeout=400;
		el.ggId="Node hareket";
		el.ggDx=36;
		el.ggDy=215;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_timer ";
		el.ggType='timer';
		hs ='';
		hs+='height : 32px;';
		hs+='left : calc(50% - ((84px + 0px) / 2) + 36px);';
		hs+='position : absolute;';
		hs+='top : calc(50% - ((32px + 0px) / 2) + 215px);';
		hs+='visibility : inherit;';
		hs+='width : 84px;';
		hs+='pointer-events:none;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me._node_hareket.ggIsActive=function() {
			return (me._node_hareket.ggTimestamp==0 ? false : (Math.floor((skin.ggCurrentTime - me._node_hareket.ggTimestamp) / me._node_hareket.ggTimeout) % 2 == 0));
		}
		el.ggElementNodeId=function() {
			return player.getCurrentNode();
		}
		me._node_hareket.ggActivate=function () {
			player.setVariableValue('ht_ani', true);
		}
		me._node_hareket.ggDeactivate=function () {
			player.setVariableValue('ht_ani', false);
		}
		me._node_hareket.ggUpdatePosition=function (useTransition) {
		}
		me.divSkin.appendChild(me._node_hareket);
		el=me._hedefseim=document.createElement('div');
		el.ggId="HEDEF-SE\xc7\u0130M";
		el.ggDx=0;
		el.ggDy=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_container ";
		el.ggType='container';
		hs ='';
		hs+='cursor : pointer;';
		hs+='height : 20px;';
		hs+='left : calc(50% - ((100px + 0px) / 2) + 0px);';
		hs+='position : absolute;';
		hs+='top : calc(50% - ((20px + 0px) / 2) + 0px);';
		hs+='visibility : inherit;';
		hs+='width : 100px;';
		hs+='pointer-events:none;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me._hedefseim.ggIsActive=function() {
			return false;
		}
		el.ggElementNodeId=function() {
			return player.getCurrentNode();
		}
		me._hedefseim.ggUpdatePosition=function (useTransition) {
		}
		me.divSkin.appendChild(me._hedefseim);
		el=me.__6fullscreen=document.createElement('div');
		el.ggId="6-fullscreen";
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_rectangle ";
		el.ggType='rectangle';
		hs ='';
		hs+='background : #000000;';
		hs+='border : 2px solid #ffffff;';
		hs+='border-radius : 7px;';
		hs+='cursor : pointer;';
		hs+='height : 36px;';
		hs+='position : absolute;';
		hs+='right : 20px;';
		hs+='top : 10px;';
		hs+='visibility : inherit;';
		hs+='width : 36px;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me.__6fullscreen.ggIsActive=function() {
			return false;
		}
		el.ggElementNodeId=function() {
			return player.getCurrentNode();
		}
		me.__6fullscreen.logicBlock_position = function() {
			var newLogicStatePosition;
			if (
				((player.getViewerSize(true).width < 480))
			)
			{
				newLogicStatePosition = 0;
			}
			else {
				newLogicStatePosition = -1;
			}
			if (me.__6fullscreen.ggCurrentLogicStatePosition != newLogicStatePosition) {
				me.__6fullscreen.ggCurrentLogicStatePosition = newLogicStatePosition;
				me.__6fullscreen.style.transition='right 0s, top 0s, transform 200ms ease 0ms, background-color 0s';
				if (me.__6fullscreen.ggCurrentLogicStatePosition == 0) {
					me.__6fullscreen.style.right='8px';
					me.__6fullscreen.style.top='10px';
				}
				else {
					me.__6fullscreen.style.right='20px';
					me.__6fullscreen.style.top='10px';
				}
			}
		}
		me.__6fullscreen.logicBlock_position();
		me.__6fullscreen.logicBlock_scaling = function() {
			var newLogicStateScaling;
			if (
				((me.elementMouseOver['_6fullscreen'] == true))
			)
			{
				newLogicStateScaling = 0;
			}
			else {
				newLogicStateScaling = -1;
			}
			if (me.__6fullscreen.ggCurrentLogicStateScaling != newLogicStateScaling) {
				me.__6fullscreen.ggCurrentLogicStateScaling = newLogicStateScaling;
				me.__6fullscreen.style.transition='right 0s, top 0s, transform 200ms ease 0ms, background-color 0s';
				if (me.__6fullscreen.ggCurrentLogicStateScaling == 0) {
					me.__6fullscreen.ggParameter.sx = 1.1;
					me.__6fullscreen.ggParameter.sy = 1.1;
					me.__6fullscreen.style.transform=parameterToTransform(me.__6fullscreen.ggParameter);
					setTimeout(function() {skin.updateSize(me.__6fullscreen);}, 250);
				}
				else {
					me.__6fullscreen.ggParameter.sx = 1;
					me.__6fullscreen.ggParameter.sy = 1;
					me.__6fullscreen.style.transform=parameterToTransform(me.__6fullscreen.ggParameter);
					setTimeout(function() {skin.updateSize(me.__6fullscreen);}, 250);
				}
			}
		}
		me.__6fullscreen.logicBlock_scaling();
		me.__6fullscreen.logicBlock_backgroundcolor = function() {
			var newLogicStateBackgroundColor;
			if (
				((me.elementMouseOver['_6fullscreen'] == true))
			)
			{
				newLogicStateBackgroundColor = 0;
			}
			else {
				newLogicStateBackgroundColor = -1;
			}
			if (me.__6fullscreen.ggCurrentLogicStateBackgroundColor != newLogicStateBackgroundColor) {
				me.__6fullscreen.ggCurrentLogicStateBackgroundColor = newLogicStateBackgroundColor;
				me.__6fullscreen.style.transition='right 0s, top 0s, transform 200ms ease 0ms, background-color 0s';
				if (me.__6fullscreen.ggCurrentLogicStateBackgroundColor == 0) {
					me.__6fullscreen.style.backgroundColor="rgba(70,65,95,1)";
				}
				else {
					me.__6fullscreen.style.backgroundColor="rgba(0,0,0,1)";
				}
			}
		}
		me.__6fullscreen.logicBlock_backgroundcolor();
		me.__6fullscreen.onclick=function (e) {
			player.setVariableValue('Sosyalmedya', false);
			player.setVariableValue('infoklasor', false);
			player.toggleFullscreen();
			player.setVariableValue('altmenu', false);
			player.setVariableValue('solmenuklasor', false);
		}
		me.__6fullscreen.onmouseenter=function (e) {
			me.elementMouseOver['_6fullscreen']=true;
			me.__6fullscreen.logicBlock_scaling();
			me.__6fullscreen.logicBlock_backgroundcolor();
		}
		me.__6fullscreen.onmouseleave=function (e) {
			me.elementMouseOver['_6fullscreen']=false;
			me.__6fullscreen.logicBlock_scaling();
			me.__6fullscreen.logicBlock_backgroundcolor();
		}
		me.__6fullscreen.ggUpdatePosition=function (useTransition) {
		}
		el=me._fullscreen=document.createElement('div');
		els=me._fullscreen__img=document.createElement('img');
		els.className='ggskin ggskin_svg';
		hs='data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0nMS4wJz8+CjxzdmcgaGVpZ2h0PSI1MTIiIGNsYXNzPSIiIHk9IjAiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDQ2OS4zMzMgNDY5LjMzMyIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgNTEyIDUxMiIgeG1sbnM6c3ZnanM9Imh0dHA6Ly9zdmdqcy5jb20vc3ZnanMiIHdpZHRoPSI1MTIiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjAiPgogPGc+CiAgPGcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3'+
			'ZnIj4KICAgPGc+CiAgICA8Zz4KICAgICA8cGF0aCBkPSJNMTYwLDBIMTAuNjY3QzQuNzcxLDAsMCw0Ljc3MSwwLDEwLjY2N1YxNjBjMCw1Ljg5Niw0Ljc3MSwxMC42NjcsMTAuNjY3LDEwLjY2N0gzMmM1Ljg5NiwwLDEwLjY2Ny00Ljc3MSwxMC42NjctMTAuNjY3ICAgICBWNDIuNjY3SDE2MGM1Ljg5NiwwLDEwLjY2Ny00Ljc3MSwxMC42NjctMTAuNjY3VjEwLjY2N0MxNzAuNjY3LDQuNzcxLDE2NS44OTYsMCwxNjAsMHoiIGRhdGEtb3JpZ2luYWw9IiMwMDAwMDAiIHN0eWxlPSIiIGZpbGw9IiNmZmZmZmYiIGNsYXNzPSIiLz4KICAgICA8cGF0aCBkPSJNNDU4LjY2NywwSDMwOS4zMzNjLTUuODk2'+
			'LDAtMTAuNjY3LDQuNzcxLTEwLjY2NywxMC42NjdWMzJjMCw1Ljg5Niw0Ljc3MSwxMC42NjcsMTAuNjY3LDEwLjY2N2gxMTcuMzMzVjE2MCAgICAgYzAsNS44OTYsNC43NzEsMTAuNjY3LDEwLjY2NywxMC42NjdoMjEuMzMzYzUuODk2LDAsMTAuNjY3LTQuNzcxLDEwLjY2Ny0xMC42NjdWMTAuNjY3QzQ2OS4zMzMsNC43NzEsNDY0LjU2MywwLDQ1OC42NjcsMHoiIGRhdGEtb3JpZ2luYWw9IiMwMDAwMDAiIHN0eWxlPSIiIGZpbGw9IiNmZmZmZmYiIGNsYXNzPSIiLz4KICAgICA8cGF0aCBkPSJNNDU4LjY2NywyOTguNjY3aC0yMS4zMzNjLTUuODk2LDAtMTAuNjY3LDQuNzcxLTEwLjY2NywxMC42Nj'+
			'd2MTE3LjMzM0gzMDkuMzMzYy01Ljg5NiwwLTEwLjY2Nyw0Ljc3MS0xMC42NjcsMTAuNjY3ICAgICB2MjEuMzMzYzAsNS44OTYsNC43NzEsMTAuNjY3LDEwLjY2NywxMC42NjdoMTQ5LjMzM2M1Ljg5NiwwLDEwLjY2Ny00Ljc3MSwxMC42NjctMTAuNjY3VjMwOS4zMzMgICAgIEM0NjkuMzMzLDMwMy40MzcsNDY0LjU2MywyOTguNjY3LDQ1OC42NjcsMjk4LjY2N3oiIGRhdGEtb3JpZ2luYWw9IiMwMDAwMDAiIHN0eWxlPSIiIGZpbGw9IiNmZmZmZmYiIGNsYXNzPSIiLz4KICAgICA8cGF0aCBkPSJNMTYwLDQyNi42NjdINDIuNjY3VjMwOS4zMzNjMC01Ljg5Ni00Ljc3MS0xMC42NjctMTAuNjY3LTEw'+
			'LjY2N0gxMC42NjdDNC43NzEsMjk4LjY2NywwLDMwMy40MzcsMCwzMDkuMzMzdjE0OS4zMzMgICAgIGMwLDUuODk2LDQuNzcxLDEwLjY2NywxMC42NjcsMTAuNjY3SDE2MGM1Ljg5NiwwLDEwLjY2Ny00Ljc3MSwxMC42NjctMTAuNjY3di0yMS4zMzMgICAgIEMxNzAuNjY3LDQzMS40MzgsMTY1Ljg5Niw0MjYuNjY3LDE2MCw0MjYuNjY3eiIgZGF0YS1vcmlnaW5hbD0iIzAwMDAwMCIgc3R5bGU9IiIgZmlsbD0iI2ZmZmZmZiIgY2xhc3M9IiIvPgogICAgPC9nPgogICA8L2c+CiAgPC9nPgogIDxnIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIvPgogIDxnIHhtbG5zPSJodHRwOi8vd3'+
			'd3LnczLm9yZy8yMDAwL3N2ZyIvPgogIDxnIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIvPgogIDxnIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIvPgogIDxnIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIvPgogIDxnIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIvPgogIDxnIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIvPgogIDxnIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIvPgogIDxnIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIvPgogIDxnIHhtbG5zPSJodHRwOi8vd3d3'+
			'LnczLm9yZy8yMDAwL3N2ZyIvPgogIDxnIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIvPgogIDxnIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIvPgogIDxnIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIvPgogIDxnIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIvPgogIDxnIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIvPgogPC9nPgo8L3N2Zz4K';
		me._fullscreen__img.setAttribute('src',hs);
		hs ='';
		hs += 'position: absolute;top: 0px;left: 0px;width: 100%;height: 100%;-webkit-user-drag:none;pointer-events:none;;';
		els.setAttribute('style', hs);
		els['ondragstart']=function() { return false; };
		el.appendChild(els);
		el.ggSubElement = els;
		el.ggId="fullscreen";
		el.ggDx=0;
		el.ggDy=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_svg ";
		el.ggType='svg';
		hs ='';
		hs+='cursor : pointer;';
		hs+='height : 28px;';
		hs+='left : calc(50% - ((28px + 0px) / 2) + 0px);';
		hs+='position : absolute;';
		hs+='top : calc(50% - ((28px + 0px) / 2) + 0px);';
		hs+='visibility : inherit;';
		hs+='width : 28px;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me._fullscreen.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._fullscreen.onclick=function (e) {
			me._fullscreenexit.style.transition='none';
			me._fullscreenexit.style.visibility=(Number(me._fullscreenexit.style.opacity)>0||!me._fullscreenexit.style.opacity)?'inherit':'hidden';
			me._fullscreenexit.ggVisible=true;
			me._fullscreen.style.transition='none';
			me._fullscreen.style.visibility='hidden';
			me._fullscreen.ggVisible=false;
		}
		me._fullscreen.ggUpdatePosition=function (useTransition) {
		}
		me.__6fullscreen.appendChild(me._fullscreen);
		el=me._fullscreenexit=document.createElement('div');
		els=me._fullscreenexit__img=document.createElement('img');
		els.className='ggskin ggskin_svg';
		hs='data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0nMS4wJz8+CjxzdmcgaGVpZ2h0PSI1MTIiIGNsYXNzPSIiIHk9IjAiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDQ2OS4zMzMgNDY5LjMzMyIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgNTEyIDUxMiIgeG1sbnM6c3ZnanM9Imh0dHA6Ly9zdmdqcy5jb20vc3ZnanMiIHdpZHRoPSI1MTIiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjAiPgogPGc+CiAgPGcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3'+
			'ZnIj4KICAgPGc+CiAgICA8Zz4KICAgICA8cGF0aCBkPSJNMTYwLDBoLTIxLjMzM0MxMzIuNzcxLDAsMTI4LDQuNzcxLDEyOCwxMC42NjdWMTI4SDEwLjY2N0M0Ljc3MSwxMjgsMCwxMzIuNzcxLDAsMTM4LjY2N1YxNjAgICAgIGMwLDUuODk2LDQuNzcxLDEwLjY2NywxMC42NjcsMTAuNjY3SDE2MGM1Ljg5NiwwLDEwLjY2Ny00Ljc3MSwxMC42NjctMTAuNjY3VjEwLjY2N0MxNzAuNjY3LDQuNzcxLDE2NS44OTYsMCwxNjAsMHoiIGRhdGEtb3JpZ2luYWw9IiMwMDAwMDAiIHN0eWxlPSIiIGZpbGw9IiNmZmZmZmYiIGNsYXNzPSIiLz4KICAgICA8cGF0aCBkPSJNNDU4LjY2NywxMjhIMzQxLjMzM1Yx'+
			'MC42NjdDMzQxLjMzMyw0Ljc3MSwzMzYuNTYzLDAsMzMwLjY2NywwaC0yMS4zMzNjLTUuODk2LDAtMTAuNjY3LDQuNzcxLTEwLjY2NywxMC42NjdWMTYwICAgICBjMCw1Ljg5Niw0Ljc3MSwxMC42NjcsMTAuNjY3LDEwLjY2N2gxNDkuMzMzYzUuODk2LDAsMTAuNjY3LTQuNzcxLDEwLjY2Ny0xMC42Njd2LTIxLjMzMyAgICAgQzQ2OS4zMzMsMTMyLjc3MSw0NjQuNTYzLDEyOCw0NTguNjY3LDEyOHoiIGRhdGEtb3JpZ2luYWw9IiMwMDAwMDAiIHN0eWxlPSIiIGZpbGw9IiNmZmZmZmYiIGNsYXNzPSIiLz4KICAgICA8cGF0aCBkPSJNNDU4LjY2NywyOTguNjY3SDMwOS4zMzNjLTUuODk2LDAtMTAuNj'+
			'Y3LDQuNzcxLTEwLjY2NywxMC42Njd2MTQ5LjMzM2MwLDUuODk2LDQuNzcxLDEwLjY2NywxMC42NjcsMTAuNjY3aDIxLjMzMyAgICAgYzUuODk2LDAsMTAuNjY3LTQuNzcxLDEwLjY2Ny0xMC42NjdWMzQxLjMzM2gxMTcuMzMzYzUuODk2LDAsMTAuNjY3LTQuNzcxLDEwLjY2Ny0xMC42Njd2LTIxLjMzMyAgICAgQzQ2OS4zMzMsMzAzLjQzNyw0NjQuNTYzLDI5OC42NjcsNDU4LjY2NywyOTguNjY3eiIgZGF0YS1vcmlnaW5hbD0iIzAwMDAwMCIgc3R5bGU9IiIgZmlsbD0iI2ZmZmZmZiIgY2xhc3M9IiIvPgogICAgIDxwYXRoIGQ9Ik0xNjAsMjk4LjY2N0gxMC42NjdDNC43NzEsMjk4LjY2NywwLDMw'+
			'My40MzcsMCwzMDkuMzMzdjIxLjMzM2MwLDUuODk2LDQuNzcxLDEwLjY2NywxMC42NjcsMTAuNjY3SDEyOHYxMTcuMzMzICAgICBjMCw1Ljg5Niw0Ljc3MSwxMC42NjcsMTAuNjY3LDEwLjY2N0gxNjBjNS44OTYsMCwxMC42NjctNC43NzEsMTAuNjY3LTEwLjY2N1YzMDkuMzMzICAgICBDMTcwLjY2NywzMDMuNDM3LDE2NS44OTYsMjk4LjY2NywxNjAsMjk4LjY2N3oiIGRhdGEtb3JpZ2luYWw9IiMwMDAwMDAiIHN0eWxlPSIiIGZpbGw9IiNmZmZmZmYiIGNsYXNzPSIiLz4KICAgIDwvZz4KICAgPC9nPgogIDwvZz4KICA8ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciLz4KICA8Zy'+
			'B4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciLz4KICA8ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciLz4KICA8ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciLz4KICA8ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciLz4KICA8ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciLz4KICA8ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciLz4KICA8ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciLz4KICA8ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciLz4KICA8ZyB4'+
			'bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciLz4KICA8ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciLz4KICA8ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciLz4KICA8ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciLz4KICA8ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciLz4KICA8ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciLz4KIDwvZz4KPC9zdmc+Cg==';
		me._fullscreenexit__img.setAttribute('src',hs);
		hs ='';
		hs += 'position: absolute;top: 0px;left: 0px;width: 100%;height: 100%;-webkit-user-drag:none;pointer-events:none;;';
		els.setAttribute('style', hs);
		els['ondragstart']=function() { return false; };
		el.appendChild(els);
		el.ggSubElement = els;
		el.ggId="fullscreenexit";
		el.ggDx=0;
		el.ggDy=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_svg ";
		el.ggType='svg';
		hs ='';
		hs+='cursor : pointer;';
		hs+='height : 28px;';
		hs+='left : calc(50% - ((28px + 0px) / 2) + 0px);';
		hs+='position : absolute;';
		hs+='top : calc(50% - ((28px + 0px) / 2) + 0px);';
		hs+='visibility : inherit;';
		hs+='width : 28px;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me._fullscreenexit.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._fullscreenexit.onclick=function (e) {
			me._fullscreen.style.transition='none';
			me._fullscreen.style.visibility=(Number(me._fullscreen.style.opacity)>0||!me._fullscreen.style.opacity)?'inherit':'hidden';
			me._fullscreen.ggVisible=true;
			me._fullscreenexit.style.transition='none';
			me._fullscreenexit.style.visibility='hidden';
			me._fullscreenexit.ggVisible=false;
		}
		me._fullscreenexit.ggUpdatePosition=function (useTransition) {
		}
		me.__6fullscreen.appendChild(me._fullscreenexit);
		me.divSkin.appendChild(me.__6fullscreen);
		el=me._solmenu=document.createElement('div');
		el.ggId="SolMenu";
		el.ggDy=-84;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=false;
		el.className="ggskin ggskin_container ";
		el.ggType='container';
		hs ='';
		hs+='height : 396px;';
		hs+='left : -200px;';
		hs+='position : absolute;';
		hs+='top : calc(50% - ((396px + 0px) / 2) - 84px);';
		hs+='visibility : hidden;';
		hs+='width : 199px;';
		hs+='pointer-events:none;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me._solmenu.ggIsActive=function() {
			return false;
		}
		el.ggElementNodeId=function() {
			return player.getCurrentNode();
		}
		me._solmenu.logicBlock_position = function() {
			var newLogicStatePosition;
			if (
				((player.getVariableValue('solmenuklasor') == true))
			)
			{
				newLogicStatePosition = 0;
			}
			else {
				newLogicStatePosition = -1;
			}
			if (me._solmenu.ggCurrentLogicStatePosition != newLogicStatePosition) {
				me._solmenu.ggCurrentLogicStatePosition = newLogicStatePosition;
				me._solmenu.style.transition='left 1000ms ease 0ms, top 1000ms ease 0ms';
				if (me._solmenu.ggCurrentLogicStatePosition == 0) {
					me._solmenu.style.left='0px';
					me._solmenu.style.top = 'calc(50% - (396px / 2) - (0px / 2) + -84px)';
				}
				else {
					me._solmenu.style.left='-200px';
					me._solmenu.style.top='calc(50% - ((396px + 0px) / 2) - 84px)';
				}
			}
		}
		me._solmenu.logicBlock_position();
		me._solmenu.logicBlock_visible = function() {
			var newLogicStateVisible;
			if (
				((player.getVariableValue('solmenu') == true))
			)
			{
				newLogicStateVisible = 0;
			}
			else {
				newLogicStateVisible = -1;
			}
			if (me._solmenu.ggCurrentLogicStateVisible != newLogicStateVisible) {
				me._solmenu.ggCurrentLogicStateVisible = newLogicStateVisible;
				me._solmenu.style.transition='left 1000ms ease 0ms, top 1000ms ease 0ms';
				if (me._solmenu.ggCurrentLogicStateVisible == 0) {
					me._solmenu.style.visibility=(Number(me._solmenu.style.opacity)>0||!me._solmenu.style.opacity)?'inherit':'hidden';
					me._solmenu.ggVisible=true;
				}
				else {
					me._solmenu.style.visibility="hidden";
					me._solmenu.ggVisible=false;
				}
			}
		}
		me._solmenu.logicBlock_visible();
		me._solmenu.ggUpdatePosition=function (useTransition) {
		}
		el=me._sol_menu=document.createElement('div');
		el.ggId="Sol Menu";
		el.ggDy=103;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_rectangle ";
		el.ggType='rectangle';
		hs ='';
		hs+='background : rgba(0,0,0,0.870588);';
		hs+='border : 0px solid #000000;';
		hs+='cursor : default;';
		hs+='height : 197px;';
		hs+='left : 0px;';
		hs+='position : absolute;';
		hs+='top : calc(50% - ((197px + 0px) / 2) + 103px);';
		hs+='visibility : inherit;';
		hs+='width : 200px;';
		hs+='pointer-events:auto;';
		hs+='backdrop-filter: blur(5px); border-radius: 0px 15px 15px 0px;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me._sol_menu.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._sol_menu.ggUpdatePosition=function (useTransition) {
		}
		el=me._menu=document.createElement('div');
		el.ggId="Menu";
		el.ggDy=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_rectangle ";
		el.ggType='rectangle';
		hs ='';
		hs+='background : rgba(0,0,0,0.870588);';
		hs+='border : 0px solid #000000;';
		hs+='cursor : pointer;';
		hs+='height : 150px;';
		hs+='left : 199px;';
		hs+='position : absolute;';
		hs+='top : calc(50% - ((150px + 0px) / 2) + 0px);';
		hs+='visibility : inherit;';
		hs+='width : 40px;';
		hs+='pointer-events:auto;';
		hs+='border-radius: 0px 10px 10px 0px; backdrop-filter: blur(5px);';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me._menu.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._menu.onclick=function (e) {
			player.setVariableValue('solmenuklasor', !player.getVariableValue('solmenuklasor'));
			player.setVariableValue('Sosyalmedya', false);
			player.setVariableValue('infoklasor', false);
			player.setVariableValue('altmenu', false);
		}
		me._menu.ggUpdatePosition=function (useTransition) {
		}
		el=me._menuyazi=document.createElement('div');
		els=me._menuyazi__img=document.createElement('img');
		els.className='ggskin ggskin_menuyazi';
		hs='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAACWCAYAAACsPspoAAAEC0lEQVR4nO2c7XHjIBCGl5v7b3dgd5B0EHXgdBB1EJfgdJDrQOnA6UDXgdMB7sCpYO9HULxgEMuXz3ezz0xmVhKIV6xBsBABCIIgCILwN1GcRIi4c04NSinNLQQROwDoyCmtlBq4+TkFuOwS8++d/GM1cQGBOiHv2pO/nsBAAYiI98z8W19mbvk/GGnWxD4Su2eWMaX7ZKa34Aik7In9GEtsavnOk5dNqsATAHwYe4WIMZE9scfEsgCAJ9D9rdGCYgLp9T2cH27qeqJwBC6d4yEgwMLU7socviulTvDlgSRSXQxKqQOcG8tixs1u7WWRWoOjp8DezYCISwB4Moef0Figr78bib0xgihW7Rn3unSMstNdDACglNqD3a+5bg65t/1vkDAQ+1sQIq4BYG'+
			'MOj+ZhJg6phaS6mNbAQOwNsas0jgmOwMVkmBZM7e9XH2nNHck7zNy3m7mWJHAO69VnGstUmx/0gXIpFTgQuwPbvfTaxFhYng0idmSE5G2BiKhJmgOx15H7scSm1GDIXdTN08jlnTElYI0nS10M4Hclp/Uu4kniAtexG7itGeZfbZojipIicO4tQAWFXm2QMhOc+Bm5PgZsl1c4P0DMvS+TgYjL0MMIgiAIQh1YEVYXvIyYxgtSapdTVhaIuAvEDIPkllVjPNiU2GiGwxvMz96KqCFQK6XGCvfxcvMuFoGliMBSarTinhEQH3LX5moIXME5WB5izL15DYFHiE/IY9eD1BA4tBwI3HwjEYGliMBSbl5gjW5mzVxa1TnxwSxy5iSYuFNk4r918XilPIIgCIJQCDvC6omqsvex0oFCswmWZwQzJuTNjrSWjGYeEHFbkJ9F'+
			'6XBrh5f7tqpSKnABDcO/APkC34i9YQ75s8gVqMEWObRydYmLd8ReOcfVyBZo+sBf5NQzMjd/p1DcisHe6DgU3u+CIoFmSwntC+9yp5chiqedJrT7m5zaomdjWS65AjvnuCd21b6xysTdNJgXcuoB49voWVSLLJhRCt1k9lqjb6wd+uiJvQK7AWVRVaBZ9aRvmK2pxaM/R5wWwaMtnPvGBXztjNO5N6su0NM3PgFjo2SIJuE3T98YW4kK0jI+2Ne4STOBnr4xi6YRVk/fmExKhHUktk7I9wiM/yATBEEQhDakRFjXQEYo3Ehpbr5k0P6HKXakNDffxM2vF4vAUkRgKSKwFBFYiggsRQSC/aWL5G/OXEMgXdxp8p2FCU0PEhYQi+LUbIEmWkVdxF326og9csvLAu3PU2lGemuw2mItzy2wdwoMRvERcYn2Zw10U3Gk4I'+
			'Mj8mJbgKk5N911QnCIeI+IJ7xkNH/ac+31KuIckW4N+TjN/QyuIbTHr4ZDa02bmpwWcQRBEARB+If5A5fkO1MPNxdJAAAAAElFTkSuQmCC';
		els.setAttribute('src',hs);
		els.ggNormalSrc=hs;
		hs ='';
		hs += 'position: absolute;top: 0px;left: 0px;width: 100%;height: 100%;-webkit-user-drag:none;pointer-events:none;;';
		els.setAttribute('style', hs);
		els.className='ggskin ggskin_image';
		els['ondragstart']=function() { return false; };
		player.checkLoaded.push(els);
		el.appendChild(els);
		el.ggSubElement = els;
		el.ggId="menuyazi";
		el.ggDy=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:0.4,sy:0.4,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_image ";
		el.ggType='image';
		hs ='';
		hs+='height : 150px;';
		hs+='left : -1px;';
		hs+='position : absolute;';
		hs+='top : calc(50% - ((150px + 0px) / 2) + 0px);';
		hs+='visibility : inherit;';
		hs+='width : 40px;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		el.style.transform=parameterToTransform(el.ggParameter);
		me._menuyazi.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._menuyazi.ggUpdatePosition=function (useTransition) {
		}
		me._menu.appendChild(me._menuyazi);
		el=me._image_10=document.createElement('div');
		els=me._image_10__img=document.createElement('img');
		els.className='ggskin ggskin_image_10';
		hs='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAAAH7ElEQVR4nO3cu44cxxmG4WomCgT4kuxUsC+Iykxl4gVZsZ2Y92PAUGT8TraoPUzVnLq7Ts8DbMYFCsR8L3p3pyYllhURXyLi19bnAE72Mv5MBGAV78YvArCKwvhFAGZ3ZfwiALO6cfwiALO5c/wiALN4cPwiAKN7cvwiAKPaafwiAKPZefwiAKM4aPwiAL07ePwiAL06afwiAL05efwiAL1oNH4RgNYajz8TAThb9DH+TATgLNHX+DMRgKNFn+PPRACOEn2PPxMB2FuMMf5MBGAvMdb4MxGAZ8WY489EAB4VY48/EwG4V8wx/kwE4FYx1/gzEYBrYs7xZyIAJTH3+DMRgPdijfFnIgBZrDX+TAQ6sLU+wOoi4ktK6e+tz9HI123bfm59iJUJQEOLjz'+
			'8TgYYEoBHjf0MEGhGABoz/IhFoQABOZvxVInAyATiR8d9EBE4kACcx/ruIwEkE4ATG/xAROIEAHMz4nyICBxOAAxn/LkTgQAJwEOPflQgcRAAOYPyHEIEDCMDOjP9QIrAzAdiR8Z9CBHYkADsx/lOJwE4EYAfG34QI7EAAnmT8TYnAkwTgCcbfBRF4ggA8yPi7IgIPEoAHGH+XROABAnAn4++aCNxJAO5g/EMQgTsIwI2MfygicCMBuIHxD0kEbiAAVxj/0ETgCgGoMP4piECFABQY/1REoEAALjD+KYnABQLwjvFPTQTeEYBXjH8JIvCKALww/qWIwAsBSMa/KBFIAmD8a1s+AksHwPhJi0dg2QAYP68sG4ElA2D8XLBkBJYLgPFTsVwElgqA8XODpSKwTACMnzssE4FPrQ9wBuMv+vbyxVufX14z05v+CcD4i76l'+
			'lH5KKf0vpfRbSunPbY/TpemfBKYOgPEXfUsp/bRt239SSikifkwiUDJ1BKYNgPEXvRl/JgJV00ZgygAYf9HF8WciUDVlBKYLgPEXVcefiUDVdBGYKgDGX3TT+DMRqJoqAtMEwPiL7hp/JgJV00RgigAYf9FD489EoGqKCAwfAOMvemr8mQhUDR+BoQNg/EW7jD8TgaqhIzBsAIy/aNfxZyJQNWwEhgyA8RcdMv5MBKqGjMBwATD+okPHn4lA1XARGCoAxl90yvgzEagaKgLDBMD4i04dfyYCVcNEYIgAGH9Rk/FnIlA1RAS6D4DxFzUdfyYCVd1HoOsAGH9RF+PPRKCq6wh0GwDjL+pq/JkIVHUbgS4DYPxFXY4/E4GqLiPQXQCMv6jr8WciUNVdBLoKgPEXDTH+TASquopANwEw/qKhxp+JQFU3EegiAMZfNOT4Mx'+
			'Go6iICzQNg/EVDjz8TgarmEWgaAOMvmmL8mQhUNY1AswAYf9FU489EoKpZBJoEwPiLphx/JgJVTSJwegCMv2jq8WciUHV6BE4NgPEXLTH+TASqTo3AaQEw/qKlxp+JQNVpETglAMZftOT4MxGoOiUChwfA+IuWHn8mAlWHR+DQABh/kfG/IgJVh0bgsAAYf5HxXyACVYdF4JAAGH+R8VeIQNUhEdg9AMZfZPw3EIGq3SOwawCMv8j47yACVbtGYLcAGH+R8T9ABKp2i8AuATD+IuN/gghU7RKBpwNg/EXGvwMRqHo6Ak8FwPiLjH9HIlD1VAQeDoDxFxn/AUSg6uEIPBQA4y8y/gOJQNVDEbg7AMZfZPwnEIGquyPw6Z5/bPxFxn+Sbdv+m1L6a0rpX63P0qHPEfHrPd9w8xOA8RcZfwMvTwL/SCn9pfVZOnTzk8BN'+
			'ATD+IuNvSASqborA1QAYf5Hxd0AEqq5GoBoA4y8y/o6IQFU1AsUAGH+R8XdIBKqKEbgYAOMvMv6OiUDVxQh8CIDxFxn/AESg6kME3gTA+IuMfyAiUPUmAt8DYPxFxj8gEaj6HoEtJeOvMP6BiUDV123bft6Mv8j4JyACVV8/pZR+b32KDhn/JF7uDvwtuTtwye/5R4DPKaW7LhFMzPgn5Enggy/btv3y+peAImD8UxOB775s2/ZLSh//DLhyBIx/ASLwx/hTuvxGoBUjYPwLWTgCb8afUvmtwCtFwPgXtGAEPow/pfploBUiYPwLWygCF8ef0vXrwDNHwPhZIQLF8ad02weCzBgB4+e7iSNQHX9Kt38k2EwRMH4+mDACV8d/l4j4HOP7d0T8abf/FKYSET9GxD8bv0b3cMxb+2PsCBg/V8X4ETj2Xk+MGQHj52Yxbg'+
			'TOudQXY0XA+LlbjBeBc2/0xhgRMH4eFuNEoM11/ug7AsbP06L/CLT9LI/oMwLGz26i3wj08UE+0VcEjJ/dRX8R6GP8WfQRAePnMNFPBPoafxZtI2D8HC7aR6DP8WfRJgLGz2miXQT6Hn8W50bA+DldnB+BMcafxTkRMH6aifMiMNb4szg2AsZPc3F8BMYcfxbHRMD46UYcF4Gxx5/FvhEwfroT+0dgjvFnsU8EjJ9uxX4RmGv8WTwXAeOneztEYM7xZw9GwPgZxhMRmHv82Z0RMH6G80AE1hh/dmMEjJ9h3RGBtcafXYmA8TO8GyKw5vizQgSMn2lUIrD2+LN3ETB+pnMhAsb/2ksEjJ9pvYqA8V8SET+0PgMcyWscAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'+
			'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgPf+D9Cnr3nmolKFAAAAAElFTkSuQmCC';
		els.setAttribute('src',hs);
		els.ggNormalSrc=hs;
		hs ='';
		hs += 'position: absolute;top: 0px;left: 0px;width: 100%;height: 100%;-webkit-user-drag:none;pointer-events:none;;';
		els.setAttribute('style', hs);
		els.className='ggskin ggskin_image';
		els['ondragstart']=function() { return false; };
		player.checkLoaded.push(els);
		el.appendChild(els);
		el.ggSubElement = els;
		el.ggId="Image 1";
		el.ggDx=-2;
		el.ggParameter={ rx:0,ry:0,a:90,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_image ";
		el.ggType='image';
		hs ='';
		hs+='cursor : pointer;';
		hs+='height : 16px;';
		hs+='left : calc(50% - ((16px + 0px) / 2) - 2px);';
		hs+='position : absolute;';
		hs+='top : 10px;';
		hs+='visibility : inherit;';
		hs+='width : 16px;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		el.style.transform=parameterToTransform(el.ggParameter);
		me._image_10.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._image_10.logicBlock_angle = function() {
			var newLogicStateAngle;
			if (
				((player.getVariableValue('solmenu') == true))
			)
			{
				newLogicStateAngle = 0;
			}
			else {
				newLogicStateAngle = -1;
			}
			if (me._image_10.ggCurrentLogicStateAngle != newLogicStateAngle) {
				me._image_10.ggCurrentLogicStateAngle = newLogicStateAngle;
				me._image_10.style.transition='transform 500ms ease 0ms';
				if (me._image_10.ggCurrentLogicStateAngle == 0) {
					me._image_10.ggParameter.a = -90;
					me._image_10.style.transform=parameterToTransform(me._image_10.ggParameter);
				}
				else {
					me._image_10.ggParameter.a = 90;
					me._image_10.style.transform=parameterToTransform(me._image_10.ggParameter);
				}
			}
		}
		me._image_10.logicBlock_angle();
		me._image_10.ggUpdatePosition=function (useTransition) {
		}
		me._menu.appendChild(me._image_10);
		el=me._image_1=document.createElement('div');
		els=me._image_1__img=document.createElement('img');
		els.className='ggskin ggskin_image_1';
		hs='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAAAH7ElEQVR4nO3cu44cxxmG4WomCgT4kuxUsC+Iykxl4gVZsZ2Y92PAUGT8TraoPUzVnLq7Ts8DbMYFCsR8L3p3pyYllhURXyLi19bnAE72Mv5MBGAV78YvArCKwvhFAGZ3ZfwiALO6cfwiALO5c/wiALN4cPwiAKN7cvwiAKPaafwiAKPZefwiAKM4aPwiAL07ePwiAL06afwiAL05efwiAL1oNH4RgNYajz8TAThb9DH+TATgLNHX+DMRgKNFn+PPRACOEn2PPxMB2FuMMf5MBGAvMdb4MxGAZ8WY489EAB4VY48/EwG4V8wx/kwE4FYx1/gzEYBrYs7xZyIAJTH3+DMRgPdijfFnIgBZrDX+TAQ6sLU+wOoi4ktK6e+tz9HI123bfm59iJUJQEOLjz'+
			'8TgYYEoBHjf0MEGhGABoz/IhFoQABOZvxVInAyATiR8d9EBE4kACcx/ruIwEkE4ATG/xAROIEAHMz4nyICBxOAAxn/LkTgQAJwEOPflQgcRAAOYPyHEIEDCMDOjP9QIrAzAdiR8Z9CBHYkADsx/lOJwE4EYAfG34QI7EAAnmT8TYnAkwTgCcbfBRF4ggA8yPi7IgIPEoAHGH+XROABAnAn4++aCNxJAO5g/EMQgTsIwI2MfygicCMBuIHxD0kEbiAAVxj/0ETgCgGoMP4piECFABQY/1REoEAALjD+KYnABQLwjvFPTQTeEYBXjH8JIvCKALww/qWIwAsBSMa/KBFIAmD8a1s+AksHwPhJi0dg2QAYP68sG4ElA2D8XLBkBJYLgPFTsVwElgqA8XODpSKwTACMnzssE4FPrQ9wBuMv+vbyxVufX14z05v+CcD4i76l'+
			'lH5KKf0vpfRbSunPbY/TpemfBKYOgPEXfUsp/bRt239SSikifkwiUDJ1BKYNgPEXvRl/JgJV00ZgygAYf9HF8WciUDVlBKYLgPEXVcefiUDVdBGYKgDGX3TT+DMRqJoqAtMEwPiL7hp/JgJV00RgigAYf9FD489EoGqKCAwfAOMvemr8mQhUDR+BoQNg/EW7jD8TgaqhIzBsAIy/aNfxZyJQNWwEhgyA8RcdMv5MBKqGjMBwATD+okPHn4lA1XARGCoAxl90yvgzEagaKgLDBMD4i04dfyYCVcNEYIgAGH9Rk/FnIlA1RAS6D4DxFzUdfyYCVd1HoOsAGH9RF+PPRKCq6wh0GwDjL+pq/JkIVHUbgS4DYPxFXY4/E4GqLiPQXQCMv6jr8WciUNVdBLoKgPEXDTH+TASquopANwEw/qKhxp+JQFU3EegiAMZfNOT4Mx'+
			'Go6iICzQNg/EVDjz8TgarmEWgaAOMvmmL8mQhUNY1AswAYf9FU489EoKpZBJoEwPiLphx/JgJVTSJwegCMv2jq8WciUHV6BE4NgPEXLTH+TASqTo3AaQEw/qKlxp+JQNVpETglAMZftOT4MxGoOiUChwfA+IuWHn8mAlWHR+DQABh/kfG/IgJVh0bgsAAYf5HxXyACVYdF4JAAGH+R8VeIQNUhEdg9AMZfZPw3EIGq3SOwawCMv8j47yACVbtGYLcAGH+R8T9ABKp2i8AuATD+IuN/gghU7RKBpwNg/EXGvwMRqHo6Ak8FwPiLjH9HIlD1VAQeDoDxFxn/AUSg6uEIPBQA4y8y/gOJQNVDEbg7AMZfZPwnEIGquyPw6Z5/bPxFxn+Sbdv+m1L6a0rpX63P0qHPEfHrPd9w8xOA8RcZfwMvTwL/SCn9pfVZOnTzk8BN'+
			'ATD+IuNvSASqborA1QAYf5Hxd0AEqq5GoBoA4y8y/o6IQFU1AsUAGH+R8XdIBKqKEbgYAOMvMv6OiUDVxQh8CIDxFxn/AESg6kME3gTA+IuMfyAiUPUmAt8DYPxFxj8gEaj6HoEtJeOvMP6BiUDV123bft6Mv8j4JyACVV8/pZR+b32KDhn/JF7uDvwtuTtwye/5R4DPKaW7LhFMzPgn5Enggy/btv3y+peAImD8UxOB775s2/ZLSh//DLhyBIx/ASLwx/hTuvxGoBUjYPwLWTgCb8afUvmtwCtFwPgXtGAEPow/pfploBUiYPwLWygCF8ef0vXrwDNHwPhZIQLF8ad02weCzBgB4+e7iSNQHX9Kt38k2EwRMH4+mDACV8d/l4j4HOP7d0T8abf/FKYSET9GxD8bv0b3cMxb+2PsCBg/V8X4ETj2Xk+MGQHj52Yxbg'+
			'TOudQXY0XA+LlbjBeBc2/0xhgRMH4eFuNEoM11/ug7AsbP06L/CLT9LI/oMwLGz26i3wj08UE+0VcEjJ/dRX8R6GP8WfQRAePnMNFPBPoafxZtI2D8HC7aR6DP8WfRJgLGz2miXQT6Hn8W50bA+DldnB+BMcafxTkRMH6aifMiMNb4szg2AsZPc3F8BMYcfxbHRMD46UYcF4Gxx5/FvhEwfroT+0dgjvFnsU8EjJ9uxX4RmGv8WTwXAeOneztEYM7xZw9GwPgZxhMRmHv82Z0RMH6G80AE1hh/dmMEjJ9h3RGBtcafXYmA8TO8GyKw5vizQgSMn2lUIrD2+LN3ETB+pnMhAsb/2ksEjJ9pvYqA8V8SET+0PgMcyWscAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'+
			'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgPf+D9Cnr3nmolKFAAAAAElFTkSuQmCC';
		els.setAttribute('src',hs);
		els.ggNormalSrc=hs;
		hs ='';
		hs += 'position: absolute;top: 0px;left: 0px;width: 100%;height: 100%;-webkit-user-drag:none;pointer-events:none;;';
		els.setAttribute('style', hs);
		els.className='ggskin ggskin_image';
		els['ondragstart']=function() { return false; };
		player.checkLoaded.push(els);
		el.appendChild(els);
		el.ggSubElement = els;
		el.ggId="Image 1";
		el.ggDx=-2;
		el.ggParameter={ rx:0,ry:0,a:90,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_image ";
		el.ggType='image';
		hs ='';
		hs+='bottom : 10px;';
		hs+='cursor : pointer;';
		hs+='height : 16px;';
		hs+='left : calc(50% - ((16px + 0px) / 2) - 2px);';
		hs+='position : absolute;';
		hs+='visibility : inherit;';
		hs+='width : 16px;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		el.style.transform=parameterToTransform(el.ggParameter);
		me._image_1.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._image_1.logicBlock_angle = function() {
			var newLogicStateAngle;
			if (
				((player.getVariableValue('solmenu') == true))
			)
			{
				newLogicStateAngle = 0;
			}
			else {
				newLogicStateAngle = -1;
			}
			if (me._image_1.ggCurrentLogicStateAngle != newLogicStateAngle) {
				me._image_1.ggCurrentLogicStateAngle = newLogicStateAngle;
				me._image_1.style.transition='transform 500ms ease 0ms';
				if (me._image_1.ggCurrentLogicStateAngle == 0) {
					me._image_1.ggParameter.a = -90;
					me._image_1.style.transform=parameterToTransform(me._image_1.ggParameter);
				}
				else {
					me._image_1.ggParameter.a = 90;
					me._image_1.style.transform=parameterToTransform(me._image_1.ggParameter);
				}
			}
		}
		me._image_1.logicBlock_angle();
		me._image_1.ggUpdatePosition=function (useTransition) {
		}
		me._menu.appendChild(me._image_1);
		me._sol_menu.appendChild(me._menu);
		el=me._tiefkhl_frische=document.createElement('div');
		els=me._tiefkhl_frische__text=document.createElement('div');
		el.className='ggskin ggskin_textdiv';
		el.ggTextDiv=els;
		el.ggId="Tiefk\xfchl & Frische";
		el.ggDx=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_text ";
		el.ggType='text';
		hs ='';
		hs+='border : 0px solid #000000;';
		hs+='color : rgba(255,255,255,1);';
		hs+='cursor : pointer;';
		hs+='height : 20px;';
		hs+='left : calc(50% - ((90% + 0px) / 2) + 0px);';
		hs+='position : absolute;';
		hs+='top : 146px;';
		hs+='visibility : inherit;';
		hs+='width : 90%;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		hs ='';
		hs += 'box-sizing: border-box;';
		hs+='width: 100%;';
		hs+='height: 100%;';
		hs+='font-size: 14px;';
		hs+='font-weight: bold;';
		hs+='text-align: center;';
		hs+='white-space: pre;';
		hs+='padding: 0px;';
		hs+='overflow: hidden;';
		hs+='overflow-y: auto;';
		els.setAttribute('style',hs);
		me._tiefkhl_frische.ggUpdateText=function() {
			var params = [];
			var hs = player._("Tiefk\xfchl & Frische", params);
			if (hs!=this.ggText) {
				this.ggText=hs;
				this.ggTextDiv.innerHTML=hs;
				if (this.ggUpdatePosition) this.ggUpdatePosition();
			}
		}
		me._tiefkhl_frische.ggUpdateText();
		el.appendChild(els);
		me._tiefkhl_frische.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._tiefkhl_frische.logicBlock_scaling = function() {
			var newLogicStateScaling;
			if (
				((me.elementMouseOver['tiefkhl_frische'] == true))
			)
			{
				newLogicStateScaling = 0;
			}
			else {
				newLogicStateScaling = -1;
			}
			if (me._tiefkhl_frische.ggCurrentLogicStateScaling != newLogicStateScaling) {
				me._tiefkhl_frische.ggCurrentLogicStateScaling = newLogicStateScaling;
				me._tiefkhl_frische.style.transition='transform 200ms ease 0ms';
				if (me._tiefkhl_frische.ggCurrentLogicStateScaling == 0) {
					me._tiefkhl_frische.ggParameter.sx = 1.05;
					me._tiefkhl_frische.ggParameter.sy = 1.05;
					me._tiefkhl_frische.style.transform=parameterToTransform(me._tiefkhl_frische.ggParameter);
					setTimeout(function() {skin.updateSize(me._tiefkhl_frische);}, 250);
				}
				else {
					me._tiefkhl_frische.ggParameter.sx = 1;
					me._tiefkhl_frische.ggParameter.sy = 1;
					me._tiefkhl_frische.style.transform=parameterToTransform(me._tiefkhl_frische.ggParameter);
					setTimeout(function() {skin.updateSize(me._tiefkhl_frische);}, 250);
				}
			}
		}
		me._tiefkhl_frische.logicBlock_scaling();
		me._tiefkhl_frische.onclick=function (e) {
			player.openNext("{node8}","38.32\/0\/100");
		}
		me._tiefkhl_frische.onmouseenter=function (e) {
			me.elementMouseOver['tiefkhl_frische']=true;
			me._tiefkhl_frische.logicBlock_scaling();
		}
		me._tiefkhl_frische.onmouseleave=function (e) {
			me.elementMouseOver['tiefkhl_frische']=false;
			me._tiefkhl_frische.logicBlock_scaling();
		}
		me._tiefkhl_frische.ggUpdatePosition=function (useTransition) {
		}
		me._sol_menu.appendChild(me._tiefkhl_frische);
		el=me._obst_gemse=document.createElement('div');
		els=me._obst_gemse__text=document.createElement('div');
		el.className='ggskin ggskin_textdiv';
		el.ggTextDiv=els;
		el.ggId="Obst & Gem\xfcse";
		el.ggDx=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_text ";
		el.ggType='text';
		hs ='';
		hs+='border : 0px solid #000000;';
		hs+='color : rgba(255,255,255,1);';
		hs+='cursor : pointer;';
		hs+='height : 20px;';
		hs+='left : calc(50% - ((90% + 0px) / 2) + 0px);';
		hs+='position : absolute;';
		hs+='top : 116px;';
		hs+='visibility : inherit;';
		hs+='width : 90%;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		hs ='';
		hs += 'box-sizing: border-box;';
		hs+='width: 100%;';
		hs+='height: 100%;';
		hs+='font-size: 14px;';
		hs+='font-weight: bold;';
		hs+='text-align: center;';
		hs+='white-space: pre;';
		hs+='padding: 0px;';
		hs+='overflow: hidden;';
		hs+='overflow-y: auto;';
		els.setAttribute('style',hs);
		me._obst_gemse.ggUpdateText=function() {
			var params = [];
			var hs = player._("Obst & Gem\xfcse", params);
			if (hs!=this.ggText) {
				this.ggText=hs;
				this.ggTextDiv.innerHTML=hs;
				if (this.ggUpdatePosition) this.ggUpdatePosition();
			}
		}
		me._obst_gemse.ggUpdateText();
		el.appendChild(els);
		me._obst_gemse.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._obst_gemse.logicBlock_scaling = function() {
			var newLogicStateScaling;
			if (
				((me.elementMouseOver['obst_gemse'] == true))
			)
			{
				newLogicStateScaling = 0;
			}
			else {
				newLogicStateScaling = -1;
			}
			if (me._obst_gemse.ggCurrentLogicStateScaling != newLogicStateScaling) {
				me._obst_gemse.ggCurrentLogicStateScaling = newLogicStateScaling;
				me._obst_gemse.style.transition='transform 200ms ease 0ms';
				if (me._obst_gemse.ggCurrentLogicStateScaling == 0) {
					me._obst_gemse.ggParameter.sx = 1.05;
					me._obst_gemse.ggParameter.sy = 1.05;
					me._obst_gemse.style.transform=parameterToTransform(me._obst_gemse.ggParameter);
					setTimeout(function() {skin.updateSize(me._obst_gemse);}, 250);
				}
				else {
					me._obst_gemse.ggParameter.sx = 1;
					me._obst_gemse.ggParameter.sy = 1;
					me._obst_gemse.style.transform=parameterToTransform(me._obst_gemse.ggParameter);
					setTimeout(function() {skin.updateSize(me._obst_gemse);}, 250);
				}
			}
		}
		me._obst_gemse.logicBlock_scaling();
		me._obst_gemse.onclick=function (e) {
			player.openNext("{node5}","-95\/0\/100");
		}
		me._obst_gemse.onmouseenter=function (e) {
			me.elementMouseOver['obst_gemse']=true;
			me._obst_gemse.logicBlock_scaling();
		}
		me._obst_gemse.onmouseleave=function (e) {
			me.elementMouseOver['obst_gemse']=false;
			me._obst_gemse.logicBlock_scaling();
		}
		me._obst_gemse.ggUpdatePosition=function (useTransition) {
		}
		me._sol_menu.appendChild(me._obst_gemse);
		el=me._kosmetik=document.createElement('div');
		els=me._kosmetik__text=document.createElement('div');
		el.className='ggskin ggskin_textdiv';
		el.ggTextDiv=els;
		el.ggId="Kosmetik";
		el.ggDx=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_text ";
		el.ggType='text';
		hs ='';
		hs+='border : 0px solid #000000;';
		hs+='color : rgba(255,255,255,1);';
		hs+='cursor : pointer;';
		hs+='height : 20px;';
		hs+='left : calc(50% - ((90% + 0px) / 2) + 0px);';
		hs+='position : absolute;';
		hs+='top : 86px;';
		hs+='visibility : inherit;';
		hs+='width : 90%;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		hs ='';
		hs += 'box-sizing: border-box;';
		hs+='width: 100%;';
		hs+='height: 100%;';
		hs+='font-size: 14px;';
		hs+='font-weight: bold;';
		hs+='text-align: center;';
		hs+='white-space: pre;';
		hs+='padding: 0px;';
		hs+='overflow: hidden;';
		hs+='overflow-y: auto;';
		els.setAttribute('style',hs);
		me._kosmetik.ggUpdateText=function() {
			var params = [];
			var hs = player._("Kosmetik", params);
			if (hs!=this.ggText) {
				this.ggText=hs;
				this.ggTextDiv.innerHTML=hs;
				if (this.ggUpdatePosition) this.ggUpdatePosition();
			}
		}
		me._kosmetik.ggUpdateText();
		el.appendChild(els);
		me._kosmetik.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._kosmetik.logicBlock_scaling = function() {
			var newLogicStateScaling;
			if (
				((me.elementMouseOver['kosmetik'] == true))
			)
			{
				newLogicStateScaling = 0;
			}
			else {
				newLogicStateScaling = -1;
			}
			if (me._kosmetik.ggCurrentLogicStateScaling != newLogicStateScaling) {
				me._kosmetik.ggCurrentLogicStateScaling = newLogicStateScaling;
				me._kosmetik.style.transition='transform 200ms ease 0ms';
				if (me._kosmetik.ggCurrentLogicStateScaling == 0) {
					me._kosmetik.ggParameter.sx = 1.05;
					me._kosmetik.ggParameter.sy = 1.05;
					me._kosmetik.style.transform=parameterToTransform(me._kosmetik.ggParameter);
					setTimeout(function() {skin.updateSize(me._kosmetik);}, 250);
				}
				else {
					me._kosmetik.ggParameter.sx = 1;
					me._kosmetik.ggParameter.sy = 1;
					me._kosmetik.style.transform=parameterToTransform(me._kosmetik.ggParameter);
					setTimeout(function() {skin.updateSize(me._kosmetik);}, 250);
				}
			}
		}
		me._kosmetik.logicBlock_scaling();
		me._kosmetik.onclick=function (e) {
			player.openNext("{node33}","-108\/0\/100");
		}
		me._kosmetik.onmouseenter=function (e) {
			me.elementMouseOver['kosmetik']=true;
			me._kosmetik.logicBlock_scaling();
		}
		me._kosmetik.onmouseleave=function (e) {
			me.elementMouseOver['kosmetik']=false;
			me._kosmetik.logicBlock_scaling();
		}
		me._kosmetik.ggUpdatePosition=function (useTransition) {
		}
		me._sol_menu.appendChild(me._kosmetik);
		el=me._fleischwaren=document.createElement('div');
		els=me._fleischwaren__text=document.createElement('div');
		el.className='ggskin ggskin_textdiv';
		el.ggTextDiv=els;
		el.ggId="Fleischwaren";
		el.ggDx=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_text ";
		el.ggType='text';
		hs ='';
		hs+='border : 0px solid #000000;';
		hs+='color : rgba(255,255,255,1);';
		hs+='cursor : pointer;';
		hs+='height : 20px;';
		hs+='left : calc(50% - ((90% + 0px) / 2) + 0px);';
		hs+='position : absolute;';
		hs+='top : 56px;';
		hs+='visibility : inherit;';
		hs+='width : 90%;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		hs ='';
		hs += 'box-sizing: border-box;';
		hs+='width: 100%;';
		hs+='height: 100%;';
		hs+='font-size: 14px;';
		hs+='font-weight: bold;';
		hs+='text-align: center;';
		hs+='white-space: pre;';
		hs+='padding: 0px;';
		hs+='overflow: hidden;';
		hs+='overflow-y: auto;';
		els.setAttribute('style',hs);
		me._fleischwaren.ggUpdateText=function() {
			var params = [];
			var hs = player._("Fleischwaren", params);
			if (hs!=this.ggText) {
				this.ggText=hs;
				this.ggTextDiv.innerHTML=hs;
				if (this.ggUpdatePosition) this.ggUpdatePosition();
			}
		}
		me._fleischwaren.ggUpdateText();
		el.appendChild(els);
		me._fleischwaren.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._fleischwaren.logicBlock_scaling = function() {
			var newLogicStateScaling;
			if (
				((me.elementMouseOver['fleischwaren'] == true))
			)
			{
				newLogicStateScaling = 0;
			}
			else {
				newLogicStateScaling = -1;
			}
			if (me._fleischwaren.ggCurrentLogicStateScaling != newLogicStateScaling) {
				me._fleischwaren.ggCurrentLogicStateScaling = newLogicStateScaling;
				me._fleischwaren.style.transition='transform 200ms ease 0ms';
				if (me._fleischwaren.ggCurrentLogicStateScaling == 0) {
					me._fleischwaren.ggParameter.sx = 1.05;
					me._fleischwaren.ggParameter.sy = 1.05;
					me._fleischwaren.style.transform=parameterToTransform(me._fleischwaren.ggParameter);
					setTimeout(function() {skin.updateSize(me._fleischwaren);}, 250);
				}
				else {
					me._fleischwaren.ggParameter.sx = 1;
					me._fleischwaren.ggParameter.sy = 1;
					me._fleischwaren.style.transform=parameterToTransform(me._fleischwaren.ggParameter);
					setTimeout(function() {skin.updateSize(me._fleischwaren);}, 250);
				}
			}
		}
		me._fleischwaren.logicBlock_scaling();
		me._fleischwaren.onclick=function (e) {
			player.openNext("{node11}","34\/0\/100");
		}
		me._fleischwaren.onmouseenter=function (e) {
			me.elementMouseOver['fleischwaren']=true;
			me._fleischwaren.logicBlock_scaling();
		}
		me._fleischwaren.onmouseleave=function (e) {
			me.elementMouseOver['fleischwaren']=false;
			me._fleischwaren.logicBlock_scaling();
		}
		me._fleischwaren.ggUpdatePosition=function (useTransition) {
		}
		me._sol_menu.appendChild(me._fleischwaren);
		el=me._weine_spirituosen=document.createElement('div');
		els=me._weine_spirituosen__text=document.createElement('div');
		el.className='ggskin ggskin_textdiv';
		el.ggTextDiv=els;
		el.ggId="Weine & Spirituosen";
		el.ggDx=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_text ";
		el.ggType='text';
		hs ='';
		hs+='border : 0px solid #000000;';
		hs+='color : rgba(255,255,255,1);';
		hs+='cursor : pointer;';
		hs+='height : 20px;';
		hs+='left : calc(50% - ((90% + 0px) / 2) + 0px);';
		hs+='position : absolute;';
		hs+='top : 26px;';
		hs+='visibility : inherit;';
		hs+='width : 90%;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		hs ='';
		hs += 'box-sizing: border-box;';
		hs+='width: 100%;';
		hs+='height: 100%;';
		hs+='font-size: 14px;';
		hs+='font-weight: bold;';
		hs+='text-align: center;';
		hs+='white-space: pre;';
		hs+='padding: 0px;';
		hs+='overflow: hidden;';
		hs+='overflow-y: auto;';
		els.setAttribute('style',hs);
		me._weine_spirituosen.ggUpdateText=function() {
			var params = [];
			var hs = player._("Weine & Spirituosen", params);
			if (hs!=this.ggText) {
				this.ggText=hs;
				this.ggTextDiv.innerHTML=hs;
				if (this.ggUpdatePosition) this.ggUpdatePosition();
			}
		}
		me._weine_spirituosen.ggUpdateText();
		el.appendChild(els);
		me._weine_spirituosen.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._weine_spirituosen.logicBlock_scaling = function() {
			var newLogicStateScaling;
			if (
				((me.elementMouseOver['weine_spirituosen'] == true))
			)
			{
				newLogicStateScaling = 0;
			}
			else {
				newLogicStateScaling = -1;
			}
			if (me._weine_spirituosen.ggCurrentLogicStateScaling != newLogicStateScaling) {
				me._weine_spirituosen.ggCurrentLogicStateScaling = newLogicStateScaling;
				me._weine_spirituosen.style.transition='transform 200ms ease 0ms';
				if (me._weine_spirituosen.ggCurrentLogicStateScaling == 0) {
					me._weine_spirituosen.ggParameter.sx = 1.05;
					me._weine_spirituosen.ggParameter.sy = 1.05;
					me._weine_spirituosen.style.transform=parameterToTransform(me._weine_spirituosen.ggParameter);
					setTimeout(function() {skin.updateSize(me._weine_spirituosen);}, 250);
				}
				else {
					me._weine_spirituosen.ggParameter.sx = 1;
					me._weine_spirituosen.ggParameter.sy = 1;
					me._weine_spirituosen.style.transform=parameterToTransform(me._weine_spirituosen.ggParameter);
					setTimeout(function() {skin.updateSize(me._weine_spirituosen);}, 250);
				}
			}
		}
		me._weine_spirituosen.logicBlock_scaling();
		me._weine_spirituosen.onclick=function (e) {
			player.openNext("{node29}","52.81\/0\/100");
		}
		me._weine_spirituosen.onmouseenter=function (e) {
			me.elementMouseOver['weine_spirituosen']=true;
			me._weine_spirituosen.logicBlock_scaling();
		}
		me._weine_spirituosen.onmouseleave=function (e) {
			me.elementMouseOver['weine_spirituosen']=false;
			me._weine_spirituosen.logicBlock_scaling();
		}
		me._weine_spirituosen.ggUpdatePosition=function (useTransition) {
		}
		me._sol_menu.appendChild(me._weine_spirituosen);
		me._solmenu.appendChild(me._sol_menu);
		me.divSkin.appendChild(me._solmenu);
		el=me._sosyalmedya=document.createElement('div');
		el.ggId="Sosyalmedya";
		el.ggDy=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=false;
		el.className="ggskin ggskin_container ";
		el.ggType='container';
		hs ='';
		hs+='height : 250px;';
		hs+='position : absolute;';
		hs+='right : -204px;';
		hs+='top : calc(50% - ((250px + 0px) / 2) + 0px);';
		hs+='visibility : hidden;';
		hs+='width : 250px;';
		hs+='pointer-events:none;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me._sosyalmedya.ggIsActive=function() {
			return false;
		}
		el.ggElementNodeId=function() {
			return player.getCurrentNode();
		}
		me._sosyalmedya.logicBlock_position = function() {
			var newLogicStatePosition;
			if (
				((player.getVariableValue('Sosyalmedya') == true))
			)
			{
				newLogicStatePosition = 0;
			}
			else {
				newLogicStatePosition = -1;
			}
			if (me._sosyalmedya.ggCurrentLogicStatePosition != newLogicStatePosition) {
				me._sosyalmedya.ggCurrentLogicStatePosition = newLogicStatePosition;
				me._sosyalmedya.style.transition='right 500ms ease 0ms, top 500ms ease 0ms';
				if (me._sosyalmedya.ggCurrentLogicStatePosition == 0) {
					me._sosyalmedya.style.right='-150px';
					me._sosyalmedya.style.top = 'calc(50% - (250px / 2))';
				}
				else {
					me._sosyalmedya.style.right='-204px';
					me._sosyalmedya.style.top='calc(50% - ((250px + 0px) / 2) + 0px)';
				}
			}
		}
		me._sosyalmedya.logicBlock_position();
		me._sosyalmedya.logicBlock_visible = function() {
			var newLogicStateVisible;
			if (
				((player.getVariableValue('info') == true))
			)
			{
				newLogicStateVisible = 0;
			}
			else {
				newLogicStateVisible = -1;
			}
			if (me._sosyalmedya.ggCurrentLogicStateVisible != newLogicStateVisible) {
				me._sosyalmedya.ggCurrentLogicStateVisible = newLogicStateVisible;
				me._sosyalmedya.style.transition='right 500ms ease 0ms, top 500ms ease 0ms';
				if (me._sosyalmedya.ggCurrentLogicStateVisible == 0) {
					me._sosyalmedya.style.visibility=(Number(me._sosyalmedya.style.opacity)>0||!me._sosyalmedya.style.opacity)?'inherit':'hidden';
					me._sosyalmedya.ggVisible=true;
				}
				else {
					me._sosyalmedya.style.visibility="hidden";
					me._sosyalmedya.ggVisible=false;
				}
			}
		}
		me._sosyalmedya.logicBlock_visible();
		me._sosyalmedya.ggUpdatePosition=function (useTransition) {
		}
		el=me._sosyalmedyabuton=document.createElement('div');
		el.ggId="sosyalmedyabuton";
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_rectangle ";
		el.ggType='rectangle';
		hs ='';
		hs+='background : rgba(0,0,0,0.784314);';
		hs+='border : 2px solid #ffffff;';
		hs+='bottom : 62px;';
		hs+='cursor : pointer;';
		hs+='height : 40px;';
		hs+='left : 5px;';
		hs+='position : absolute;';
		hs+='visibility : inherit;';
		hs+='width : 40px;';
		hs+='pointer-events:auto;';
		hs+='border-radius: 7px 0px 0px 7px;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me._sosyalmedyabuton.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._sosyalmedyabuton.logicBlock_backgroundcolor = function() {
			var newLogicStateBackgroundColor;
			if (
				((me.elementMouseOver['sosyalmedyabuton'] == true))
			)
			{
				newLogicStateBackgroundColor = 0;
			}
			else {
				newLogicStateBackgroundColor = -1;
			}
			if (me._sosyalmedyabuton.ggCurrentLogicStateBackgroundColor != newLogicStateBackgroundColor) {
				me._sosyalmedyabuton.ggCurrentLogicStateBackgroundColor = newLogicStateBackgroundColor;
				me._sosyalmedyabuton.style.transition='background-color 0s';
				if (me._sosyalmedyabuton.ggCurrentLogicStateBackgroundColor == 0) {
					me._sosyalmedyabuton.style.backgroundColor="rgba(70,65,95,1)";
				}
				else {
					me._sosyalmedyabuton.style.backgroundColor="rgba(0,0,0,0.784314)";
				}
			}
		}
		me._sosyalmedyabuton.logicBlock_backgroundcolor();
		me._sosyalmedyabuton.onclick=function (e) {
			player.setVariableValue('Sosyalmedya', !player.getVariableValue('Sosyalmedya'));
			player.setVariableValue('infoklasor', false);
			player.setVariableValue('altmenu', false);
			player.setVariableValue('solmenuklasor', false);
		}
		me._sosyalmedyabuton.onmouseenter=function (e) {
			me.elementMouseOver['sosyalmedyabuton']=true;
			me._sosyalmedyabuton.logicBlock_backgroundcolor();
		}
		me._sosyalmedyabuton.onmouseleave=function (e) {
			me.elementMouseOver['sosyalmedyabuton']=false;
			me._sosyalmedyabuton.logicBlock_backgroundcolor();
		}
		me._sosyalmedyabuton.ggUpdatePosition=function (useTransition) {
		}
		el=me._svg_3=document.createElement('div');
		els=me._svg_3__img=document.createElement('img');
		els.className='ggskin ggskin_svg';
		hs='data:image/svg+xml;base64,PHN2ZyBpZD0iTGF5ZXJfMSIgdmlld0JveD0iMCAwIDUxMS45MjYgNTExLjkyNiIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB3aWR0aD0iNTEyIiBlbmFibGUtYmFja2dyb3VuZD0ibmV3IDAgMCA1MTEuOTI2IDUxMS45MjYiIGhlaWdodD0iNTEyIj4KIDxwYXRoIGQ9Im0yMzcuMzAyIDI2OS4wMDFjOC4wMjYgNS44IDE3Ljg5NSA5LjIyIDI4LjU2NiA5LjIyaDkxLjI4djQ0LjI2bDU3Ljg2Mi00NC4yNmgyNC45NjJjMjYuOTA5IDAgNDguNzIzLTIxLjc0NyA0OC43MjMtNDguNTc0di0xNzMuNTczYzAtMjYuODI3LTIxLjgxNC00OC41NzQtNDguNzIzLTQ4LjU3NGgtMTc0LjEwNG'+
			'MtMjYuOTA5IDAtNDguNzIzIDIxLjc0Ny00OC43MjMgNDguNTc0djIxMi45Mjd6IiBmaWxsPSIjZjdmM2YxIi8+CiA8cGF0aCBkPSJtNDM5Ljk3MiA3LjVoLTQxLjczMmMyNi45MDkgMCA0OC43MjMgMjEuNzQ4IDQ4LjcyMyA0OC41NzR2MTczLjU3M2MwIDI2LjgyNy0yMS44MTQgNDguNTc0LTQ4LjcyMyA0OC41NzRoLTI0Ljk2MmwtMTYuMTMgMTIuMzM4djMxLjkyMmw1Ny44NjItNDQuMjZoMjQuOTYyYzI2LjkwOSAwIDQ4LjcyMy0yMS43NDcgNDguNzIzLTQ4LjU3NHYtMTczLjU3M2MuMDAxLTI2LjgyNi0yMS44MTMtNDguNTc0LTQ4LjcyMy00OC41NzR6IiBmaWxsPSIjZWJlMWRjIi8+CiA8cGF0'+
			'aCBkPSJtMzE1LjM3NiAyMDcuMDIzIDUuMDIyIDQuMDY1YzcuOTYyIDYuNDQ1IDE3Ljg5NiA5Ljk2MiAyOC4xMzkgOS45NjJoNzEuMjkyYzYuNzU4IDAgMTIuMi01LjYzOCAxMS44NzgtMTIuNDY3LS4zMDEtNi4zOTYuMDE0LTY0LjY0NS4wMTQtNzEuMjEycy01LjMyNC0xMS44OTItMTEuODkyLTExLjg5MmwtNDguMzQzLS4xNDYgNS45MTktMTQuMDE4YzYuMTUtMTQuNTY2IDUuMTU2LTMxLjE2OC0yLjY4OS00NC44OTYtMi4yMTgtMy44ODItNy4yMDktNS4xNTYtMTEuMDE3LTIuODEzLTIuMzQgMS40NC0zLjc2NiAzLjk5MS0zLjc2NiA2LjczOSAwIDEyLjU3MS00LjU5IDI0LjcwOS0xMi45MDcgMz'+
			'QuMTM1bC0zMC44MjYgMzQuODgxaC0xMS4yMzh2NjcuNjYxaDEwLjQxNHoiIGZpbGw9IiNmZmQzNmMiLz4KIDxwYXRoIGQ9Im0zMTAuNTY0IDIxNy43NWgtMzIuNTQ5Yy0yLjE1MSAwLTMuODk2LTEuNzQ0LTMuODk2LTMuODk2di04Mi45NzRjMC0yLjE1MiAxLjc0NC0zLjg5NiAzLjg5Ni0zLjg5NmgzMi41NDljMi4xNTIgMCAzLjg5NiAxLjc0NCAzLjg5NiAzLjg5NnY4Mi45NzRjLS4wMDEgMi4xNTEtMS43NDUgMy44OTYtMy44OTYgMy44OTZ6IiBmaWxsPSIjOGVlNmYzIi8+CiA8cGF0aCBkPSJtMjM3LjM3MiAzNTUuOTg3di0xNzUuMTgyYzAtMjEuMTU1LTE3LjIwMi0zOC4zMDUtMzguNDIzLTM4'+
			'LjMwNWgtMTM3LjI5NmMtMjEuMjIgMC0zOC40MjMgMTcuMTUtMzguNDIzIDM4LjMwNXYxMzYuODc3YzAgMjEuMTU1IDE3LjIwMiAzOC4zMDUgMzguNDIzIDM4LjMwNWg3NS40MjV2MzUuMjNsNDUuNjI5LTM1LjIzeiIgZmlsbD0iIzRlZDVlYSIvPgogPHBhdGggZD0ibTE5OC45NSAxNDIuNWgtNTQuNDA5YzIxLjIyIDAgMzguNDIzIDE3LjE1IDM4LjQyMyAzOC4zMDV2MTc1LjE4Mmg1NC40MDl2LTE3NS4xODJjLS4wMDEtMjEuMTU1LTE3LjIwMy0zOC4zMDUtMzguNDIzLTM4LjMwNXoiIGZpbGw9IiM2MmE2ZmQiLz4KIDxwYXRoIGQ9Im0zMTEuNjk3IDMyNy45OThoLTk3LjQzMmMtMTUuMDU5IDAtMj'+
			'cuMjY3IDEyLjE3LTI3LjI2NyAyNy4xODN2OTcuMTM0YzAgMTUuMDEzIDEyLjIwOCAyNy4xODMgMjcuMjY3IDI3LjE4M2g1My41MjV2MjUuMDAybDMyLjM4MS0yNS4wMDFoMTEuNTI2YzE1LjA1OSAwIDI3LjI2Ny0xMi4xNyAyNy4yNjctMjcuMTgzdi05Ny4xMzRjLS4wMDEtMTUuMDEzLTEyLjIwOS0yNy4xODQtMjcuMjY3LTI3LjE4NHoiIGZpbGw9IiNmYTkwODQiLz4KIDxwYXRoIGQ9Im0zMTEuNjk3IDMyNy45OThoLTQyYzE1LjA1OSAwIDI3LjI2NyAxMi4xNyAyNy4yNjcgMjcuMTgzdjk3LjEzNWMwIDE1LjAxMy0xMi4yMDggMjcuMTgzLTI3LjI2NyAyNy4xODNoLTEuOTA3djI1LjAwMWwzMi4z'+
			'ODEtMjUuMDAxaDExLjUyNmMxNS4wNTkgMCAyNy4yNjctMTIuMTcgMjcuMjY3LTI3LjE4M3YtOTcuMTM1Yy0uMDAxLTE1LjAxMi0xMi4yMDgtMjcuMTgzLTI3LjI2Ny0yNy4xODN6IiBmaWxsPSIjZmY2Y2I1Ii8+CiA8cGF0aCBkPSJtMjYyLjk4IDQzNi43NTNjMjMuNDQ2LTEyLjQyOSAzNS41OTMtMjMuMDA1IDM1LjU5My0zOS4zODkgMC0yMi41OTktMjcuNjg0LTI4LjI0OS0zNS41OTMtMTEuMjk5LTkuMDQtMTcuNTE0LTM1LjU5My0xMS4yOTktMzUuNTkzIDExLjI5OSAwIDE2LjM4NCAxMi4xNDcgMjYuOTU5IDM1LjU5MyAzOS4zODl6IiBmaWxsPSIjZjdmM2YxIi8+CiA8cGF0aCBkPSJtNDM5Lj'+
			'k3MyAwaC0yMi4wMWMtOS42NzUgMC05LjY3NSAxNSAwIDE1aDIyLjAxYzIyLjczIDAgNDEuMjIzIDE4LjQyNiA0MS4yMjMgNDEuMDc0djE3My41NzJjMCAyMi42NDktMTguNDkyIDQxLjA3NS00MS4yMjMgNDEuMDc1aC0yNC45NjNjLTEuNjQ3IDAtMy4yNDguNTQyLTQuNTU3IDEuNTQzbC00NS44MDYgMzUuMDM4di0yOS4wODFjMC00LjE0Mi0zLjM1Ny03LjUtNy41LTcuNWgtOTEuMjhjLTcuNDc1IDAtMTQuNjU5LTEuOTczLTIwLjk5NS01LjcyNHYtODQuMTkyYzAtMTUuNzctOC4wMzItMjkuNzAzLTIwLjIyOS0zNy45NDZ2LTg2Ljc4NWMwLTIyLjY0OCAxOC40OTMtNDEuMDc0IDQxLjIyNC00MS4w'+
			'NzRoMTA1LjA5NmM5LjY3NCAwIDkuNjc0LTE1IDAtMTVoLTEwNS4wOTZjLTMxLjAwMiAwLTU2LjIyNCAyNS4xNTUtNTYuMjI0IDU2LjA3NHY4MC4xOTNjLTMuNDM0LS44Mi03LjAxMi0xLjI2Ny0xMC42OTQtMS4yNjdoLTEzNy4yOTZjLTI1LjMyMSAwLTQ1LjkyMiAyMC41NDgtNDUuOTIyIDQ1LjgwNXYxNi4xOTVjMCA5LjY3NCAxNSA5LjY3NCAxNSAwdi0xNi4xOTVjMC0xNi45ODYgMTMuODcxLTMwLjgwNSAzMC45MjItMzAuODA1aDEzNy4yOTdjMTcuMDUxIDAgMzAuOTIzIDEzLjgxOSAzMC45MjMgMzAuODA1djg3LjE3OGMtLjA5LjY2Mi0uMDg2IDEuMzI5IDAgMS45ODZ2NDcuNzEyYzAgLjk0My'+
			'0uMDU3IDEuODgyLS4xNDIgMi44MTZoLTE1LjQ2N2MtMTcuMDQzIDAtMzEuMjUxIDEyLjMwMS0zNC4xOTcgMjguNDY4LS42ODIuMjU3LTEuMzM3LjYxNi0xLjk0NCAxLjA4NGwtMzMuNTQ1IDI1LjkwMXYtMTkuOTY0YzAtNC4xNDItMy4zNTctNy41LTcuNS03LjVoLTc1LjQyNWMtMTcuMDUxIDAtMzAuOTIyLTEzLjgxOS0zMC45MjItMzAuODA1di03NS42ODFjMC05LjY3NC0xNS05LjY3NC0xNSAwdjc1LjY4MmMwIDI1LjI1NyAyMC42MDEgNDUuODA1IDQ1LjkyMiA0NS44MDVoNjcuOTI2djI3LjczYzAgNi4wMTYgNy4zMDUgOS42MjUgMTIuMDg0IDUuOTM3bDM3LjgzNS0yOS4yMTN2ODQuMzc1YzAg'+
			'MTkuMTI1IDE1LjU5NyAzNC42ODMgMzQuNzY3IDM0LjY4M2g0Ni4wMjV2MTcuNTAxYzAgNi4wMTQgNy4zMDUgOS42MjcgMTIuMDgzIDUuOTM3bDMwLjM1Ni0yMy40MzhoOC45NjhjMTkuMTcgMCAzNC43NjctMTUuNTU5IDM0Ljc2Ny0zNC42ODN2LTEzLjMxNmMwLTkuNjc0LTE1LTkuNjc0LTE1IDB2MTMuMzE2YzAgMTAuODU0LTguODY3IDE5LjY4My0xOS43NjcgMTkuNjgzaC0xMS41MjdjLTEuNjU5IDAtMy4yNzEuNTUtNC41ODMgMS41NjNsLTIwLjI5OCAxNS42NzF2LTkuNzM1YzAtNC4xNDItMy4zNTctNy41LTcuNS03LjVoLTUzLjUyNWMtMTAuODk5IDAtMTkuNzY3LTguODMtMTkuNzY3LTE5Lj'+
			'Y4M3YtOTcuMTM0YzAtMTAuODU0IDguODY3LTE5LjY4MyAxOS43NjctMTkuNjgzaDk3LjQzM2MxMC44OTkgMCAxOS43NjcgOC44MyAxOS43NjcgMTkuNjgzdjM2LjgxOWMwIDkuNjc0IDE1IDkuNjc0IDE1IDB2LTM2LjgxOGMwLTE5LjEyNS0xNS41OTctMzQuNjgzLTM0Ljc2Ny0zNC42ODNoLTY2LjkxYy4wNTctLjkzNy4wODYtMzguODE4LjA4Ni0zOC44MTggNi42MTMgMi42NTkgMTMuNzAzIDQuMDQxIDIwLjk5NSA0LjA0MWg4My43OHYzNi43NmMwIDYuMDAxIDcuMjc0IDkuNjE0IDEyLjA1NyA1Ljk1N2w1NS44NDYtNDIuNzE3aDIyLjQyM2MzMS4wMDEgMCA1Ni4yMjMtMjUuMTU1IDU2LjIyMy01'+
			'Ni4wNzV2LTE3My41NzNjLS4wMDEtMzAuOTE5LTI1LjIyMy01Ni4wNzQtNTYuMjI0LTU2LjA3NHoiLz4KIDxwYXRoIGQ9Im0zNzEuNjYgNTUuNDEyYy05LjUyMy0yLjQzMS0xOS4yMjcgNS4wOTMtMTkuMjI3IDE0LjkzMyAwIDEwLjc1MS0zLjkxOCAyMS4xMTItMTEuMDI3IDI5LjE2OWwtMjAuNjY0IDIzLjM4M2MtMS4zMzgtMi4wNTMtMy42NS0zLjQxMi02LjI4My0zLjQxMmgtNDAuMzRjLTQuMTQzIDAtNy41IDMuMzU4LTcuNSA3LjV2OTAuNzY1YzAgNC4xNDIgMy4zNTcgNy41IDcuNSA3LjVoNDAuMzRjMy4wMzEgMCA1LjYzNS0xLjgwMSA2LjgxOC00LjM4NyA4LjE2NyA0Ljk5IDE3LjYzMSA3Lj'+
			'Y4OCAyNy4yNiA3LjY4OGg3MS4yOTJjMTAuODk0IDAgMTkuODgxLTkuNDUzIDE5LjM3LTIwLjMxOS0uMjI3LTQuODEyLjAyMS02OS40MjUuMDIxLTcwLjg2IDAtMTAuNjkyLTguNjk5LTE5LjM5Mi0xOS4zNjktMTkuMzkybC0zNy4wNzMtLjExMSAxLjUzNS0zLjYzNWM3LjAxNS0xNi42MTMgNS44Ni0zNS44NzctMy4wODYtNTEuNTM0LTIuMDg4LTMuNjU4LTUuNDg3LTYuMjQ1LTkuNTY3LTcuMjg4LTQuMDgyLTEuMDQyIDQuMDggMS4wNDMgMCAwLTkuNTIyLTIuNDMxIDQuMDggMS4wNDMgMCAwem0tNjQuNzAxIDE1NC44MzhoLTI1LjM0di03NS43NjVoMjUuMzR6bTExMi44Ny03Ny4yNzFjMi40MjIg'+
			'MCA0LjM5MiAxLjk3IDQuMzkyIDQuMzkyIDAgMS40MjctLjAxNSA1LjMtLjAzNSAxMC41NTEtLjExMSAyOC45OTItLjE4NSA1Ni40NS4wMjkgNjEuMDE0LjA3OCAxLjY0Ny0uNzIzIDIuNzQ1LTEuMjA3IDMuMjUzLS44MzguODc4LTEuOTY3IDEuMzYxLTMuMTc5IDEuMzYxaC03MS4yOTJjLTguNDk4IDAtMTYuODE1LTIuOTQ1LTIzLjQyMS04LjI5MmwtMy4xNTctMi41NTZ2LTU4LjUzMWwzMC42OTEtMzQuNzI5YzkuNTMzLTEwLjgwNCAxNC43ODMtMjQuNjg5IDE0Ljc4My0zOS4wOTggMC0uNDI0LjU3OS0uNTM0Ljc3MS0uMjA0IDYuNjQyIDExLjYyMyA3LjQ5OCAyNS45MjQgMi4yOTEgMzguMjU3bC'+
			'01LjkxOSAxNC4wMTljLS45NzcgMi4zMTMtLjczMSA0Ljk2LjY1MiA3LjA1NCAxLjM4NSAyLjA5NCAzLjcyNSAzLjM1NiA2LjIzNCAzLjM2NHoiLz4KIDxwYXRoIGQ9Im03OS45NTEgMjYwLjQ5OGMtNC4xNDMgMC03LjUgMy4zNTgtNy41IDcuNXMzLjM1NyA3LjUgNy41IDcuNWgyMi4xMDhsLTQuMTMgMjQuOTc5Yy0uNjc2IDQuMDg2IDIuMDkgNy45NDcgNi4xNzYgOC42MjMuNDE1LjA2OS44MjYuMTAyIDEuMjMyLjEwMiAzLjYwNCAwIDYuNzgzLTIuNjA1IDcuMzkxLTYuMjc4bDQuNTM0LTI3LjQyNWgxOC4wOTNsLTQuMTMgMjQuOTc5Yy0uNjc2IDQuMDg2IDIuMDkgNy45NDcgNi4xNzYgOC42MjMu'+
			'NDE1LjA2OS44MjYuMTAyIDEuMjMyLjEwMiAzLjYwNCAwIDYuNzgzLTIuNjA1IDcuMzkxLTYuMjc4bDQuNTM0LTI3LjQyNWgzMC4wOTNjNC4xNDMgMCA3LjUtMy4zNTggNy41LTcuNXMtMy4zNTctNy41LTcuNS03LjVoLTI3LjYxM2wzLjAyNS0xOC4yOTZoMjQuNTg4YzQuMTQzIDAgNy41LTMuMzU4IDcuNS03LjVzLTMuMzU3LTcuNS03LjUtNy41aC0yMi4xMDhsNC4xMy0yNC45NzljLjY3Ni00LjA4Ni0yLjA5LTcuOTQ3LTYuMTc2LTguNjIzLTQuMDkxLS42NzgtNy45NDcgMi4wOS04LjYyMyA2LjE3NmwtNC41MzQgMjcuNDI1aC0xOC4wOTNsNC4xMy0yNC45NzljLjY3Ni00LjA4Ni0yLjA5LTcuOT'+
			'Q3LTYuMTc2LTguNjIzLTQuMDk2LS42NzgtNy45NDYgMi4wOS04LjYyMyA2LjE3NmwtNC41MzQgMjcuNDI1aC0zMC4wOTNjLTQuMTQzIDAtNy41IDMuMzU4LTcuNSA3LjVzMy4zNTcgNy41IDcuNSA3LjVoMjcuNjEzbC0zLjAyNSAxOC4yOTZ6bTQyLjgxNy0xOC4yOTZoMTguMDkzbC0zLjAyNSAxOC4yOTZoLTE4LjA5M3oiLz4KIDxwYXRoIGQ9Im0yNjIuODkgMzc0LjE5NmMtNi4wNTYtNC45ODYtMTQuMTEzLTYuOTUzLTIyLjE5NS00Ljk4OC0xMC4zNTcgMi41MTUtMjAuODA4IDEyLjE5Ny0yMC44MDggMjguMTU2IDAgOS45MzMgMy42MjUgMTguNTU1IDExLjA4MiAyNi4zNTkgNi4wOTEgNi4zNzUg'+
			'MTQuODgxIDEyLjQzNyAyOC40OTkgMTkuNjU3IDEuMDk5LjU4MyAyLjMwNi44NzQgMy41MTMuODc0czIuNDE0LS4yOTEgMy41MTMtLjg3NGMyMy43NTgtMTIuNTk1IDM5LjU4LTI1LjI0IDM5LjU4LTQ2LjAxNiAwLTE2LjA0Ni0xMC44MjItMjUuNjI5LTIxLjU0OC0yOC4wMDgtOC4wNTgtMS43ODgtMTUuODcuMTEtMjEuNjM2IDQuODR6bTI4LjE4MyAyMy4xNjhjMCAxMS4yMDYtNy40MzMgMTkuNDkzLTI4LjA5MyAzMC44NjYtMjAuNjYtMTEuMzc0LTI4LjA5NC0xOS42NjEtMjguMDk0LTMwLjg2NiAwLTguMzM4IDQuODI4LTEyLjQ4MiA5LjM0Ny0xMy41OC44MzMtLjIwMiAxLjcyNS0uMzE2IDIuNj'+
			'QyLS4zMTYgMy4zOTkgMCA3LjEzNiAxLjU3IDkuNDQgNi4wMzcgMS4zMTMgMi41NDIgMy45NjcgNC4xMTggNi44MTQgNC4wNTkgMi44NTktLjA1NyA1LjQzOC0xLjczNSA2LjY0Ny00LjMyNyAyLjQyNy01LjIwMiA3LjUzMS02LjExNyAxMS40OTktNS4yMzYgNC43MzggMS4wNDkgOS43OTggNS4xMTIgOS43OTggMTMuMzYzeiIvPgo8L3N2Zz4K';
		me._svg_3__img.setAttribute('src',hs);
		hs ='';
		hs += 'position: absolute;top: 0px;left: 0px;width: 100%;height: 100%;-webkit-user-drag:none;pointer-events:none;;';
		els.setAttribute('style', hs);
		els['ondragstart']=function() { return false; };
		el.appendChild(els);
		el.ggSubElement = els;
		el.ggId="Svg 3";
		el.ggDx=0;
		el.ggDy=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_svg ";
		el.ggType='svg';
		hs ='';
		hs+='cursor : pointer;';
		hs+='height : 75%;';
		hs+='left : calc(50% - ((75% + 0px) / 2) + 0px);';
		hs+='position : absolute;';
		hs+='top : calc(50% - ((75% + 0px) / 2) + 0px);';
		hs+='visibility : inherit;';
		hs+='width : 75%;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me._svg_3.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._svg_3.ggUpdatePosition=function (useTransition) {
		}
		me._sosyalmedyabuton.appendChild(me._svg_3);
		me._sosyalmedya.appendChild(me._sosyalmedyabuton);
		el=me._sosyalmedyaarkaplan=document.createElement('div');
		el.ggId="SosyalMedyaarkaplan";
		el.ggDy=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_rectangle ";
		el.ggType='rectangle';
		hs ='';
		hs+='background : rgba(0,0,0,0.784314);';
		hs+='border : 2px solid #ffffff;';
		hs+='border-radius : 20px;';
		hs+='cursor : default;';
		hs+='height : 135px;';
		hs+='position : absolute;';
		hs+='right : 0px;';
		hs+='top : calc(50% - ((135px + 4px) / 2) + 0px);';
		hs+='visibility : inherit;';
		hs+='width : 200px;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me._sosyalmedyaarkaplan.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._sosyalmedyaarkaplan.ggUpdatePosition=function (useTransition) {
		}
		el=me._svg_7=document.createElement('div');
		els=me._svg_7__img=document.createElement('img');
		els.className='ggskin ggskin_svg';
		hs='data:image/svg+xml;base64,PHN2ZyBpZD0iQ2FwYV8xIiB2aWV3Qm94PSIwIDAgNTEyIDUxMiIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB3aWR0aD0iNTEyIiBlbmFibGUtYmFja2dyb3VuZD0ibmV3IDAgMCA1MTIgNTEyIiBoZWlnaHQ9IjUxMiI+CiA8Zz4KICA8cGF0aCBkPSJtMzA3Ljc5IDIyMy40NzYtNTMuMTM1IDc4LjQ2Ny03OC41NzMgNzguMThjLTI5LjIyMi0zNy4xMzktNjEuMTMyLTczLjExNi04MC41ODctMTE2LjYzMWw0Mi4zNTItNjQuODc5IDY0Ljk1Ny02Mi42NjhjLTIxLjcxIDI2LjgzMS0yMC4wODkgNjYuMjkzIDQuODY0IDkxLjI0NiAyNi42OTYgMjYuNjk2IDY5Ljk2OCAyNi42OTYgOT'+
			'YuNjYzIDAgMS4yMDMtMS4yMDMgMi4zNjUtMi40NDYgMy40NTktMy43MTV6IiBmaWxsPSIjZWNiNzJiIi8+CiAgPHBhdGggZD0ibTMwOS4wMiAyMjIuMDAzYzIxLjktMjYuODQ0IDIwLjM0Ni02Ni40NDItNC42ODgtOTEuNDYyLTI2LjY5Ni0yNi42OTYtNjkuOTY4LTI2LjY5Ni05Ni42NjMgMC0xLjEyMSAxLjEyMS0yLjE4OSAyLjI3LTMuMjE1IDMuNDQ1bDQ0LjgxMS03Mi44NDcgNjAuNzk1LTUyLjgwOWM0NS40MDcgMTQuMzc0IDgyLjk2NCA0Ni4zNzkgMTA0LjY0OCA4Ny45NzdsLTQ0LjM1MiA3MS41MTZ6IiBmaWxsPSIjNTA4NWY3Ii8+CiAgPHBhdGggZD0ibTIwMi44MDIgMTM1Ljk0OS0xMDcu'+
			'MzEyIDEyNy41NDljLTEwLjY0My0yMy43ODMtMTcuNTYyLTQ5LjgxNy0xOC4yNzYtNzkuNTI5LS4wNTQtMS42ODktLjA4MS0zLjM5MS0uMDgxLTUuMDkzIDAtNDMuNzE4IDE1LjY4NS04My43ODkgNDEuNzQ2LTExNC44NjF6IiBmaWxsPSIjZGEyZjJhIi8+CiAgPHBhdGggZD0ibTIwMi44MDIgMTM1Ljk0OS04My45MjYtNzEuOTM5YzMyLjgxNi0zOS4xMjUgODIuMDYtNjQuMDEgMTM3LjEyNi02NC4wMSAxOC44NDUgMCAzNy4wMDkgMi45MTYgNTQuMDY1IDguMzJ6IiBmaWxsPSIjNDI3NGViIi8+CiAgPHBhdGggZD0ibTQzNC44NjcgMTc4Ljg2NWMwLTI5Ljc3OS03LjI3OC01Ny44NTktMjAuMTUxLT'+
			'gyLjU1OGwtMjM4LjY0IDI4My44MjZjMjcuMTEzIDM0LjQ4OCA1MS44ODcgNjkuOTg1IDYyLjE4MyAxMTMuNDU0LjMzIDEuMzkyLjY4NSAzLjAxOSAxLjA2MyA0Ljg0OCAzLjczMyAxOC4wODYgMjkuNjMgMTguMDg2IDMzLjM2MyAwIC4zNzgtMS44MjkuNzMzLTMuNDU2IDEuMDYzLTQuODQ4IDI3LjQ0OC0xMTUuODkyIDE1Ny44MDctMTc1LjExOCAxNjEuMDQzLTMwOS42MTguMDQ2LTEuNjk2LjA3Ni0zLjM5Ny4wNzYtNS4xMDR6IiBmaWxsPSIjNjBhODUwIi8+CiA8L2c+Cjwvc3ZnPgo=';
		me._svg_7__img.setAttribute('src',hs);
		hs ='';
		hs += 'position: absolute;top: 0px;left: 0px;width: 100%;height: 100%;-webkit-user-drag:none;pointer-events:none;;';
		els.setAttribute('style', hs);
		els['ondragstart']=function() { return false; };
		el.appendChild(els);
		el.ggSubElement = els;
		el.ggId="Svg 7";
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_svg ";
		el.ggType='svg';
		hs ='';
		hs+='bottom : 10px;';
		hs+='cursor : pointer;';
		hs+='height : 30px;';
		hs+='left : 10px;';
		hs+='position : absolute;';
		hs+='visibility : inherit;';
		hs+='width : 30px;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me._svg_7.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._svg_7.logicBlock_scaling = function() {
			var newLogicStateScaling;
			if (
				((me.elementMouseOver['svg_7'] == true))
			)
			{
				newLogicStateScaling = 0;
			}
			else {
				newLogicStateScaling = -1;
			}
			if (me._svg_7.ggCurrentLogicStateScaling != newLogicStateScaling) {
				me._svg_7.ggCurrentLogicStateScaling = newLogicStateScaling;
				me._svg_7.style.transition='transform 200ms ease 0ms';
				if (me._svg_7.ggCurrentLogicStateScaling == 0) {
					me._svg_7.ggParameter.sx = 1.1;
					me._svg_7.ggParameter.sy = 1.1;
					me._svg_7.style.transform=parameterToTransform(me._svg_7.ggParameter);
					setTimeout(function() {skin.updateSize(me._svg_7);}, 250);
				}
				else {
					me._svg_7.ggParameter.sx = 1;
					me._svg_7.ggParameter.sy = 1;
					me._svg_7.style.transform=parameterToTransform(me._svg_7.ggParameter);
					setTimeout(function() {skin.updateSize(me._svg_7);}, 250);
				}
			}
		}
		me._svg_7.logicBlock_scaling();
		me._svg_7.onclick=function (e) {
			player.openUrl(player.getVariableValue('google_map', me.hotspot ? me.hotspot.id : (player.hotspot ? player.hotspot.id : '')),"_blank");
		}
		me._svg_7.onmouseenter=function (e) {
			me.elementMouseOver['svg_7']=true;
			me._svg_7.logicBlock_scaling();
		}
		me._svg_7.onmouseleave=function (e) {
			me.elementMouseOver['svg_7']=false;
			me._svg_7.logicBlock_scaling();
		}
		me._svg_7.ggUpdatePosition=function (useTransition) {
		}
		me._sosyalmedyaarkaplan.appendChild(me._svg_7);
		el=me._svg_5=document.createElement('div');
		els=me._svg_5__img=document.createElement('img');
		els.className='ggskin ggskin_svg';
		hs='data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0nMS4wJyBlbmNvZGluZz0naXNvLTg4NTktMSc/Pgo8IURPQ1RZUEUgc3ZnIFBVQkxJQyAnLS8vVzNDLy9EVEQgU1ZHIDEuMS8vRU4nICdodHRwOi8vd3d3LnczLm9yZy9HcmFwaGljcy9TVkcvMS4xL0RURC9zdmcxMS5kdGQnPgo8IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMTguMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+CjxzdmcgeT0iMHB4IiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTIuMTk2IDExMi4xOTYiIHN0eWxlPSJlbmFibGUtYmFja2dyb3VuZDpuZXcgMCAwIDExMi4xOTYgMT'+
			'EyLjE5NjsiIGlkPSJDYXBhXzEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjBweCI+CiA8Zz4KICA8Y2lyY2xlIGN5PSI1Ni4wOTgiIGN4PSI1Ni4wOTgiIHI9IjU2LjA5OCIgc3R5bGU9ImZpbGw6IzNCNTk5ODsiLz4KICA8cGF0aCBkPSJNNzAuMjAxLDU4LjI5NGgtMTAuMDF2MzYuNjcySDQ1LjAyNVY1OC4yOTRoLTcuMjEzVjQ1LjQwNmg3LjIxM3YtOC4zNCAgIGMwLTUuOTY0LDIuODMzLTE1LjMwMywxNS4zMDEtMTUuMzAzTDcxLjU2LDIxLjgxdjEyLjUx'+
			'aC04LjE1MWMtMS4zMzcsMC0zLjIxNywwLjY2OC0zLjIxNywzLjUxM3Y3LjU4NWgxMS4zMzRMNzAuMjAxLDU4LjI5NHoiIHN0eWxlPSJmaWxsOiNGRkZGRkY7Ii8+CiA8L2c+CiA8Zy8+CiA8Zy8+CiA8Zy8+CiA8Zy8+CiA8Zy8+CiA8Zy8+CiA8Zy8+CiA8Zy8+CiA8Zy8+CiA8Zy8+CiA8Zy8+CiA8Zy8+CiA8Zy8+CiA8Zy8+CiA8Zy8+Cjwvc3ZnPgo=';
		me._svg_5__img.setAttribute('src',hs);
		hs ='';
		hs += 'position: absolute;top: 0px;left: 0px;width: 100%;height: 100%;-webkit-user-drag:none;pointer-events:none;;';
		els.setAttribute('style', hs);
		els['ondragstart']=function() { return false; };
		el.appendChild(els);
		el.ggSubElement = els;
		el.ggId="Svg 5";
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_svg ";
		el.ggType='svg';
		hs ='';
		hs+='bottom : 50px;';
		hs+='cursor : pointer;';
		hs+='height : 30px;';
		hs+='left : 10px;';
		hs+='position : absolute;';
		hs+='visibility : inherit;';
		hs+='width : 30px;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me._svg_5.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._svg_5.logicBlock_scaling = function() {
			var newLogicStateScaling;
			if (
				((me.elementMouseOver['svg_5'] == true))
			)
			{
				newLogicStateScaling = 0;
			}
			else {
				newLogicStateScaling = -1;
			}
			if (me._svg_5.ggCurrentLogicStateScaling != newLogicStateScaling) {
				me._svg_5.ggCurrentLogicStateScaling = newLogicStateScaling;
				me._svg_5.style.transition='transform 200ms ease 0ms';
				if (me._svg_5.ggCurrentLogicStateScaling == 0) {
					me._svg_5.ggParameter.sx = 1.1;
					me._svg_5.ggParameter.sy = 1.1;
					me._svg_5.style.transform=parameterToTransform(me._svg_5.ggParameter);
					setTimeout(function() {skin.updateSize(me._svg_5);}, 250);
				}
				else {
					me._svg_5.ggParameter.sx = 1;
					me._svg_5.ggParameter.sy = 1;
					me._svg_5.style.transform=parameterToTransform(me._svg_5.ggParameter);
					setTimeout(function() {skin.updateSize(me._svg_5);}, 250);
				}
			}
		}
		me._svg_5.logicBlock_scaling();
		me._svg_5.onclick=function (e) {
			player.openUrl(player.getVariableValue('face', me.hotspot ? me.hotspot.id : (player.hotspot ? player.hotspot.id : '')),"_blank");
		}
		me._svg_5.onmouseenter=function (e) {
			me.elementMouseOver['svg_5']=true;
			me._svg_5.logicBlock_scaling();
		}
		me._svg_5.onmouseleave=function (e) {
			me.elementMouseOver['svg_5']=false;
			me._svg_5.logicBlock_scaling();
		}
		me._svg_5.ggUpdatePosition=function (useTransition) {
		}
		me._sosyalmedyaarkaplan.appendChild(me._svg_5);
		el=me._instagram=document.createElement('div');
		els=me._instagram__img=document.createElement('img');
		els.className='ggskin ggskin_instagram';
		hs=basePath + 'images/instagram.png';
		els.setAttribute('src',hs);
		els.ggNormalSrc=hs;
		hs ='';
		hs += 'position: absolute;top: 0px;left: 0px;width: 100%;height: 100%;-webkit-user-drag:none;pointer-events:none;;';
		els.setAttribute('style', hs);
		els.className='ggskin ggskin_button';
		els['ondragstart']=function() { return false; };
		player.checkLoaded.push(els);
		el.appendChild(els);
		el.ggSubElement = els;
		el.ggId="instagram";
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_button ";
		el.ggType='button';
		hs ='';
		hs+='bottom : 90px;';
		hs+='cursor : pointer;';
		hs+='height : 33px;';
		hs+='left : 10px;';
		hs+='position : absolute;';
		hs+='visibility : inherit;';
		hs+='width : 33px;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me._instagram.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._instagram.logicBlock_scaling = function() {
			var newLogicStateScaling;
			if (
				((me.elementMouseOver['instagram'] == true))
			)
			{
				newLogicStateScaling = 0;
			}
			else {
				newLogicStateScaling = -1;
			}
			if (me._instagram.ggCurrentLogicStateScaling != newLogicStateScaling) {
				me._instagram.ggCurrentLogicStateScaling = newLogicStateScaling;
				me._instagram.style.transition='transform 200ms ease 0ms';
				if (me._instagram.ggCurrentLogicStateScaling == 0) {
					me._instagram.ggParameter.sx = 1.1;
					me._instagram.ggParameter.sy = 1.1;
					me._instagram.style.transform=parameterToTransform(me._instagram.ggParameter);
					setTimeout(function() {skin.updateSize(me._instagram);}, 250);
				}
				else {
					me._instagram.ggParameter.sx = 1;
					me._instagram.ggParameter.sy = 1;
					me._instagram.style.transform=parameterToTransform(me._instagram.ggParameter);
					setTimeout(function() {skin.updateSize(me._instagram);}, 250);
				}
			}
		}
		me._instagram.logicBlock_scaling();
		me._instagram.onclick=function (e) {
			player.openUrl(player.getVariableValue('insta', me.hotspot ? me.hotspot.id : (player.hotspot ? player.hotspot.id : '')),"_blank");
		}
		me._instagram.onmouseenter=function (e) {
			me.elementMouseOver['instagram']=true;
			me._instagram.logicBlock_scaling();
		}
		me._instagram.onmouseleave=function (e) {
			me.elementMouseOver['instagram']=false;
			me._instagram.logicBlock_scaling();
		}
		me._instagram.ggUpdatePosition=function (useTransition) {
		}
		me._sosyalmedyaarkaplan.appendChild(me._instagram);
		me._sosyalmedya.appendChild(me._sosyalmedyaarkaplan);
		me.divSkin.appendChild(me._sosyalmedya);
		el=me._infobilgileri=document.createElement('div');
		el.ggId="\u0130nfoBilgileri";
		el.ggDy=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=false;
		el.className="ggskin ggskin_container ";
		el.ggType='container';
		hs ='';
		hs+='height : 330px;';
		hs+='position : absolute;';
		hs+='right : -303px;';
		hs+='top : calc(50% - ((330px + 0px) / 2) + 0px);';
		hs+='visibility : hidden;';
		hs+='width : 300px;';
		hs+='pointer-events:none;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me._infobilgileri.ggIsActive=function() {
			return false;
		}
		el.ggElementNodeId=function() {
			return player.getCurrentNode();
		}
		me._infobilgileri.logicBlock_position = function() {
			var newLogicStatePosition;
			if (
				((player.getVariableValue('infoklasor') == true))
			)
			{
				newLogicStatePosition = 0;
			}
			else {
				newLogicStatePosition = -1;
			}
			if (me._infobilgileri.ggCurrentLogicStatePosition != newLogicStatePosition) {
				me._infobilgileri.ggCurrentLogicStatePosition = newLogicStatePosition;
				me._infobilgileri.style.transition='right 500ms ease 0ms, top 500ms ease 0ms';
				if (me._infobilgileri.ggCurrentLogicStatePosition == 0) {
					me._infobilgileri.style.right='10px';
					me._infobilgileri.style.top = 'calc(50% - (330px / 2))';
				}
				else {
					me._infobilgileri.style.right='-303px';
					me._infobilgileri.style.top='calc(50% - ((330px + 0px) / 2) + 0px)';
				}
			}
		}
		me._infobilgileri.logicBlock_position();
		me._infobilgileri.logicBlock_visible = function() {
			var newLogicStateVisible;
			if (
				((player.getVariableValue('info') == true))
			)
			{
				newLogicStateVisible = 0;
			}
			else {
				newLogicStateVisible = -1;
			}
			if (me._infobilgileri.ggCurrentLogicStateVisible != newLogicStateVisible) {
				me._infobilgileri.ggCurrentLogicStateVisible = newLogicStateVisible;
				me._infobilgileri.style.transition='right 500ms ease 0ms, top 500ms ease 0ms';
				if (me._infobilgileri.ggCurrentLogicStateVisible == 0) {
					me._infobilgileri.style.visibility=(Number(me._infobilgileri.style.opacity)>0||!me._infobilgileri.style.opacity)?'inherit':'hidden';
					me._infobilgileri.ggVisible=true;
				}
				else {
					me._infobilgileri.style.visibility="hidden";
					me._infobilgileri.ggVisible=false;
				}
			}
		}
		me._infobilgileri.logicBlock_visible();
		me._infobilgileri.ggUpdatePosition=function (useTransition) {
		}
		el=me._infokapat=document.createElement('div');
		el.ggId="infokapat";
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_rectangle ";
		el.ggType='rectangle';
		hs ='';
		hs+='background : rgba(0,0,0,0.784314);';
		hs+='border : 2px solid #ffffff;';
		hs+='bottom : 25px;';
		hs+='cursor : pointer;';
		hs+='height : 40px;';
		hs+='left : -44px;';
		hs+='position : absolute;';
		hs+='visibility : inherit;';
		hs+='width : 40px;';
		hs+='pointer-events:auto;';
		hs+='border-radius: 7px 0px 0px 7px;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me._infokapat.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._infokapat.logicBlock_backgroundcolor = function() {
			var newLogicStateBackgroundColor;
			if (
				((me.elementMouseOver['infokapat'] == true))
			)
			{
				newLogicStateBackgroundColor = 0;
			}
			else {
				newLogicStateBackgroundColor = -1;
			}
			if (me._infokapat.ggCurrentLogicStateBackgroundColor != newLogicStateBackgroundColor) {
				me._infokapat.ggCurrentLogicStateBackgroundColor = newLogicStateBackgroundColor;
				me._infokapat.style.transition='background-color 0s';
				if (me._infokapat.ggCurrentLogicStateBackgroundColor == 0) {
					me._infokapat.style.backgroundColor="rgba(70,65,95,1)";
				}
				else {
					me._infokapat.style.backgroundColor="rgba(0,0,0,0.784314)";
				}
			}
		}
		me._infokapat.logicBlock_backgroundcolor();
		me._infokapat.onclick=function (e) {
			player.setVariableValue('infoklasor', !player.getVariableValue('infoklasor'));
			player.setVariableValue('Sosyalmedya', false);
			player.setVariableValue('altmenu', false);
			player.setVariableValue('solmenuklasor', false);
		}
		me._infokapat.onmouseenter=function (e) {
			me.elementMouseOver['infokapat']=true;
			me._infokapat.logicBlock_backgroundcolor();
		}
		me._infokapat.onmouseleave=function (e) {
			me.elementMouseOver['infokapat']=false;
			me._infokapat.logicBlock_backgroundcolor();
		}
		me._infokapat.ggUpdatePosition=function (useTransition) {
		}
		el=me._infologo=document.createElement('div');
		els=me._infologo__img=document.createElement('img');
		els.className='ggskin ggskin_svg';
		hs='data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0nMS4wJz8+CjxzdmcgaGVpZ2h0PSI1MTIiIGNsYXNzPSIiIHk9IjAiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDExMS41NzcgMTExLjU3NyIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgNTEyIDUxMiIgeG1sbnM6c3ZnanM9Imh0dHA6Ly9zdmdqcy5jb20vc3ZnanMiIHdpZHRoPSI1MTIiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjAiPgogPGc+CiAgPGcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3'+
			'ZnIj4KICAgPHBhdGggZD0iTTc4Ljk2Miw5OS41MzZsLTEuNTU5LDYuMzczYy00LjY3NywxLjg0Ni04LjQxMywzLjI1MS0xMS4xOTUsNC4yMTdjLTIuNzg1LDAuOTY5LTYuMDIxLDEuNDUxLTkuNzA4LDEuNDUxICAgYy01LjY2MiwwLTEwLjA2Ni0xLjM4Ny0xMy4yMDctNC4xNDJjLTMuMTQxLTIuNzY2LTQuNzEyLTYuMjcxLTQuNzEyLTEwLjUyM2MwLTEuNjQ2LDAuMTE0LTMuMzM5LDAuMzUxLTUuMDY0ICAgYzAuMjM5LTEuNzI3LDAuNjE5LTMuNjcyLDEuMTM5LTUuODQ2bDUuODQ1LTIwLjY4OGMwLjUyLTEuOTgxLDAuOTYyLTMuODU4LDEuMzE2LTUuNjMzYzAuMzU5LTEuNzY0LDAuNTMyLTMuMzg3'+
			'LDAuNTMyLTQuODQ4ICAgYzAtMi42NDItMC41NDctNC40OS0xLjYzNi01LjUyOWMtMS4wODktMS4wMzYtMy4xNjctMS41NjItNi4yNTItMS41NjJjLTEuNTExLDAtMy4wNjQsMC4yNDItNC42NDcsMC43MSAgIGMtMS41OSwwLjQ3LTIuOTQ5LDAuOTI0LTQuMDksMS4zNDZsMS41NjMtNi4zNzhjMy44MjktMS41NTksNy40ODktMi44OTQsMTAuOTktNC4wMDJjMy41MDEtMS4xMTEsNi44MDktMS42NjcsOS45MzgtMS42NjcgICBjNS42MjMsMCw5Ljk2MiwxLjM1OSwxMy4wMDksNC4wNzdjMy4wNDcsMi43Miw0LjU3LDYuMjQ2LDQuNTcsMTAuNTkxYzAsMC44OTktMC4xLDIuNDgzLTAuMzE1LDQuNzQ3IC'+
			'AgYy0wLjIxLDIuMjY5LTAuNjAxLDQuMzQ4LTEuMTcxLDYuMjM5bC01LjgyLDIwLjYwNWMtMC40NzcsMS42NTUtMC45MDYsMy41NDctMS4yNzksNS42NzZjLTAuMzg1LDIuMTE1LTAuNTY5LDMuNzMxLTAuNTY5LDQuODE1ICAgYzAsMi43MzYsMC42MSw0LjYwNCwxLjgzMyw1LjU5N2MxLjIzMiwwLjk5MywzLjM1NCwxLjQ4Nyw2LjM2OCwxLjQ4N2MxLjQxNSwwLDMuMDI1LTAuMjUxLDQuODE0LTAuNzQ0ICAgQzc2Ljg1NCwxMDAuMzQ4LDc4LjE1NSw5OS45MTUsNzguOTYyLDk5LjUzNnogTTgwLjQzOCwxMy4wM2MwLDMuNTktMS4zNTMsNi42NTYtNC4wNzIsOS4xNzdjLTIuNzEyLDIuNTMtNS45OCwz'+
			'Ljc5Ni05LjgwMywzLjc5NiAgIGMtMy44MzUsMC03LjExMS0xLjI2Ni05Ljg1NC0zLjc5NmMtMi43MzgtMi41MjItNC4xMS01LjU4Ny00LjExLTkuMTc3YzAtMy41ODMsMS4zNzItNi42NTQsNC4xMS05LjIwNyAgIEM1OS40NDcsMS4yNzQsNjIuNzI5LDAsNjYuNTYzLDBjMy44MjIsMCw3LjA5MSwxLjI3Nyw5LjgwMywzLjgyM0M3OS4wODcsNi4zNzYsODAuNDM4LDkuNDQ4LDgwLjQzOCwxMy4wM3oiIGRhdGEtb3JpZ2luYWw9IiMwMDAwMDAiIHN0eWxlPSIiIGZpbGw9IiNmZmZmZmYiLz4KICA8L2c+CiAgPGcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIi8+CiAgPGcgeG1sbnM9Im'+
			'h0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIi8+CiAgPGcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIi8+CiAgPGcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIi8+CiAgPGcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIi8+CiAgPGcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIi8+CiAgPGcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIi8+CiAgPGcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIi8+CiAgPGcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIi8+CiAgPGcgeG1sbnM9Imh0'+
			'dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIi8+CiAgPGcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIi8+CiAgPGcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIi8+CiAgPGcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIi8+CiAgPGcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIi8+CiAgPGcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIi8+CiA8L2c+Cjwvc3ZnPgo=';
		me._infologo__img.setAttribute('src',hs);
		hs ='';
		hs += 'position: absolute;top: 0px;left: 0px;width: 100%;height: 100%;-webkit-user-drag:none;pointer-events:none;;';
		els.setAttribute('style', hs);
		els['ondragstart']=function() { return false; };
		el.appendChild(els);
		el.ggSubElement = els;
		el.ggId="infologo";
		el.ggDx=-1;
		el.ggDy=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_svg ";
		el.ggType='svg';
		hs ='';
		hs+='cursor : pointer;';
		hs+='height : 70%;';
		hs+='left : calc(50% - ((70% + 0px) / 2) - 1px);';
		hs+='position : absolute;';
		hs+='top : calc(50% - ((70% + 0px) / 2) + 0px);';
		hs+='visibility : inherit;';
		hs+='width : 70%;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me._infologo.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._infologo.ggUpdatePosition=function (useTransition) {
		}
		me._infokapat.appendChild(me._infologo);
		me._infobilgileri.appendChild(me._infokapat);
		el=me._info_arkaplan=document.createElement('div');
		el.ggId="info arkaplan";
		el.ggDx=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_rectangle ";
		el.ggType='rectangle';
		hs ='';
		hs+='background : rgba(0,0,0,0.784314);';
		hs+='border : 2px solid #ffffff;';
		hs+='border-radius : 30px;';
		hs+='cursor : default;';
		hs+='height : 100%;';
		hs+='left : calc(50% - ((100% + 4px) / 2) + 0px);';
		hs+='position : absolute;';
		hs+='top : 0px;';
		hs+='visibility : inherit;';
		hs+='width : 100%;';
		hs+='pointer-events:auto;';
		hs+='backdrop-filter: blur(3px);';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me._info_arkaplan.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._info_arkaplan.ggUpdatePosition=function (useTransition) {
		}
		el=me._zoomin0=document.createElement('div');
		els=me._zoomin0__img=document.createElement('img');
		els.className='ggskin ggskin_svg';
		hs='data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0nMS4wJyBlbmNvZGluZz0ndXRmLTgnPz4KPCFET0NUWVBFIHN2ZyBQVUJMSUMgJy0vL1czQy8vRFREIFNWRyAxLjEgQmFzaWMvL0VOJyAnaHR0cDovL3d3dy53My5vcmcvR3JhcGhpY3MvU1ZHLzEuMS9EVEQvc3ZnMTEtYmFzaWMuZHRkJz4KPCEtLSBHYXJkZW4gR25vbWUgU29mdHdhcmUgLSBTa2luIEJ1dHRvbnMgLS0+CjxzdmcgaGVpZ2h0PSIzMnB4IiB5PSIwcHgiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDMyIDMyIiB3aWR0aD0iMzJweCIgYmFzZVByb2ZpbGU9ImJhc2ljIiBpZD0iTGF5ZXJfMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIi'+
			'B4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgeD0iMHB4Ij4KIDxnIG9wYWNpdHk9IjAuNCIgc3Ryb2tlLXdpZHRoPSIxLjUiIHN0cm9rZT0iIzNDM0MzQyI+CiAgPHBhdGggZD0iTTIyLjA2MSwxNC44MDNoLTQuODY0VjkuOTM4YzAtMC42NjEtMC41MzYtMS4xOTctMS4xOTctMS4xOTdjLTAuNjYsMC0xLjE5NiwwLjUzNi0xLjE5NiwxLjE5N3Y0Ljg2NSAgICBIOS45MzhjLTAuNjYxLDAtMS4xOTYsMC41MzYtMS4xOTYsMS4xOTdjMCwwLjY2LDAuNTM2LDEuMTk2LDEuMTk2LDEuMTk2aDQuODY2djQuODY1YzAsMC42NiwwLjUzNiwx'+
			'LjE5NiwxLjE5NiwxLjE5NiAgICBjMC42NjEsMCwxLjE5Ny0wLjUzNiwxLjE5Ny0xLjE5NnYtNC44NjVoNC44NjRjMC42NjEsMCwxLjE5Ni0wLjUzNiwxLjE5Ni0xLjE5NkMyMy4yNTcsMTUuMzM5LDIyLjcyMiwxNC44MDMsMjIuMDYxLDE0LjgwM3ogICAgIE0xNiwzLjVDOS4wOTYsMy41LDMuNSw5LjA5NiwzLjUsMTZjMCw2LjkwMyw1LjU5NiwxMi40OTksMTIuNSwxMi41YzYuOTAzLTAuMDAxLDEyLjQ5OS01LjU5NywxMi41LTEyLjUgICAgQzI4LjQ5OSw5LjA5NiwyMi45MDMsMy41LDE2LDMuNXogTTIzLjE0NiwyMy4xNDZjLTEuODMyLDEuODMxLTQuMzUyLDIuOTYtNy4xNDYsMi45NnMtNS4zMT'+
			'QtMS4xMjktNy4xNDYtMi45NiAgICBDNy4wMjIsMjEuMzE0LDUuODk0LDE4Ljc5NSw1Ljg5MywxNmMwLjAwMS0yLjc5NSwxLjEyOS01LjMxNCwyLjk2MS03LjE0N2MxLjgzMy0xLjgzMSw0LjM1Mi0yLjk2LDcuMTQ2LTIuOTYxICAgIGMyLjc5NSwwLjAwMSw1LjMxMywxLjEzLDcuMTQ2LDIuOTYxYzEuODMyLDEuODMzLDIuOTYsNC4zNTIsMi45NjEsNy4xNDdDMjYuMTA2LDE4Ljc5NSwyNC45NzksMjEuMzE0LDIzLjE0NiwyMy4xNDZ6Ii8+CiA8L2c+CiA8ZyBzdHJva2Utd2lkdGg9IjAuMiIgc3Ryb2tlPSIjMDAwMDAwIiBmaWxsPSIjRkZGRkZGIj4KICA8cGF0aCBkPSJNMjIuMDYxLDE0LjgwM2gt'+
			'NC44NjRWOS45MzhjMC0wLjY2MS0wLjUzNi0xLjE5Ny0xLjE5Ny0xLjE5N2MtMC42NiwwLTEuMTk2LDAuNTM2LTEuMTk2LDEuMTk3djQuODY1ICAgIEg5LjkzOGMtMC42NjEsMC0xLjE5NiwwLjUzNi0xLjE5NiwxLjE5N2MwLDAuNjYsMC41MzYsMS4xOTYsMS4xOTYsMS4xOTZoNC44NjZ2NC44NjVjMCwwLjY2LDAuNTM2LDEuMTk2LDEuMTk2LDEuMTk2ICAgIGMwLjY2MSwwLDEuMTk3LTAuNTM2LDEuMTk3LTEuMTk2di00Ljg2NWg0Ljg2NGMwLjY2MSwwLDEuMTk2LTAuNTM2LDEuMTk2LTEuMTk2QzIzLjI1NywxNS4zMzksMjIuNzIyLDE0LjgwMywyMi4wNjEsMTQuODAzeiAgICAgTTE2LDMuNUM5Lj'+
			'A5NiwzLjUsMy41LDkuMDk2LDMuNSwxNmMwLDYuOTAzLDUuNTk2LDEyLjQ5OSwxMi41LDEyLjVjNi45MDMtMC4wMDEsMTIuNDk5LTUuNTk3LDEyLjUtMTIuNSAgICBDMjguNDk5LDkuMDk2LDIyLjkwMywzLjUsMTYsMy41eiBNMjMuMTQ2LDIzLjE0NmMtMS44MzIsMS44MzEtNC4zNTIsMi45Ni03LjE0NiwyLjk2cy01LjMxNC0xLjEyOS03LjE0Ni0yLjk2ICAgIEM3LjAyMiwyMS4zMTQsNS44OTQsMTguNzk1LDUuODkzLDE2YzAuMDAxLTIuNzk1LDEuMTI5LTUuMzE0LDIuOTYxLTcuMTQ3YzEuODMzLTEuODMxLDQuMzUyLTIuOTYsNy4xNDYtMi45NjEgICAgYzIuNzk1LDAuMDAxLDUuMzEzLDEuMTMs'+
			'Ny4xNDYsMi45NjFjMS44MzIsMS44MzMsMi45Niw0LjM1MiwyLjk2MSw3LjE0N0MyNi4xMDYsMTguNzk1LDI0Ljk3OSwyMS4zMTQsMjMuMTQ2LDIzLjE0NnoiLz4KIDwvZz4KPC9zdmc+Cg==';
		me._zoomin0__img.setAttribute('src',hs);
		hs ='';
		hs += 'position: absolute;top: 0px;left: 0px;width: 100%;height: 100%;-webkit-user-drag:none;pointer-events:none;;';
		els.setAttribute('style', hs);
		els['ondragstart']=function() { return false; };
		el.appendChild(els);
		el.ggSubElement = els;
		el.ggId="zoomin";
		el.ggParameter={ rx:0,ry:0,a:45,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_svg ";
		el.ggType='svg';
		hs ='';
		hs+='cursor : pointer;';
		hs+='height : 35px;';
		hs+='left : 10px;';
		hs+='position : absolute;';
		hs+='top : 10px;';
		hs+='visibility : inherit;';
		hs+='width : 35px;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		el.style.transform=parameterToTransform(el.ggParameter);
		me._zoomin0.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._zoomin0.logicBlock_scaling = function() {
			var newLogicStateScaling;
			if (
				((me.elementMouseOver['zoomin0'] == true))
			)
			{
				newLogicStateScaling = 0;
			}
			else {
				newLogicStateScaling = -1;
			}
			if (me._zoomin0.ggCurrentLogicStateScaling != newLogicStateScaling) {
				me._zoomin0.ggCurrentLogicStateScaling = newLogicStateScaling;
				me._zoomin0.style.transition='transform 200ms ease 0ms';
				if (me._zoomin0.ggCurrentLogicStateScaling == 0) {
					me._zoomin0.ggParameter.sx = 1.1;
					me._zoomin0.ggParameter.sy = 1.1;
					me._zoomin0.style.transform=parameterToTransform(me._zoomin0.ggParameter);
					setTimeout(function() {skin.updateSize(me._zoomin0);}, 250);
				}
				else {
					me._zoomin0.ggParameter.sx = 1;
					me._zoomin0.ggParameter.sy = 1;
					me._zoomin0.style.transform=parameterToTransform(me._zoomin0.ggParameter);
					setTimeout(function() {skin.updateSize(me._zoomin0);}, 250);
				}
			}
		}
		me._zoomin0.logicBlock_scaling();
		me._zoomin0.onclick=function (e) {
			player.setVariableValue('infoklasor', false);
		}
		me._zoomin0.onmouseenter=function (e) {
			me.elementMouseOver['zoomin0']=true;
			me._zoomin0.logicBlock_scaling();
		}
		me._zoomin0.onmouseleave=function (e) {
			me.elementMouseOver['zoomin0']=false;
			me._zoomin0.logicBlock_scaling();
		}
		me._zoomin0.ggUpdatePosition=function (useTransition) {
		}
		me._info_arkaplan.appendChild(me._zoomin0);
		el=me._adres_1=document.createElement('div');
		els=me._adres_1__text=document.createElement('div');
		el.className='ggskin ggskin_textdiv';
		el.ggTextDiv=els;
		el.ggId="adres_1";
		el.ggDx=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_text ";
		el.ggType='text';
		hs ='';
		hs+='border : 0px solid #000000;';
		hs+='color : rgba(255,255,255,1);';
		hs+='cursor : default;';
		hs+='height : 20px;';
		hs+='left : calc(50% - ((100% + 0px) / 2) + 0px);';
		hs+='position : absolute;';
		hs+='top : 259px;';
		hs+='visibility : inherit;';
		hs+='width : 100%;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		hs ='';
		hs += 'box-sizing: border-box;';
		hs+='width: 100%;';
		hs+='height: 100%;';
		hs+='font-size: 15px;';
		hs+='font-weight: bold;';
		hs+='text-align: center;';
		hs+='white-space: pre;';
		hs+='padding: 0px;';
		hs+='overflow: hidden;';
		els.setAttribute('style',hs);
		me._adres_1.ggUpdateText=function() {
			var params = [];
			var hs = player._("Anschrift", params);
			if (hs!=this.ggText) {
				this.ggText=hs;
				this.ggTextDiv.innerHTML=hs;
				if (this.ggUpdatePosition) this.ggUpdatePosition();
			}
		}
		me._adres_1.ggUpdateText();
		el.appendChild(els);
		me._adres_1.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._adres_1.ggUpdatePosition=function (useTransition) {
		}
		el=me._adress=document.createElement('div');
		els=me._adress__text=document.createElement('div');
		el.className='ggskin ggskin_textdiv';
		el.ggTextDiv=els;
		el.ggId="adress";
		el.ggDx=0;
		el.ggDy=40;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'translate(0px, -50%) ' };
		el.ggVisible=true;
		el.className="ggskin ggskin_text ";
		el.ggType='text';
		hs ='';
		hs+='color : rgba(255,255,255,1);';
		hs+='cursor : pointer;';
		hs+='height : auto;';
		hs+='left : calc(50% - ((100% + 0px) / 2) + 0px);';
		hs+='position : absolute;';
		hs+='top : calc(50% - ((0px + 0px) / 2) + 40px);';
		hs+='transform : translate(0px, -50%);;';
		hs+='visibility : inherit;';
		hs+='width : 100%;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='0% 50%';
		hs ='';
		hs += 'box-sizing: border-box;';
		hs+='width: 100%;';
		hs+='height: auto;';
		hs+='border : 0px solid #000000;';
		hs+='font-size: 13px;';
		hs+='font-weight: bold;';
		hs+='text-align: center;';
		hs+='white-space: pre-line;';
		hs+='padding: 0px;';
		hs+='overflow: hidden;';
		els.setAttribute('style',hs);
		me._adress.ggUpdateText=function() {
			var params = [];
			params.push(player._(String(player.getVariableValue('addr', me.hotspot ? me.hotspot.id : (player.hotspot ? player.hotspot.id : '')))));
			var hs = player._("%1", params);
			if (hs!=this.ggText) {
				this.ggText=hs;
				this.ggTextDiv.innerHTML=hs;
				if (this.ggUpdatePosition) this.ggUpdatePosition();
			}
		}
		me._adress.ggUpdateText();
		player.addListener('varchanged_addr', function() {
			me._adress.ggUpdateText();
		});
		el.appendChild(els);
		me._adress.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._adress.onclick=function (e) {
			player.openUrl(player.getVariableValue('google_map', me.hotspot ? me.hotspot.id : (player.hotspot ? player.hotspot.id : '')),"_blank");
		}
		me._adress.ggUpdatePosition=function (useTransition) {
		}
		me._adres_1.appendChild(me._adress);
		me._info_arkaplan.appendChild(me._adres_1);
		el=me._website=document.createElement('div');
		els=me._website__text=document.createElement('div');
		el.className='ggskin ggskin_textdiv';
		el.ggTextDiv=els;
		el.ggId="website";
		el.ggDx=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_text ";
		el.ggType='text';
		hs ='';
		hs+='border : 0px solid #000000;';
		hs+='color : rgba(255,255,255,1);';
		hs+='cursor : default;';
		hs+='height : 20px;';
		hs+='left : calc(50% - ((100% + 0px) / 2) + 0px);';
		hs+='position : absolute;';
		hs+='top : 171px;';
		hs+='visibility : inherit;';
		hs+='width : 100%;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		hs ='';
		hs += 'box-sizing: border-box;';
		hs+='width: 100%;';
		hs+='height: 100%;';
		hs+='font-size: 15px;';
		hs+='font-weight: bold;';
		hs+='text-align: center;';
		hs+='white-space: pre;';
		hs+='padding: 0px;';
		hs+='overflow: hidden;';
		els.setAttribute('style',hs);
		me._website.ggUpdateText=function() {
			var params = [];
			var hs = player._("Website", params);
			if (hs!=this.ggText) {
				this.ggText=hs;
				this.ggTextDiv.innerHTML=hs;
				if (this.ggUpdatePosition) this.ggUpdatePosition();
			}
		}
		me._website.ggUpdateText();
		el.appendChild(els);
		me._website.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._website.ggUpdatePosition=function (useTransition) {
		}
		el=me._website_adresi=document.createElement('div');
		els=me._website_adresi__text=document.createElement('div');
		el.className='ggskin ggskin_textdiv';
		el.ggTextDiv=els;
		el.ggId="website adresi";
		el.ggDx=-3;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_text ";
		el.ggType='text';
		hs ='';
		hs+='border : 0px solid #000000;';
		hs+='color : rgba(255,255,255,1);';
		hs+='cursor : pointer;';
		hs+='height : 20px;';
		hs+='left : calc(50% - ((100% + 0px) / 2) - 3px);';
		hs+='position : absolute;';
		hs+='top : 23px;';
		hs+='visibility : inherit;';
		hs+='width : 100%;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='0% 50%';
		hs ='';
		hs += 'box-sizing: border-box;';
		hs+='width: 100%;';
		hs+='height: 100%;';
		hs+='font-size: 13px;';
		hs+='font-weight: bold;';
		hs+='text-align: center;';
		hs+='white-space: pre;';
		hs+='padding: 0px;';
		hs+='overflow: hidden;';
		els.setAttribute('style',hs);
		me._website_adresi.ggUpdateText=function() {
			var params = [];
			params.push(player._(String(player.getVariableValue('web_site', me.hotspot ? me.hotspot.id : (player.hotspot ? player.hotspot.id : '')))));
			var hs = player._("%1", params);
			if (hs!=this.ggText) {
				this.ggText=hs;
				this.ggTextDiv.innerHTML=hs;
				if (this.ggUpdatePosition) this.ggUpdatePosition();
			}
		}
		me._website_adresi.ggUpdateText();
		player.addListener('varchanged_web_site', function() {
			me._website_adresi.ggUpdateText();
		});
		el.appendChild(els);
		me._website_adresi.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._website_adresi.onmousedown=function (e) {
			player.openUrl("https:\/\/"+player.getVariableValue('web_site', me.hotspot ? me.hotspot.id : (player.hotspot ? player.hotspot.id : '')),"_blank");
		}
		me._website_adresi.ggUpdatePosition=function (useTransition) {
		}
		me._website.appendChild(me._website_adresi);
		me._info_arkaplan.appendChild(me._website);
		el=me._email=document.createElement('div');
		els=me._email__text=document.createElement('div');
		el.className='ggskin ggskin_textdiv';
		el.ggTextDiv=els;
		el.ggId="email";
		el.ggDx=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_text ";
		el.ggType='text';
		hs ='';
		hs+='border : 0px solid #000000;';
		hs+='color : rgba(255,255,255,1);';
		hs+='cursor : default;';
		hs+='height : 20px;';
		hs+='left : calc(50% - ((100% + 0px) / 2) + 0px);';
		hs+='position : absolute;';
		hs+='top : 218px;';
		hs+='visibility : inherit;';
		hs+='width : 100%;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		hs ='';
		hs += 'box-sizing: border-box;';
		hs+='width: 100%;';
		hs+='height: 100%;';
		hs+='font-size: 15px;';
		hs+='font-weight: bold;';
		hs+='text-align: center;';
		hs+='white-space: pre;';
		hs+='padding: 0px;';
		hs+='overflow: hidden;';
		els.setAttribute('style',hs);
		me._email.ggUpdateText=function() {
			var params = [];
			var hs = player._("E  Mail", params);
			if (hs!=this.ggText) {
				this.ggText=hs;
				this.ggTextDiv.innerHTML=hs;
				if (this.ggUpdatePosition) this.ggUpdatePosition();
			}
		}
		me._email.ggUpdateText();
		el.appendChild(els);
		me._email.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._email.ggUpdatePosition=function (useTransition) {
		}
		el=me._email_adres=document.createElement('div');
		els=me._email_adres__text=document.createElement('div');
		el.className='ggskin ggskin_textdiv';
		el.ggTextDiv=els;
		el.ggId="email adres";
		el.ggDx=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_text ";
		el.ggType='text';
		hs ='';
		hs+='border : 0px solid #000000;';
		hs+='color : rgba(255,255,255,1);';
		hs+='cursor : pointer;';
		hs+='height : 20px;';
		hs+='left : calc(50% - ((100% + 0px) / 2) + 0px);';
		hs+='position : absolute;';
		hs+='top : 20px;';
		hs+='visibility : inherit;';
		hs+='width : 100%;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='0% 50%';
		hs ='';
		hs += 'box-sizing: border-box;';
		hs+='width: 100%;';
		hs+='height: 100%;';
		hs+='font-size: 12px;';
		hs+='font-weight: bold;';
		hs+='text-align: center;';
		hs+='white-space: pre;';
		hs+='padding: 0px;';
		hs+='overflow: hidden;';
		els.setAttribute('style',hs);
		me._email_adres.ggUpdateText=function() {
			var params = [];
			params.push(player._(String(player.getVariableValue('mail', me.hotspot ? me.hotspot.id : (player.hotspot ? player.hotspot.id : '')))));
			var hs = player._("%1", params);
			if (hs!=this.ggText) {
				this.ggText=hs;
				this.ggTextDiv.innerHTML=hs;
				if (this.ggUpdatePosition) this.ggUpdatePosition();
			}
		}
		me._email_adres.ggUpdateText();
		player.addListener('varchanged_mail', function() {
			me._email_adres.ggUpdateText();
		});
		el.appendChild(els);
		me._email_adres.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._email_adres.onclick=function (e) {
			player.openUrl("mailto:"+player.getVariableValue('mail', me.hotspot ? me.hotspot.id : (player.hotspot ? player.hotspot.id : '')),"_blank");
		}
		me._email_adres.ggUpdatePosition=function (useTransition) {
		}
		me._email.appendChild(me._email_adres);
		me._info_arkaplan.appendChild(me._email);
		el=me._telefon=document.createElement('div');
		els=me._telefon__text=document.createElement('div');
		el.className='ggskin ggskin_textdiv';
		el.ggTextDiv=els;
		el.ggId="Telefon";
		el.ggDx=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_text ";
		el.ggType='text';
		hs ='';
		hs+='border : 0px solid #000000;';
		hs+='color : rgba(255,255,255,1);';
		hs+='cursor : default;';
		hs+='height : 20px;';
		hs+='left : calc(50% - ((100% + 0px) / 2) + 0px);';
		hs+='position : absolute;';
		hs+='top : 125px;';
		hs+='visibility : inherit;';
		hs+='width : 100%;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		hs ='';
		hs += 'box-sizing: border-box;';
		hs+='width: 100%;';
		hs+='height: 100%;';
		hs+='font-size: 15px;';
		hs+='font-weight: bold;';
		hs+='text-align: center;';
		hs+='white-space: pre;';
		hs+='padding: 0px;';
		hs+='overflow: hidden;';
		els.setAttribute('style',hs);
		me._telefon.ggUpdateText=function() {
			var params = [];
			var hs = player._("Telefon", params);
			if (hs!=this.ggText) {
				this.ggText=hs;
				this.ggTextDiv.innerHTML=hs;
				if (this.ggUpdatePosition) this.ggUpdatePosition();
			}
		}
		me._telefon.ggUpdateText();
		el.appendChild(els);
		me._telefon.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._telefon.logicBlock_text = function() {
			var newLogicStateText;
			if (
				((player.getVariableValue('TR', me.hotspot ? me.hotspot.id : (player.hotspot ? player.hotspot.id : '')) == true))
			)
			{
				newLogicStateText = 0;
			}
			else if (
				((player.getVariableValue('EN', me.hotspot ? me.hotspot.id : (player.hotspot ? player.hotspot.id : '')) == true))
			)
			{
				newLogicStateText = 1;
			}
			else if (
				((player.getVariableValue('DE', me.hotspot ? me.hotspot.id : (player.hotspot ? player.hotspot.id : '')) == true))
			)
			{
				newLogicStateText = 2;
			}
			else if (
				((player.getVariableValue('RU', me.hotspot ? me.hotspot.id : (player.hotspot ? player.hotspot.id : '')) == true))
			)
			{
				newLogicStateText = 3;
			}
			else {
				newLogicStateText = -1;
			}
			if (me._telefon.ggCurrentLogicStateText != newLogicStateText) {
				me._telefon.ggCurrentLogicStateText = newLogicStateText;
				me._telefon.style.transition='';
				if (me._telefon.ggCurrentLogicStateText == 0) {
					if (me._telefon.ggUpdateText) {
					me._telefon.ggUpdateText=function() {
						var params = [];
						var hs = player._("Telefon", params);
						if (hs!=this.ggText) {
							this.ggText=hs;
							this.ggTextDiv.innerHTML=hs;
							if (this.ggUpdatePosition) this.ggUpdatePosition();
						}
					}
					me._telefon.ggUpdateText();
					} else {
						if (me._telefon.ggUpdatePosition) me._telefon.ggUpdatePosition();
					}
				}
				else if (me._telefon.ggCurrentLogicStateText == 1) {
					if (me._telefon.ggUpdateText) {
					me._telefon.ggUpdateText=function() {
						var params = [];
						var hs = player._("Phone", params);
						if (hs!=this.ggText) {
							this.ggText=hs;
							this.ggTextDiv.innerHTML=hs;
							if (this.ggUpdatePosition) this.ggUpdatePosition();
						}
					}
					me._telefon.ggUpdateText();
					} else {
						if (me._telefon.ggUpdatePosition) me._telefon.ggUpdatePosition();
					}
				}
				else if (me._telefon.ggCurrentLogicStateText == 2) {
					if (me._telefon.ggUpdateText) {
					me._telefon.ggUpdateText=function() {
						var params = [];
						var hs = player._("Telefon", params);
						if (hs!=this.ggText) {
							this.ggText=hs;
							this.ggTextDiv.innerHTML=hs;
							if (this.ggUpdatePosition) this.ggUpdatePosition();
						}
					}
					me._telefon.ggUpdateText();
					} else {
						if (me._telefon.ggUpdatePosition) me._telefon.ggUpdatePosition();
					}
				}
				else if (me._telefon.ggCurrentLogicStateText == 3) {
					if (me._telefon.ggUpdateText) {
					me._telefon.ggUpdateText=function() {
						var params = [];
						var hs = player._("\u0442\u0435\u043b\u0435\u0444\u043e\u043d", params);
						if (hs!=this.ggText) {
							this.ggText=hs;
							this.ggTextDiv.innerHTML=hs;
							if (this.ggUpdatePosition) this.ggUpdatePosition();
						}
					}
					me._telefon.ggUpdateText();
					} else {
						if (me._telefon.ggUpdatePosition) me._telefon.ggUpdatePosition();
					}
				}
				else {
					if (me._telefon.ggUpdateText) {
					me._telefon.ggUpdateText=function() {
						var params = [];
						var hs = player._("Telefon", params);
						if (hs!=this.ggText) {
							this.ggText=hs;
							this.ggTextDiv.innerHTML=hs;
							if (this.ggUpdatePosition) this.ggUpdatePosition();
						}
					}
					me._telefon.ggUpdateText();
					} else {
						if (me._telefon.ggUpdatePosition) me._telefon.ggUpdatePosition();
					}
				}
			}
		}
		me._telefon.logicBlock_text();
		me._telefon.ggUpdatePosition=function (useTransition) {
		}
		el=me._telefonno=document.createElement('div');
		els=me._telefonno__text=document.createElement('div');
		el.className='ggskin ggskin_textdiv';
		el.ggTextDiv=els;
		el.ggId="telefonno";
		el.ggDx=0;
		el.ggDy=20;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_text ";
		el.ggType='text';
		hs ='';
		hs+='border : 0px solid #000000;';
		hs+='color : rgba(255,255,255,1);';
		hs+='cursor : pointer;';
		hs+='height : 20px;';
		hs+='left : calc(50% - ((100% + 0px) / 2) + 0px);';
		hs+='position : absolute;';
		hs+='top : calc(50% - ((20px + 0px) / 2) + 20px);';
		hs+='visibility : inherit;';
		hs+='width : 100%;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='0% 50%';
		hs ='';
		hs += 'box-sizing: border-box;';
		hs+='width: 100%;';
		hs+='height: 100%;';
		hs+='font-size: 13px;';
		hs+='font-weight: bold;';
		hs+='text-align: center;';
		hs+='white-space: pre;';
		hs+='padding: 0px;';
		hs+='overflow: hidden;';
		els.setAttribute('style',hs);
		me._telefonno.ggUpdateText=function() {
			var params = [];
			params.push(player._(String(player.getVariableValue('tel', me.hotspot ? me.hotspot.id : (player.hotspot ? player.hotspot.id : '')))));
			var hs = player._("%1", params);
			if (hs!=this.ggText) {
				this.ggText=hs;
				this.ggTextDiv.innerHTML=hs;
				if (this.ggUpdatePosition) this.ggUpdatePosition();
			}
		}
		me._telefonno.ggUpdateText();
		player.addListener('varchanged_tel', function() {
			me._telefonno.ggUpdateText();
		});
		el.appendChild(els);
		me._telefonno.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._telefonno.onclick=function (e) {
			player.openUrl("tel:"+player.getVariableValue('tel', me.hotspot ? me.hotspot.id : (player.hotspot ? player.hotspot.id : '')),"_self");
		}
		me._telefonno.ggUpdatePosition=function (useTransition) {
		}
		me._telefon.appendChild(me._telefonno);
		me._info_arkaplan.appendChild(me._telefon);
		me._infobilgileri.appendChild(me._info_arkaplan);
		el=me._logo2=document.createElement('div');
		els=me._logo2__img=document.createElement('img');
		els.className='ggskin ggskin_external';
		hs ='';
		hs += 'position: absolute;-webkit-user-drag:none;pointer-events:none;;';
		els.setAttribute('style', hs);
		els.onload=function() {me._logo2.ggUpdatePosition();}
		el.appendChild(els);
		el.ggSubElement = els;
		hs ='';
		el.ggAltText="";
		el.ggScrollbars=false;
		el.ggUpdateText = function() {
			me._logo2.ggSubElement.setAttribute('alt', player._(me._logo2.ggAltText));
			me._logo2.ggUpdateImagePlaceholder();
		}
		el.ggSetImage = function(img) {
			me._logo2.ggText_untranslated = img;
			me._logo2.ggUpdateImageTranslation();
		}
		el.ggUpdateImage = function() {
			me._logo2.ggSubElement.style.width = '0px';
			me._logo2.ggSubElement.style.height = '0px';
			me._logo2.ggSubElement.src='';
			me._logo2.ggSubElement.src=me._logo2.ggText;
		}
		el.ggUpdateImageTranslation = function() {
			if (me._logo2.ggText != player._(me._logo2.ggText_untranslated)) {
				me._logo2.ggText = player._(me._logo2.ggText_untranslated);
				me._logo2.ggUpdateImage()
			}
		}
		player.addListener('', function() {
			me._logo2.ggUpdateImagePlaceholder();
		});
		el.ggUpdateImagePlaceholder = function() {
			if (me._logo2.ggText != "assets/"+player.getVariableValue('logo_img', me.hotspot ? me.hotspot.id : (player.hotspot ? player.hotspot.id : ''))+"") {
				me._logo2.ggText="assets/"+player.getVariableValue('logo_img', me.hotspot ? me.hotspot.id : (player.hotspot ? player.hotspot.id : ''))+"";
				me._logo2.ggUpdateImage()
			}
		}
		els['ondragstart']=function() { return false; };
		player.checkLoaded.push(els);
		el.ggUpdateText();
		el.ggId="Logo2";
		el.ggDx=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_external ";
		el.ggType='external';
		hs ='';
		hs+='border : 0px solid #000000;';
		hs+='cursor : pointer;';
		hs+='height : 90px;';
		hs+='left : calc(50% - ((150px + 0px) / 2) + 0px);';
		hs+='position : absolute;';
		hs+='top : 30px;';
		hs+='visibility : inherit;';
		hs+='width : 150px;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 0%';
		me._logo2.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._logo2.logicBlock_scaling = function() {
			var newLogicStateScaling;
			if (
				((me.elementMouseOver['logo2'] == true))
			)
			{
				newLogicStateScaling = 0;
			}
			else {
				newLogicStateScaling = -1;
			}
			if (me._logo2.ggCurrentLogicStateScaling != newLogicStateScaling) {
				me._logo2.ggCurrentLogicStateScaling = newLogicStateScaling;
				me._logo2.style.transition='transform 500ms ease 0ms';
				if (me._logo2.ggCurrentLogicStateScaling == 0) {
					me._logo2.ggParameter.sx = 1.1;
					me._logo2.ggParameter.sy = 1.1;
					me._logo2.style.transform=parameterToTransform(me._logo2.ggParameter);
					setTimeout(function() {skin.updateSize(me._logo2);}, 550);
				}
				else {
					me._logo2.ggParameter.sx = 1;
					me._logo2.ggParameter.sy = 1;
					me._logo2.style.transform=parameterToTransform(me._logo2.ggParameter);
					setTimeout(function() {skin.updateSize(me._logo2);}, 550);
				}
			}
		}
		me._logo2.logicBlock_scaling();
		me._logo2.logicBlock_visible = function() {
			var newLogicStateVisible;
			if (
				((player.getVariableValue('logo_img') == ""))
			)
			{
				newLogicStateVisible = 0;
			}
			else {
				newLogicStateVisible = -1;
			}
			if (me._logo2.ggCurrentLogicStateVisible != newLogicStateVisible) {
				me._logo2.ggCurrentLogicStateVisible = newLogicStateVisible;
				me._logo2.style.transition='transform 500ms ease 0ms';
				if (me._logo2.ggCurrentLogicStateVisible == 0) {
					me._logo2.style.visibility="hidden";
					me._logo2.ggSubElement.src='';
					me._logo2.ggVisible=false;
				}
				else {
					me._logo2.style.visibility=(Number(me._logo2.style.opacity)>0||!me._logo2.style.opacity)?'inherit':'hidden';
					me._logo2.ggSubElement.src=me._logo2.ggText;
					me._logo2.ggVisible=true;
				}
			}
		}
		me._logo2.logicBlock_visible();
		me._logo2.onclick=function (e) {
			player.openUrl("https:\/\/"+player.getVariableValue('web_site', me.hotspot ? me.hotspot.id : (player.hotspot ? player.hotspot.id : '')),"_blank");
		}
		me._logo2.onmouseenter=function (e) {
			me.elementMouseOver['logo2']=true;
			me._logo2.logicBlock_scaling();
		}
		me._logo2.onmouseleave=function (e) {
			me.elementMouseOver['logo2']=false;
			me._logo2.logicBlock_scaling();
		}
		me._logo2.ggUpdatePosition=function (useTransition) {
			var parentWidth = me._logo2.clientWidth;
			var parentHeight = me._logo2.clientHeight;
			var img = me._logo2__img;
			var aspectRatioDiv = me._logo2.clientWidth / me._logo2.clientHeight;
			var aspectRatioImg = img.naturalWidth / img.naturalHeight;
			if (img.naturalWidth < parentWidth) parentWidth = img.naturalWidth;
			if (img.naturalHeight < parentHeight) parentHeight = img.naturalHeight;
			var currentWidth,currentHeight;
			if (aspectRatioDiv > aspectRatioImg) {
				currentHeight = parentHeight;
				currentWidth = Math.round(parentHeight * aspectRatioImg);
				img.style.width='';
				img.style.height=parentHeight + 'px';
			} else {
				currentWidth = parentWidth;
				currentHeight = Math.round(parentWidth / aspectRatioImg);
				img.style.width=parentWidth + 'px';
				img.style.height='';
			};
			if (!me._logo2.ggScrollbars || currentWidth < me._logo2.clientWidth) {
				img.style.right='';
				img.style.left='50%';
				img.style.marginLeft='-' + currentWidth/2 + 'px';
			} else {
				img.style.right='';
				img.style.left='0px';
				img.style.marginLeft='0px';
				me._logo2.scrollLeft=currentWidth / 2 - me._logo2.clientWidth / 2;
			}
			if (!me._logo2.ggScrollbars || currentHeight < me._logo2.clientHeight) {
				img.style.bottom='';
				img.style.top='0px';
			} else {
				img.style.bottom='';
				img.style.top='0px';
				img.style.marginTop='0px';
			}
		}
		me._infobilgileri.appendChild(me._logo2);
		me.divSkin.appendChild(me._infobilgileri);
		el=me._alt_men=document.createElement('div');
		el.ggId="alt men\xfc";
		el.ggDx=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_container ";
		el.ggType='container';
		hs ='';
		hs+='bottom : -60px;';
		hs+='height : 44px;';
		hs+='left : calc(50% - ((100% + 0px) / 2) + 0px);';
		hs+='position : absolute;';
		hs+='visibility : inherit;';
		hs+='width : 100%;';
		hs+='pointer-events:none;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me._alt_men.ggIsActive=function() {
			return false;
		}
		el.ggElementNodeId=function() {
			return player.getCurrentNode();
		}
		me._alt_men.logicBlock_position = function() {
			var newLogicStatePosition;
			if (
				((player.getVariableValue('altmenu') == true))
			)
			{
				newLogicStatePosition = 0;
			}
			else {
				newLogicStatePosition = -1;
			}
			if (me._alt_men.ggCurrentLogicStatePosition != newLogicStatePosition) {
				me._alt_men.ggCurrentLogicStatePosition = newLogicStatePosition;
				me._alt_men.style.transition='left 500ms ease 0ms, bottom 500ms ease 0ms';
				if (me._alt_men.ggCurrentLogicStatePosition == 0) {
					me._alt_men.style.left = 'calc(50% - (100% / 2))';
					me._alt_men.style.bottom='60px';
				}
				else {
					me._alt_men.style.left='calc(50% - ((100% + 0px) / 2) + 0px)';
					me._alt_men.style.bottom='-60px';
				}
			}
		}
		me._alt_men.logicBlock_position();
		me._alt_men.ggUpdatePosition=function (useTransition) {
		}
		el=me._kkresimler=document.createElement('div');
		el.ggId="K\xfc\xe7\xfck-resimler";
		el.ggDx=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_container ";
		el.ggType='container';
		hs ='';
		hs+='bottom : 0px;';
		hs+='height : 120px;';
		hs+='left : calc(50% - ((100% + 0px) / 2) + 0px);';
		hs+='position : absolute;';
		hs+='visibility : inherit;';
		hs+='width : 100%;';
		hs+='pointer-events:none;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me._kkresimler.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._kkresimler.ggUpdatePosition=function (useTransition) {
		}
		el=me._thumbnail_menu=document.createElement('div');
		els=me._thumbnail_menu__content=document.createElement('div');
		els.className='ggskin ggskin_subelement ggskin_scrollarea';
		el.ggContent=els;
		el.appendChild(els);
		el.ggHorScrollVisible = false;
		el.ggVertScrollVisible = false;
		el.ggContentLeftOffset = 0;
		el.ggContentTopOffset = 0;
		el.ggContentWidth = 0;
		el.ggContentHeight = 0;
		el.ggDragInertiaX = 0;
		el.ggDragInertiaY = 0;
		el.ggVPercentVisible = 1.0;
		el.ggHPercentVisible = 1.0;
		el.ggIsDragging = false;
		hs ='';
		hs+='height : 111.5px;';
		hs+='left : 50%;';
		hs+='margin-left : -91.5px;';
		hs+='margin-top : -55.75px;';
		hs+='overflow-x : visible;';
		hs+='overflow-y : visible;';
		hs+='position : absolute;';
		hs+='top : 50%;';
		hs+='width : 183px;';
		hs+="backdrop-filter: blur(5px);";
		els.setAttribute('style',hs);
		me._thumbnail_menu.ggScrollByX = function(diffX) {
			if(!me._thumbnail_menu.ggHorScrollVisible || diffX == 0 || me._thumbnail_menu.ggHPercentVisible >= 1.0) return;
			me._thumbnail_menu.ggScrollPosX = (me._thumbnail_menu__horScrollFg.offsetLeft + diffX);
			me._thumbnail_menu.ggScrollPosX = Math.max(me._thumbnail_menu.ggScrollPosX, 0);
			me._thumbnail_menu.ggScrollPosX = Math.min(me._thumbnail_menu.ggScrollPosX, me._thumbnail_menu__horScrollBg.offsetWidth - me._thumbnail_menu__horScrollFg.offsetWidth);
			me._thumbnail_menu__horScrollFg.style.left = me._thumbnail_menu.ggScrollPosX + 'px';
			let percentScrolled = me._thumbnail_menu.ggScrollPosX / (me._thumbnail_menu__horScrollBg.offsetWidth - me._thumbnail_menu__horScrollFg.offsetWidth);
			me._thumbnail_menu__content.style.left = -(Math.round((me._thumbnail_menu.ggContentWidth * (1.0 - me._thumbnail_menu.ggHPercentVisible)) * percentScrolled)) + me._thumbnail_menu.ggContentLeftOffset + 'px';
			me._thumbnail_menu.ggScrollPosXPercent = (me._thumbnail_menu__horScrollFg.offsetLeft / me._thumbnail_menu__horScrollBg.offsetWidth);
		}
		me._thumbnail_menu.ggScrollByXSmooth = function(diffX) {
			if(!me._thumbnail_menu.ggHorScrollVisible || diffX == 0 || me._thumbnail_menu.ggHPercentVisible >= 1.0) return;
			var scrollPerInterval = diffX / 25;
			var scrollCurrX = 0;
			var id = setInterval(function() {
				scrollCurrX += scrollPerInterval;
				me._thumbnail_menu.ggScrollPosX += scrollPerInterval;
				if (diffX > 0 && (scrollCurrX >= diffX || me._thumbnail_menu.ggScrollPosX >= me._thumbnail_menu__horScrollBg.offsetWidth - me._thumbnail_menu__horScrollFg.offsetWidth)) {
					me._thumbnail_menu.ggScrollPosX = Math.min(me._thumbnail_menu.ggScrollPosX, me._thumbnail_menu__horScrollBg.offsetWidth - me._thumbnail_menu__horScrollFg.offsetWidth);
					clearInterval(id);
				}
				if (diffX < 0 && (scrollCurrX <= diffX || me._thumbnail_menu.ggScrollPosX <= 0)) {
					me._thumbnail_menu.ggScrollPosX = Math.max(me._thumbnail_menu.ggScrollPosX, 0);
					clearInterval(id);
				}
			me._thumbnail_menu__horScrollFg.style.left = me._thumbnail_menu.ggScrollPosX + 'px';
			let percentScrolled = me._thumbnail_menu.ggScrollPosX / (me._thumbnail_menu__horScrollBg.offsetWidth - me._thumbnail_menu__horScrollFg.offsetWidth);
			me._thumbnail_menu__content.style.left = -(Math.round((me._thumbnail_menu.ggContentWidth * (1.0 - me._thumbnail_menu.ggHPercentVisible)) * percentScrolled)) + me._thumbnail_menu.ggContentLeftOffset + 'px';
			me._thumbnail_menu.ggScrollPosXPercent = (me._thumbnail_menu__horScrollFg.offsetLeft / me._thumbnail_menu__horScrollBg.offsetWidth);
			}, 10);
		}
		me._thumbnail_menu.ggScrollByY = function(diffY) {
			if(!me._thumbnail_menu.ggVertScrollVisible || diffY == 0 || me._thumbnail_menu.ggVPercentVisible >= 1.0) return;
			me._thumbnail_menu.ggScrollPosY = (me._thumbnail_menu__vertScrollFg.offsetTop + diffY);
			me._thumbnail_menu.ggScrollPosY = Math.max(me._thumbnail_menu.ggScrollPosY, 0);
			me._thumbnail_menu.ggScrollPosY = Math.min(me._thumbnail_menu.ggScrollPosY, me._thumbnail_menu__vertScrollBg.offsetHeight - me._thumbnail_menu__vertScrollFg.offsetHeight);
			me._thumbnail_menu__vertScrollFg.style.top = me._thumbnail_menu.ggScrollPosY + 'px';
			let percentScrolled = me._thumbnail_menu.ggScrollPosY / (me._thumbnail_menu__vertScrollBg.offsetHeight - me._thumbnail_menu__vertScrollFg.offsetHeight);
			me._thumbnail_menu__content.style.top = -(Math.round((me._thumbnail_menu.ggContentHeight * (1.0 - me._thumbnail_menu.ggVPercentVisible)) * percentScrolled)) + me._thumbnail_menu.ggContentTopOffset + 'px';
			me._thumbnail_menu.ggScrollPosYPercent = (me._thumbnail_menu__vertScrollFg.offsetTop / me._thumbnail_menu__vertScrollBg.offsetHeight);
		}
		me._thumbnail_menu.ggScrollByYSmooth = function(diffY) {
			if(!me._thumbnail_menu.ggVertScrollVisible || diffY == 0 || me._thumbnail_menu.ggVPercentVisible >= 1.0) return;
			var scrollPerInterval = diffY / 25;
			var scrollCurrY = 0;
			var id = setInterval(function() {
				scrollCurrY += scrollPerInterval;
				me._thumbnail_menu.ggScrollPosY += scrollPerInterval;
				if (diffY > 0 && (scrollCurrY >= diffY || me._thumbnail_menu.ggScrollPosY >= me._thumbnail_menu__vertScrollBg.offsetHeight - me._thumbnail_menu__vertScrollFg.offsetHeight)) {
					me._thumbnail_menu.ggScrollPosY = Math.min(me._thumbnail_menu.ggScrollPosY, me._thumbnail_menu__vertScrollBg.offsetHeight - me._thumbnail_menu__vertScrollFg.offsetHeight);
					clearInterval(id);
				}
				if (diffY < 0 && (scrollCurrY <= diffY || me._thumbnail_menu.ggScrollPosY <= 0)) {
					me._thumbnail_menu.ggScrollPosY = Math.max(me._thumbnail_menu.ggScrollPosY, 0);
					clearInterval(id);
				}
			me._thumbnail_menu__vertScrollFg.style.top = me._thumbnail_menu.ggScrollPosY + 'px';
			let percentScrolled = me._thumbnail_menu.ggScrollPosY / (me._thumbnail_menu__vertScrollBg.offsetHeight - me._thumbnail_menu__vertScrollFg.offsetHeight);
			me._thumbnail_menu__content.style.top = -(Math.round((me._thumbnail_menu.ggContentHeight * (1.0 - me._thumbnail_menu.ggVPercentVisible)) * percentScrolled)) + me._thumbnail_menu.ggContentTopOffset + 'px';
			me._thumbnail_menu.ggScrollPosYPercent = (me._thumbnail_menu__vertScrollFg.offsetTop / me._thumbnail_menu__vertScrollBg.offsetHeight);
			}, 10);
		}
		me._thumbnail_menu.ggScrollIntoView = function(posX, posY, width, height) {
			if (me._thumbnail_menu.ggHorScrollVisible) {
				if (posX < 0) {
					var diffX = Math.floor(posX * me._thumbnail_menu.ggHPercentVisible);
					me._thumbnail_menu.ggScrollByXSmooth(diffX);
				} else if (posX + width > me._thumbnail_menu.clientWidth - (me._thumbnail_menu.ggVertScrollVisible ? 15 : 0)) {
					var diffX = Math.ceil(((posX + width) - (me._thumbnail_menu.clientWidth - (me._thumbnail_menu.ggVertScrollVisible ? 15 : 0))) * me._thumbnail_menu.ggHPercentVisible);
					me._thumbnail_menu.ggScrollByXSmooth(diffX);
				}
			}
			if (me._thumbnail_menu.ggVertScrollVisible) {
				if (posY < 0) {
					var diffY = Math.floor(posY * me._thumbnail_menu.ggVPercentVisible);
					me._thumbnail_menu.ggScrollByYSmooth(diffY);
				} else if (posY + height > me._thumbnail_menu.clientHeight - (me._thumbnail_menu.ggHorScrollVisible ? 15 : 0)) {
					var diffY = Math.ceil(((posY + height) - (me._thumbnail_menu.clientHeight - (me._thumbnail_menu.ggHorScrollVisible ? 15 : 0))) * me._thumbnail_menu.ggVPercentVisible);
					me._thumbnail_menu.ggScrollByYSmooth(diffY);
				}
			}
		}
		me._thumbnail_menu__content.mousetouchend = e => {
			let inertiaInterval = setInterval(function() {
				me._thumbnail_menu.ggDragInertiaX *= 0.96;
				me._thumbnail_menu.ggDragInertiaY *= 0.96;
				me._thumbnail_menu.ggScrollByX(me._thumbnail_menu.ggDragInertiaX);
				me._thumbnail_menu.ggScrollByY(me._thumbnail_menu.ggDragInertiaY);
				if (Math.abs(me._thumbnail_menu.ggDragInertiaX) < 1.0 && Math.abs(me._thumbnail_menu.ggDragInertiaY) < 1.0) {
					clearInterval(inertiaInterval);
				}
				}, 10);
			me._thumbnail_menu__content.onmouseup = null;
			me._thumbnail_menu__content.onmousemove = null;
			me._thumbnail_menu__content.ontouchend = null;
			me._thumbnail_menu__content.ontouchmove = null;
			me._thumbnail_menu__content.onpointerup = null;
			me._thumbnail_menu__content.onpointermove = null;
			setTimeout(function() { me._thumbnail_menu.ggIsDragging = false; }, 100);
		}
		me._thumbnail_menu__content.mousetouchmove = e => {
			e = e || window.event;
			e.preventDefault();
			var t = e.touches;
			var eventX = t ? t[0].clientX : e.clientX;
			var eventY = t ? t[0].clientY : e.clientY;
			if (Math.abs(eventX - me._thumbnail_menu.ggDragStartX) > 10 || Math.abs(eventY - me._thumbnail_menu.ggDragStartY) > 10) me._thumbnail_menu.ggIsDragging = true;
			var diffX = (eventX - me._thumbnail_menu.ggDragLastX) * me._thumbnail_menu.ggHPercentVisible;
			var diffY = (eventY - me._thumbnail_menu.ggDragLastY) * me._thumbnail_menu.ggVPercentVisible;
			me._thumbnail_menu.ggDragInertiaX = -diffX;
			me._thumbnail_menu.ggDragInertiaY = -diffY;
			me._thumbnail_menu.ggDragLastX = eventX;
			me._thumbnail_menu.ggDragLastY = eventY;
			me._thumbnail_menu.ggScrollByX(-diffX);
			me._thumbnail_menu.ggScrollByY(-diffY);
		}
		me._thumbnail_menu__content.mousetouchstart = e => {
			e = e || window.event;
			var t = e.touches;
			me._thumbnail_menu.ggDragLastX = me._thumbnail_menu.ggDragStartX = t ? t[0].clientX : e.clientX;
			me._thumbnail_menu.ggDragLastY = me._thumbnail_menu.ggDragStartY = t ? t[0].clientY : e.clientY;
			me._thumbnail_menu__content.onmouseup = me._thumbnail_menu__content.mousetouchend;
			me._thumbnail_menu__content.ontouchend = me._thumbnail_menu__content.mousetouchend;
			me._thumbnail_menu__content.onmousemove = me._thumbnail_menu__content.mousetouchmove;
			me._thumbnail_menu__content.ontouchmove = me._thumbnail_menu__content.mousetouchmove;
			if (player.getOS() == 1 && navigator.maxTouchPoints > 0) {
				me._thumbnail_menu__content.onpointerup = me._thumbnail_menu__content.ontouchend;
				me._thumbnail_menu__content.onpointermove = me._thumbnail_menu__content.ontouchmove;
			}
		}
		els.onmousedown = me._thumbnail_menu__content.mousetouchstart;
		els.ontouchstart = me._thumbnail_menu__content.mousetouchstart;
		if (player.getOS() == 1 && navigator.maxTouchPoints > 0) {
			els.onpointerdown = me._thumbnail_menu__content.mousetouchstart;
		}
		elHorScrollBg = me._thumbnail_menu__horScrollBg = document.createElement('div');
		el.appendChild(elHorScrollBg);
		elHorScrollBg.setAttribute('style', 'position: absolute; left: 0px; bottom: 0px; visibility: hidden; width: 900px; height: 15px; background-color: rgba(21,21,21,1); pointer-events: auto;');
		elHorScrollBg.className='ggskin ggskin_scrollarea_hscrollbg';
		elHorScrollFg = me._thumbnail_menu__horScrollFg = document.createElement('div');
		elHorScrollBg.appendChild(elHorScrollFg);
		elHorScrollFg.className='ggskin ggskin_scrollarea_hscrollfg';
		elHorScrollFg.setAttribute('style', 'position: absolute; left: 0px; top: 0px; visibility: hidden; width: 900px; height: 15px; background-color: rgba(255,255,255,1); pointer-events: auto;');
		me._thumbnail_menu.ggScrollPosX = 0;
		me._thumbnail_menu.ggScrollPosXPercent = 0.0;
		elHorScrollFg.onmousedown = function(e) {
			if (player.getOS() == 1 && navigator.maxTouchPoints > 0) return;
			e = e || window.event;
			e.preventDefault();
			e.stopPropagation();
			me._thumbnail_menu.ggDragLastX = e.clientX;
			document.onmouseup = function() {
				let inertiaInterval = setInterval(function() {
					me._thumbnail_menu.ggDragInertiaX *= 0.96;
					me._thumbnail_menu.ggScrollByX(me._thumbnail_menu.ggDragInertiaX);
					if (Math.abs(me._thumbnail_menu.ggDragInertiaX) < 1.0) {
						clearInterval(inertiaInterval);
					}
					}, 10);
				document.onmouseup = null;
				document.onmousemove = null;
			}
			document.onmousemove = function(e) {
				e = e || window.event;
				e.preventDefault();
				var diffX = e.clientX - me._thumbnail_menu.ggDragLastX;
				me._thumbnail_menu.ggDragInertiaX = diffX;
				me._thumbnail_menu.ggDragLastX = e.clientX;
				me._thumbnail_menu.ggScrollByX(diffX);
			}
		}
		elHorScrollFg.ontouchstart = function(e) {
			e = e || window.event;
			e.preventDefault();
			e.stopPropagation();
			var t = e.touches;
			me._thumbnail_menu.ggDragLastX = t ? t[0].clientX : e.clientX;
			document.ontouchend = function() {
				let inertiaInterval = setInterval(function() {
					me._thumbnail_menu.ggDragInertiaX *= 0.96;
					me._thumbnail_menu.ggScrollByX(me._thumbnail_menu.ggDragInertiaX);
					if (Math.abs(me._thumbnail_menu.ggDragInertiaX) < 1.0) {
						clearInterval(inertiaInterval);
					}
					}, 10);
				document.ontouchend = null;
				document.ontouchmove = null;
				document.onpointerup = null;
				document.onpointermove = null;
			}
			if (player.getOS() == 1 && navigator.maxTouchPoints > 0) {
				document.onpointerup = document.ontouchend;
			}
			document.ontouchmove = function(e) {
				e = e || window.event;
				e.preventDefault();
				var t = e.touches;
				var diffX = (t ? t[0].clientX : e.clientX) - me._thumbnail_menu.ggDragLastX;
				me._thumbnail_menu.ggDragInertiaX = diffX;
				me._thumbnail_menu.ggDragLastX = t ? t[0].clientX : e.clientX;
				me._thumbnail_menu.ggScrollByX(diffX);
			}
			if (player.getOS() == 1 && navigator.maxTouchPoints > 0) {
				document.onpointermove = document.ontouchmove;
			}
		}
		if (player.getOS() == 1 && navigator.maxTouchPoints > 0) {
			elHorScrollFg.onpointerdown = elHorScrollFg.ontouchstart;
		}
		elHorScrollBg.onmousedown = function(e) {
			e = e || window.event;
			e.preventDefault();
			var diffX = me._thumbnail_menu.ggScrollWidth;
			if (e.offsetX < me._thumbnail_menu.ggScrollPosX) {
				diffX = diffX * -1;
			}
			me._thumbnail_menu.ggScrollByXSmooth(diffX);
		}
		elHorScrollBg.ontouchstart = function(e) {
			e = e || window.event;
			e.preventDefault();
			e.stopPropagation();
			var t = e.touches;
			var rect = me._thumbnail_menu__horScrollBg.getBoundingClientRect();
			var diffX = me._thumbnail_menu.ggScrollWidth;
			if ((t[0].clientX - rect.left) < me._thumbnail_menu.ggScrollPosX) {
				diffX = diffX * -1;
			}
			me._thumbnail_menu.ggScrollByXSmooth(diffX);
		}
		el.addEventListener('wheel', function(e) {
			e.preventDefault();
			var wheelDelta = Math.sign(e.deltaX);
			me._thumbnail_menu.ggScrollByXSmooth(30 * me._thumbnail_menu.ggHPercentVisible * wheelDelta);
		});
		elCornerBg = me._thumbnail_menu__cornerBg = document.createElement('div');
		el.appendChild(elCornerBg);
		elCornerBg.setAttribute('style', 'position: absolute; right: 0px; bottom: 0px; visibility: hidden; width: 15px; height: 15px; background-color: rgba(255,19,161,0);');
		elCornerBg.className='ggskin ggskin_scrollarea_scrollcorner';
		el.ggId="thumbnail_menu";
		el.ggDx=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_scrollarea ";
		el.ggType='scrollarea';
		hs ='';
		hs+='background : #000000;';
		hs+='border : 0px solid #000000;';
		hs+='height : 100%;';
		hs+='left : calc(50% - ((100% + 0px) / 2) + 0px);';
		hs+='overflow : hidden;';
		hs+='position : absolute;';
		hs+='top : 60px;';
		hs+='visibility : inherit;';
		hs+='width : 100%;';
		hs+='pointer-events:none;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me._thumbnail_menu.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._thumbnail_menu.logicBlock_alpha = function() {
			var newLogicStateAlpha;
			if (
				((player.getVariableValue('vis_thumbnail_menu', me.hotspot ? me.hotspot.id : (player.hotspot ? player.hotspot.id : '')) == false))
			)
			{
				newLogicStateAlpha = 0;
			}
			else {
				newLogicStateAlpha = -1;
			}
			if (me._thumbnail_menu.ggCurrentLogicStateAlpha != newLogicStateAlpha) {
				me._thumbnail_menu.ggCurrentLogicStateAlpha = newLogicStateAlpha;
				me._thumbnail_menu.style.transition='opacity 500ms ease 0ms';
				if (me._thumbnail_menu.ggCurrentLogicStateAlpha == 0) {
					setTimeout(function() { if (me._thumbnail_menu.style.opacity == 0.0) { me._thumbnail_menu.style.visibility="hidden"; } }, 505);
					me._thumbnail_menu.style.opacity=0;
				}
				else {
					me._thumbnail_menu.style.visibility=me._thumbnail_menu.ggVisible?'inherit':'hidden';
					me._thumbnail_menu.style.opacity=1;
				}
			}
		}
		me._thumbnail_menu.logicBlock_alpha();
		me._thumbnail_menu.ggUpdatePosition=function (useTransition) {
			{
				var horScrollWasVisible = this.ggHorScrollVisible;
				var vertScrollWasVisible = this.ggVertScrollVisible;
				this.ggContent.style.left = '0px';
				this.ggContent.style.top = '0px';
				this.ggContentLeftOffset = 0;
				this.ggContentTopOffset = 0;
				var offsetWidthWithScale = this.getBoundingClientRect().width;
				var offsetHeightWithScale = this.getBoundingClientRect().height;
				var domRectContent = this.ggContent.getBoundingClientRect();
				var minX = 0;
				var minY = 0;
				var maxX = 0;
				var maxY = 0;
				var stack=[];
				stack.push(this.ggContent);
				while(stack.length>0) {
					var e=stack.pop();
					if (e!=this.ggContent && e.getBoundingClientRect && e.style['display']!='none' && (e.offsetWidth != 0 || e.offsetHeight != 0)) {
						var domRectChild = e.getBoundingClientRect();
						var diffX = domRectChild.left - domRectContent.left;
						minX = Math.min(minX, diffX);
						maxX = Math.max(maxX, diffX + domRectChild.width);
						var diffY = domRectChild.top - domRectContent.top;
						minY = Math.min(minY, diffY);
						maxY = Math.max(maxY, diffY + domRectChild.height);
					}
					if (e.hasChildNodes() && e.style['display']!='none' && e.style['overflow']!='hidden') {
						for(var i=0;i<e.childNodes.length;i++) {
							stack.push(e.childNodes[i]);
						}
					}
				}
				if (minX < 0) this.ggContentLeftOffset = -minX;
				if (minY < 0) this.ggContentTopOffset = -minY;
				this.ggContent.style.left = this.ggContentLeftOffset + 'px';
				this.ggContent.style.top = this.ggContentTopOffset + 'px';
				var contentWidth = maxX - minX;
				this.ggContent.style.width = contentWidth + 'px';
				var contentHeight = maxY - minY;
				this.ggContent.style.height = contentHeight + 'px';
			var scaleX = this.getBoundingClientRect().width / this.offsetWidth;
				this.ggContentWidth = contentWidth / scaleX;
			var scaleY = this.getBoundingClientRect().height / this.offsetHeight;
				this.ggContentHeight = contentHeight / scaleY;
				var containerWidth = offsetWidthWithScale;
				if (this.ggVertScrollVisible) containerWidth -= 15;
				if (contentWidth < containerWidth) {
					this.ggContent.style.left = '50%';
					this.ggContent.style.marginLeft = ((contentWidth/-2) - (this.ggVertScrollVisible ? (15/2) : 0)) + 'px';
				}
				else {
					this.ggContent.style.left = this.ggContentLeftOffset + 'px';
					this.ggContent.style.marginLeft = '0px';
				}
				var containerHeight = this.clientHeight;
				if (this.ggHorScrollVisible) containerHeight -= 15;
				if (contentHeight < containerHeight) {
					this.ggContent.style.top = '50%';
					this.ggContent.style.marginTop = ((contentHeight/-2) - (this.ggHorScrollVisible ? (15/2) : 0))  + 'px';
				}
				else {
					this.ggContent.style.top = this.ggContentTopOffset + 'px';
					this.ggContent.style.marginTop = '0px';
				}
				if (contentWidth > Math.ceil(offsetWidthWithScale)) {
					me._thumbnail_menu__horScrollBg.style.visibility = 'inherit';
					me._thumbnail_menu__horScrollFg.style.visibility = 'inherit';
					me._thumbnail_menu.ggHorScrollVisible = true;
				} else {
					me._thumbnail_menu__horScrollBg.style.visibility = 'hidden';
					me._thumbnail_menu__horScrollFg.style.visibility = 'hidden';
					me._thumbnail_menu.ggHorScrollVisible = false;
				}
				if(me._thumbnail_menu.ggHorScrollVisible) {
					me._thumbnail_menu.ggAvailableHeight = me._thumbnail_menu.clientHeight - 15;
					if (me._thumbnail_menu.ggVertScrollVisible) {
						me._thumbnail_menu.ggAvailableWidth = me._thumbnail_menu.clientWidth - 15;
						me._thumbnail_menu.ggAvailableWidthWithScale = me._thumbnail_menu.getBoundingClientRect().width - me._thumbnail_menu__horScrollBg.getBoundingClientRect().height;
					} else {
						me._thumbnail_menu.ggAvailableWidth = me._thumbnail_menu.clientWidth;
						me._thumbnail_menu.ggAvailableWidthWithScale = me._thumbnail_menu.getBoundingClientRect().width;
					}
					me._thumbnail_menu__horScrollBg.style.width = me._thumbnail_menu.ggAvailableWidth + 'px';
					me._thumbnail_menu.ggHPercentVisible = contentWidth != 0 ? me._thumbnail_menu.ggAvailableWidthWithScale / contentWidth : 0.0;
					if (me._thumbnail_menu.ggHPercentVisible > 1.0) me._thumbnail_menu.ggHPercentVisible = 1.0;
					me._thumbnail_menu.ggScrollWidth = Math.round(me._thumbnail_menu__horScrollBg.offsetWidth * me._thumbnail_menu.ggHPercentVisible);
					me._thumbnail_menu__horScrollFg.style.width = me._thumbnail_menu.ggScrollWidth + 'px';
					me._thumbnail_menu.ggScrollPosX = me._thumbnail_menu.ggScrollPosXPercent * me._thumbnail_menu.ggAvailableWidth;
					me._thumbnail_menu.ggScrollPosX = Math.min(me._thumbnail_menu.ggScrollPosX, me._thumbnail_menu__horScrollBg.offsetWidth - me._thumbnail_menu__horScrollFg.offsetWidth);
					me._thumbnail_menu__horScrollFg.style.left = me._thumbnail_menu.ggScrollPosX + 'px';
					if (me._thumbnail_menu.ggHPercentVisible < 1.0) {
						let percentScrolled = me._thumbnail_menu.ggScrollPosX / (me._thumbnail_menu__horScrollBg.offsetWidth - me._thumbnail_menu__horScrollFg.offsetWidth);
						me._thumbnail_menu__content.style.left = -(Math.round((me._thumbnail_menu.ggContentWidth * (1.0 - me._thumbnail_menu.ggHPercentVisible)) * percentScrolled)) + this.ggContentLeftOffset + 'px';
					}
				} else {
					me._thumbnail_menu.ggAvailableHeight = me._thumbnail_menu.clientHeight;
					me._thumbnail_menu.ggScrollPosX = 0;
					me._thumbnail_menu.ggScrollPosXPercent = 0.0;
				}
				if(horScrollWasVisible != me._thumbnail_menu.ggHorScrollVisible || vertScrollWasVisible != me._thumbnail_menu.ggVertScrollVisible) {
					skin.updateSize(me._thumbnail_menu);
					me._thumbnail_menu.ggUpdatePosition();
				}
			}
		}
		el=me._thumbnail_cloner=document.createElement('div');
		el.isDragging = function() {
			let scrollerParent = me._thumbnail_cloner;
			while ((scrollerParent = scrollerParent.parentNode) != null) {
				if (scrollerParent.hasOwnProperty('ggIsDragging') && scrollerParent.ggIsDragging == true) return true;
			}
			return false;
		}
		el.ggNumRepeat = 1;
		el.ggNumRows = 0;
		el.ggNumCols = 0;
		el.ggCloneOffset = 0;
		el.ggCloneOffsetChanged = false;
		el.ggWidth = 150;
		el.ggHeight = 75;
		el.ggUpdating = false;
		el.ggFilter = [];
		el.ggFilterHsSkinId = '';
		el.ggInstances = [];
		el.ggNumFilterPassed = 0;
		el.getFilteredNodes = function(tourNodes, filter) {
			var filteredNodes = [];
			for (var i = 0; i < tourNodes.length; i++) {
				var nodeId = tourNodes[i];
				var passed = true;
				var nodeData = player.getNodeUserdata(nodeId);
				if (filter.length > 0) {
					for (var j=0; j < filter.length; j++) {
						if (nodeData['tags'].indexOf(filter[j].trim()) == -1) passed = false;
					}
				}
				if (passed) {
					filteredNodes.push(nodeId);
				}
			}
			return filteredNodes;
		}
		el.ggUpdate = function(filter) {
			if(me._thumbnail_cloner.ggUpdating == true) return;
			me._thumbnail_cloner.ggUpdating = true;
			var el=me._thumbnail_cloner;
			var curNumRows = 0;
			curNumRows = me._thumbnail_cloner.ggNumRepeat;
			if (curNumRows < 1) curNumRows = 1;
			if (typeof filter=='object') {
				el.ggFilter = filter;
			} else {
				filter = el.ggFilter;
			};
			if (me.ggTag) filter.push(me.ggTag);
			filter=filter.sort();
			if ((el.ggNumRows == curNumRows) && (el.ggInstances.length > 0) && (filter.length === el.ggCurrentFilter.length) && (filter.every(function(value, index) { return value === el.ggCurrentFilter[index] }) )) {
				me._thumbnail_cloner.ggUpdating = false;
				return;
			} else {
				el.ggNumCols = 1;
				el.ggNumRows = curNumRows;
			var centerOffsetHor = 0;
			var centerOffsetVert = 0;
				me._thumbnail_cloner.ggCloneOffsetChanged = false;
			}
			el.ggCurrentFilter = filter;
			el.ggInstances = [];
			if (el.hasChildNodes() == true) {
				while (el.firstChild) {
					el.removeChild(el.firstChild);
				}
			}
			var tourNodes = player.getNodeIds();
			if (tourNodes.length == 0) {
				me._thumbnail_cloner.ggUpdating = false;
				return;
			}
			var row = 0;
			var column = 0;
			var currentIndex = 0;
			var keepCloning = true;
			tourNodes = me._thumbnail_cloner.getFilteredNodes(tourNodes, filter);
			me._thumbnail_cloner.ggNumFilterPassed = tourNodes.length;
			for (var i = 0; i < tourNodes.length; i++) {
				var nodeId = tourNodes[i];
				var nodeData = player.getNodeUserdata(nodeId);
				if (!keepCloning || i < me._thumbnail_cloner.ggCloneOffset) continue;
				var parameter={};
				parameter.top = centerOffsetVert + (row * me._thumbnail_cloner.ggHeight) + 'px';
				parameter.left = centerOffsetHor + (column * me._thumbnail_cloner.ggWidth) + 'px';
				parameter.width=me._thumbnail_cloner.ggWidth + 'px';
				parameter.height=me._thumbnail_cloner.ggHeight + 'px';
				parameter.index=currentIndex;
				parameter.title=nodeData['title'];
				var inst = new SkinCloner_thumbnail_cloner_Class(nodeId, me, el, parameter);
				currentIndex++;
				el.ggInstances.push(inst);
				el.appendChild(inst.__div);
				inst.__div.ggObj=inst;
				skin.updateSize(inst.__div);
				row++;
				if (row >= el.ggNumRows) {
					row = 0;
					column++;
					el.ggNumCols++;
				}
			}
			me._thumbnail_cloner.ggNodeCount = me._thumbnail_cloner.ggNumFilterPassed;
			me._thumbnail_cloner.ggUpdating = false;
			player.triggerEvent('clonerchanged');
			if (me._thumbnail_cloner.parentNode && me._thumbnail_cloner.parentNode.classList.contains('ggskin_subelement') && me._thumbnail_cloner.parentNode.parentNode.classList.contains('ggskin_scrollarea')) me._thumbnail_cloner.parentNode.parentNode.ggUpdatePosition();
		}
		el.ggFilter = [];
		el.ggId="thumbnail_cloner";
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_cloner ";
		el.ggType='cloner';
		hs ='';
		hs+='height : 75px;';
		hs+='left : 0px;';
		hs+='overflow : visible;';
		hs+='position : absolute;';
		hs+='top : 0px;';
		hs+='visibility : inherit;';
		hs+='width : 150px;';
		hs+='pointer-events:none;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me._thumbnail_cloner.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._thumbnail_cloner.ggUpdateConditionNodeChange=function () {
			var cnode=player.getCurrentNode();
			for(var i=0; i<me._thumbnail_cloner.childNodes.length; i++) {
				var child=me._thumbnail_cloner.childNodes[i];
				if (child.ggObj && child.ggObj.ggNodeId==cnode) {
			        var childOffX = child.offsetLeft;
			        var childOffY = child.offsetTop;
					var p = child.parentElement;
			        while (p != null && p!==this.divSkin) {
						if (p.ggType && p.ggType == 'scrollarea') {
							p.ggScrollIntoView(childOffX, childOffY, child.clientWidth, child.clientHeight);
						}
						childOffX += p.offsetLeft;
						childOffY += p.offsetTop;
						p = p.parentElement;
					}
				}
			}
		}
		me._thumbnail_cloner.ggUpdatePosition=function (useTransition) {
			me._thumbnail_cloner.ggUpdate();
		}
		me._thumbnail_menu__content.appendChild(me._thumbnail_cloner);
		me._kkresimler.appendChild(me._thumbnail_menu);
		el=me._stbuttonlar_1=document.createElement('div');
		el.ggId="\xfcst-buttonlar_1";
		el.ggDx=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_rectangle ";
		el.ggType='rectangle';
		hs ='';
		hs+='border : 0px solid #000000;';
		hs+='cursor : default;';
		hs+='height : 40px;';
		hs+='left : calc(50% - ((100% + 0px) / 2) + 0px);';
		hs+='position : absolute;';
		hs+='top : 0px;';
		hs+='visibility : inherit;';
		hs+='width : 100%;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me._stbuttonlar_1.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._stbuttonlar_1.ggUpdatePosition=function (useTransition) {
		}
		el=me.__360gradansicht=document.createElement('div');
		el.ggId="360gradansicht";
		el.ggDx=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_rectangle ";
		el.ggType='rectangle';
		hs ='';
		hs+='background : #000000;';
		hs+='border : 0px solid #000000;';
		hs+='bottom : -20px;';
		hs+='cursor : default;';
		hs+='height : 45px;';
		hs+='left : calc(50% - ((225% + 0px) / 2) + 0px);';
		hs+='position : absolute;';
		hs+='visibility : inherit;';
		hs+='width : 225%;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me.__360gradansicht.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me.__360gradansicht.ggUpdatePosition=function (useTransition) {
		}
		me._stbuttonlar_1.appendChild(me.__360gradansicht);
		el=me._container_2=document.createElement('div');
		el.ggId="Container 2";
		el.ggDx=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_container ";
		el.ggType='container';
		hs ='';
		hs+='bottom : 25px;';
		hs+='height : 39px;';
		hs+='left : calc(50% - ((257px + 0px) / 2) + 0px);';
		hs+='position : absolute;';
		hs+='visibility : inherit;';
		hs+='width : 257px;';
		hs+='pointer-events:none;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me._container_2.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._container_2.ggUpdatePosition=function (useTransition) {
		}
		el=me.__5=document.createElement('div');
		el.ggId="5";
		el.ggDx=110;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_rectangle ";
		el.ggType='rectangle';
		hs ='';
		hs+='background : #000000;';
		hs+='border : 2px solid #ffffff;';
		hs+='bottom : 2px;';
		hs+='cursor : pointer;';
		hs+='height : 36px;';
		hs+='left : calc(50% - ((36px + 4px) / 2) + 110px);';
		hs+='position : absolute;';
		hs+='visibility : inherit;';
		hs+='width : 36px;';
		hs+='pointer-events:auto;';
		hs+='border-radius: 7px 7px 7px 7px;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me.__5.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me.__5.logicBlock_backgroundcolor = function() {
			var newLogicStateBackgroundColor;
			if (
				((me.elementMouseOver['_5'] == true))
			)
			{
				newLogicStateBackgroundColor = 0;
			}
			else {
				newLogicStateBackgroundColor = -1;
			}
			if (me.__5.ggCurrentLogicStateBackgroundColor != newLogicStateBackgroundColor) {
				me.__5.ggCurrentLogicStateBackgroundColor = newLogicStateBackgroundColor;
				me.__5.style.transition='background-color 0s';
				if (me.__5.ggCurrentLogicStateBackgroundColor == 0) {
					me.__5.style.backgroundColor="rgba(70,65,95,1)";
				}
				else {
					me.__5.style.backgroundColor="rgba(0,0,0,1)";
				}
			}
		}
		me.__5.logicBlock_backgroundcolor();
		me.__5.onmouseenter=function (e) {
			me.elementMouseOver['_5']=true;
			me.__5.logicBlock_backgroundcolor();
		}
		me.__5.onmousedown=function (e) {
			me.elementMouseDown['_5']=true;
		}
		me.__5.onmouseup=function (e) {
			me.elementMouseDown['_5']=false;
		}
		me.__5.onmouseleave=function (e) {
			me.elementMouseDown['_5']=false;
			me.elementMouseOver['_5']=false;
			me.__5.logicBlock_backgroundcolor();
		}
		me.__5.ggCurrentLogicStateBackgroundColor = -1;
		me.__5.ggUpdateConditionTimer=function () {
			if (me.elementMouseDown['_5']) {
				player.changePanLog(-1.5,true);
			}
		}
		me.__5.ggUpdatePosition=function (useTransition) {
		}
		el=me._button_image_right=document.createElement('div');
		els=me._button_image_right__img=document.createElement('img');
		els.className='ggskin ggskin_svg';
		hs='data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0nMS4wJyBlbmNvZGluZz0ndXRmLTgnPz4KPCFET0NUWVBFIHN2ZyBQVUJMSUMgJy0vL1czQy8vRFREIFNWRyAxLjEgQmFzaWMvL0VOJyAnaHR0cDovL3d3dy53My5vcmcvR3JhcGhpY3MvU1ZHLzEuMS9EVEQvc3ZnMTEtYmFzaWMuZHRkJz4KPCEtLSBHYXJkZW4gR25vbWUgU29mdHdhcmUgLSBTa2luIEJ1dHRvbnMgLS0+CjxzdmcgaGVpZ2h0PSIzMnB4IiB5PSIwcHgiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDMyIDMyIiB3aWR0aD0iMzJweCIgYmFzZVByb2ZpbGU9ImJhc2ljIiBpZD0iTGF5ZXJfMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIi'+
			'B4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgeD0iMHB4Ij4KIDxnIG9wYWNpdHk9IjAuNCIgc3Ryb2tlLXdpZHRoPSIxLjUiIHN0cm9rZT0iIzNDM0MzQyI+CiAgPHBhdGggZD0iTTMuNSwxNkMzLjUwMSw5LjA5Niw5LjA5NiwzLjUwMSwxNiwzLjVsMCwwQzIyLjkwNCwzLjUwMSwyOC40OTksOS4wOTYsMjguNSwxNmwwLDAgICAgYy0wLjAwMSw2LjkwNC01LjU5NiwxMi40OTktMTIuNSwxMi41bDAsMEM5LjA5NiwyOC40OTksMy41MDEsMjIuOTA0LDMuNSwxNkwzLjUsMTZ6IE04Ljg1Myw4Ljg1MyAgICBDNy4wMjIsMTAuNjg2LDUu'+
			'ODk0LDEzLjIwNSw1Ljg5MywxNmwwLDBjMCwyLjc5NSwxLjEyOSw1LjMxNCwyLjk2LDcuMTQ2bDAsMGMxLjgzMywxLjgzMSw0LjM1MywyLjk2LDcuMTQ3LDIuOTYxbDAsMCAgICBjMi43OTUtMC4wMDEsNS4zMTQtMS4xMyw3LjE0Ni0yLjk2MWwwLDBjMS44MzItMS44MzIsMi45NjEtNC4zNTIsMi45NjEtNy4xNDZsMCwwYzAtMi43OTUtMS4xMjktNS4zMTQtMi45NjEtNy4xNDdsMCwwICAgIEMyMS4zMTQsNy4wMjIsMTguNzk1LDUuODk0LDE2LDUuODkzbDAsMEMxMy4yMDYsNS44OTQsMTAuNjg2LDcuMDIyLDguODUzLDguODUzTDguODUzLDguODUzeiIvPgogIDxwYXRoIGQ9Ik0xMi45MiwyMi42NT'+
			'djLTAuNDQyLTAuNDkxLTAuNDAzLTEuMjQ3LDAuMDg4LTEuNjg5bDAsMGw1LjQ4MS00LjkzOGwtNS40ODEtNC45Mzd2MCAgICBjLTAuNDkxLTAuNDQyLTAuNTMtMS4xOTktMC4wODgtMS42OWwwLDBjMC40NDEtMC40OTEsMS4xOTgtMC41MzEsMS42ODktMC4wODhsMCwwbDYuNDY4LDUuODI2ICAgIGMwLjI1MSwwLjIyNiwwLjM5NiwwLjU1MSwwLjM5NiwwLjg4OWwwLDBjMCwwLjMzNy0wLjE0NSwwLjY2My0wLjM5NiwwLjg4OWwwLDBsLTYuNDY4LDUuODI2Yy0wLjIyOSwwLjIwNi0wLjUxNSwwLjMwOC0wLjgsMC4zMDggICAgbDAsMEMxMy40ODIsMjMuMDUzLDEzLjE1NiwyMi45MTksMTIuOTIsMjIu'+
			'NjU3TDEyLjkyLDIyLjY1N3oiLz4KIDwvZz4KIDxnIHN0cm9rZS13aWR0aD0iMC4yIiBzdHJva2U9IiMwMDAwMDAiIGZpbGw9IiNGRkZGRkYiPgogIDxwYXRoIGQ9Ik0zLjUsMTZDMy41MDEsOS4wOTYsOS4wOTYsMy41MDEsMTYsMy41bDAsMEMyMi45MDQsMy41MDEsMjguNDk5LDkuMDk2LDI4LjUsMTZsMCwwICAgIGMtMC4wMDEsNi45MDQtNS41OTYsMTIuNDk5LTEyLjUsMTIuNWwwLDBDOS4wOTYsMjguNDk5LDMuNTAxLDIyLjkwNCwzLjUsMTZMMy41LDE2eiBNOC44NTMsOC44NTMgICAgQzcuMDIyLDEwLjY4Niw1Ljg5NCwxMy4yMDUsNS44OTMsMTZsMCwwYzAsMi43OTUsMS4xMjksNS4zMTQsMi'+
			'45Niw3LjE0NmwwLDBjMS44MzMsMS44MzEsNC4zNTMsMi45Niw3LjE0NywyLjk2MWwwLDAgICAgYzIuNzk1LTAuMDAxLDUuMzE0LTEuMTMsNy4xNDYtMi45NjFsMCwwYzEuODMyLTEuODMyLDIuOTYxLTQuMzUyLDIuOTYxLTcuMTQ2bDAsMGMwLTIuNzk1LTEuMTI5LTUuMzE0LTIuOTYxLTcuMTQ3bDAsMCAgICBDMjEuMzE0LDcuMDIyLDE4Ljc5NSw1Ljg5NCwxNiw1Ljg5M2wwLDBDMTMuMjA2LDUuODk0LDEwLjY4Niw3LjAyMiw4Ljg1Myw4Ljg1M0w4Ljg1Myw4Ljg1M3oiLz4KICA8cGF0aCBkPSJNMTIuOTIsMjIuNjU3Yy0wLjQ0Mi0wLjQ5MS0wLjQwMy0xLjI0NywwLjA4OC0xLjY4OWwwLDBsNS40'+
			'ODEtNC45MzhsLTUuNDgxLTQuOTM3djAgICAgYy0wLjQ5MS0wLjQ0Mi0wLjUzLTEuMTk5LTAuMDg4LTEuNjlsMCwwYzAuNDQxLTAuNDkxLDEuMTk4LTAuNTMxLDEuNjg5LTAuMDg4bDAsMGw2LjQ2OCw1LjgyNiAgICBjMC4yNTEsMC4yMjYsMC4zOTYsMC41NTEsMC4zOTYsMC44ODlsMCwwYzAsMC4zMzctMC4xNDUsMC42NjMtMC4zOTYsMC44ODlsMCwwbC02LjQ2OCw1LjgyNmMtMC4yMjksMC4yMDYtMC41MTUsMC4zMDgtMC44LDAuMzA4ICAgIGwwLDBDMTMuNDgyLDIzLjA1MywxMy4xNTYsMjIuOTE5LDEyLjkyLDIyLjY1N0wxMi45MiwyMi42NTd6Ii8+CiA8L2c+Cjwvc3ZnPgo=';
		me._button_image_right__img.setAttribute('src',hs);
		hs ='';
		hs += 'position: absolute;top: 0px;left: 0px;width: 100%;height: 100%;-webkit-user-drag:none;pointer-events:none;;';
		els.setAttribute('style', hs);
		els['ondragstart']=function() { return false; };
		el.appendChild(els);
		el.ggSubElement = els;
		el.ggId="button_image_right";
		el.ggDx=0;
		el.ggDy=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_svg ";
		el.ggType='svg';
		hs ='';
		hs+='cursor : pointer;';
		hs+='height : 40px;';
		hs+='left : calc(50% - ((40px + 0px) / 2) + 0px);';
		hs+='position : absolute;';
		hs+='top : calc(50% - ((40px + 0px) / 2) + 0px);';
		hs+='visibility : inherit;';
		hs+='width : 40px;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.setAttribute('aria-keyshortcuts', 'Right');
		el.style.transformOrigin='50% 50%';
		me._button_image_right.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._button_image_right.logicBlock_scaling = function() {
			var newLogicStateScaling;
			if (
				((me.elementMouseOver['button_image_right'] == true))
			)
			{
				newLogicStateScaling = 0;
			}
			else {
				newLogicStateScaling = -1;
			}
			if (me._button_image_right.ggCurrentLogicStateScaling != newLogicStateScaling) {
				me._button_image_right.ggCurrentLogicStateScaling = newLogicStateScaling;
				me._button_image_right.style.transition='transform 0s';
				if (me._button_image_right.ggCurrentLogicStateScaling == 0) {
					me._button_image_right.ggParameter.sx = 1.1;
					me._button_image_right.ggParameter.sy = 1.1;
					me._button_image_right.style.transform=parameterToTransform(me._button_image_right.ggParameter);
					skin.updateSize(me._button_image_right);
				}
				else {
					me._button_image_right.ggParameter.sx = 1;
					me._button_image_right.ggParameter.sy = 1;
					me._button_image_right.style.transform=parameterToTransform(me._button_image_right.ggParameter);
					skin.updateSize(me._button_image_right);
				}
			}
		}
		me._button_image_right.logicBlock_scaling();
		me._button_image_right.onmouseenter=function (e) {
			me.elementMouseOver['button_image_right']=true;
			me._button_image_right.logicBlock_scaling();
		}
		me._button_image_right.onmouseleave=function (e) {
			me.elementMouseOver['button_image_right']=false;
			me._button_image_right.logicBlock_scaling();
		}
		me._button_image_right.ggUpdatePosition=function (useTransition) {
		}
		me.__5.appendChild(me._button_image_right);
		me._container_2.appendChild(me.__5);
		el=me.__4=document.createElement('div');
		el.ggId="4";
		el.ggDx=60;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_rectangle ";
		el.ggType='rectangle';
		hs ='';
		hs+='background : #000000;';
		hs+='border : 2px solid #ffffff;';
		hs+='bottom : 2px;';
		hs+='cursor : pointer;';
		hs+='height : 36px;';
		hs+='left : calc(50% - ((36px + 4px) / 2) + 60px);';
		hs+='position : absolute;';
		hs+='visibility : inherit;';
		hs+='width : 36px;';
		hs+='pointer-events:auto;';
		hs+='border-radius: 7px 7px 7px 7px;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me.__4.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me.__4.logicBlock_backgroundcolor = function() {
			var newLogicStateBackgroundColor;
			if (
				((me.elementMouseOver['_4'] == true))
			)
			{
				newLogicStateBackgroundColor = 0;
			}
			else {
				newLogicStateBackgroundColor = -1;
			}
			if (me.__4.ggCurrentLogicStateBackgroundColor != newLogicStateBackgroundColor) {
				me.__4.ggCurrentLogicStateBackgroundColor = newLogicStateBackgroundColor;
				me.__4.style.transition='background-color 0s';
				if (me.__4.ggCurrentLogicStateBackgroundColor == 0) {
					me.__4.style.backgroundColor="rgba(70,65,95,1)";
				}
				else {
					me.__4.style.backgroundColor="rgba(0,0,0,1)";
				}
			}
		}
		me.__4.logicBlock_backgroundcolor();
		me.__4.onmouseenter=function (e) {
			me.elementMouseOver['_4']=true;
			me.__4.logicBlock_backgroundcolor();
		}
		me.__4.onmousedown=function (e) {
			me.elementMouseDown['_4']=true;
		}
		me.__4.onmouseup=function (e) {
			me.elementMouseDown['_4']=false;
		}
		me.__4.onmouseleave=function (e) {
			me.elementMouseDown['_4']=false;
			me.elementMouseOver['_4']=false;
			me.__4.logicBlock_backgroundcolor();
		}
		me.__4.ggCurrentLogicStateBackgroundColor = -1;
		me.__4.ggUpdateConditionTimer=function () {
			if (me.elementMouseDown['_4']) {
				player.changePanLog(1.5,true);
			}
		}
		me.__4.ggUpdatePosition=function (useTransition) {
		}
		el=me._button_image_left=document.createElement('div');
		els=me._button_image_left__img=document.createElement('img');
		els.className='ggskin ggskin_svg';
		hs='data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0nMS4wJyBlbmNvZGluZz0ndXRmLTgnPz4KPCFET0NUWVBFIHN2ZyBQVUJMSUMgJy0vL1czQy8vRFREIFNWRyAxLjEgQmFzaWMvL0VOJyAnaHR0cDovL3d3dy53My5vcmcvR3JhcGhpY3MvU1ZHLzEuMS9EVEQvc3ZnMTEtYmFzaWMuZHRkJz4KPCEtLSBHYXJkZW4gR25vbWUgU29mdHdhcmUgLSBTa2luIEJ1dHRvbnMgLS0+CjxzdmcgaGVpZ2h0PSIzMnB4IiB5PSIwcHgiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDMyIDMyIiB3aWR0aD0iMzJweCIgYmFzZVByb2ZpbGU9ImJhc2ljIiBpZD0iTGF5ZXJfMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIi'+
			'B4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgeD0iMHB4Ij4KIDxnIG9wYWNpdHk9IjAuNCIgc3Ryb2tlLXdpZHRoPSIxLjUiIHN0cm9rZT0iIzNDM0MzQyI+CiAgPHBhdGggZD0iTTMuNSwxNkMzLjUwMSw5LjA5Niw5LjA5NiwzLjUwMSwxNiwzLjVsMCwwQzIyLjkwMywzLjUwMSwyOC40OTksOS4wOTYsMjguNSwxNmwwLDAgICAgYy0wLjAwMSw2LjkwNC01LjU5NywxMi40OTktMTIuNSwxMi41bDAsMEM5LjA5NiwyOC40OTksMy41LDIyLjkwNCwzLjUsMTZMMy41LDE2eiBNNS44OTIsMTZjMCwyLjc5NSwxLjEyOSw1LjMxNCwyLjk2'+
			'MSw3LjE0NmwwLDAgICAgYzEuODMzLDEuODMxLDQuMzUzLDIuOTYsNy4xNDcsMi45NjFsMCwwYzIuNzk0LTAuMDAxLDUuMzE0LTEuMTMsNy4xNDctMi45NjFsMCwwYzEuODMtMS44MzIsMi45NTktNC4zNTIsMi45Ni03LjE0NmwwLDAgICAgYy0wLjAwMS0yLjc5NS0xLjEzLTUuMzE0LTIuOTYtNy4xNDdsMCwwQzIxLjMxNCw3LjAyMiwxOC43OTQsNS44OTQsMTYsNS44OTNsMCwwYy0yLjc5NCwwLTUuMzE0LDEuMTI5LTcuMTQ3LDIuOTZsMCwwICAgIEM3LjAyMSwxMC42ODYsNS44OTMsMTMuMjA1LDUuODkyLDE2TDUuODkyLDE2TDUuODkyLDE2eiIvPgogIDxwYXRoIGQ9Ik0xNy4zOTEsMjIuNjg2bC'+
			'02LjQ2OC01LjgyN2MtMC4yNS0wLjIyNi0wLjM5Ni0wLjU1Mi0wLjM5Ni0wLjg4OWwwLDBjMC0wLjMzNywwLjE0Ni0wLjY2MywwLjM5Ni0wLjg4OSAgICBsMCwwbDYuNDY4LTUuODI2YzAuNDkxLTAuNDQyLDEuMjQ3LTAuNDAzLDEuNjg5LDAuMDg4bDAsMGMwLjQ0MiwwLjQ5LDAuNDAyLDEuMjQ3LTAuMDg4LDEuNjg5bDAsMGwtNS40ODEsNC45MzhsNS40ODEsNC45MzhsMCwwICAgIGMwLjQ5LDAuNDQyLDAuNTMsMS4xOTgsMC4wODgsMS42ODlsMCwwYy0wLjIzNiwwLjI2My0wLjU2MiwwLjM5Ni0wLjg4OSwwLjM5NmwwLDBDMTcuOTA2LDIyLjk5MywxNy42MiwyMi44OTEsMTcuMzkxLDIyLjY4NiAg'+
			'ICBMMTcuMzkxLDIyLjY4NnoiLz4KIDwvZz4KIDxnIHN0cm9rZS13aWR0aD0iMC4yIiBzdHJva2U9IiMwMDAwMDAiIGZpbGw9IiNGRkZGRkYiPgogIDxwYXRoIGQ9Ik0zLjUsMTZDMy41MDEsOS4wOTYsOS4wOTYsMy41MDEsMTYsMy41bDAsMEMyMi45MDMsMy41MDEsMjguNDk5LDkuMDk2LDI4LjUsMTZsMCwwICAgIGMtMC4wMDEsNi45MDQtNS41OTcsMTIuNDk5LTEyLjUsMTIuNWwwLDBDOS4wOTYsMjguNDk5LDMuNSwyMi45MDQsMy41LDE2TDMuNSwxNnogTTUuODkyLDE2YzAsMi43OTUsMS4xMjksNS4zMTQsMi45NjEsNy4xNDZsMCwwICAgIGMxLjgzMywxLjgzMSw0LjM1MywyLjk2LDcuMTQ3LD'+
			'IuOTYxbDAsMGMyLjc5NC0wLjAwMSw1LjMxNC0xLjEzLDcuMTQ3LTIuOTYxbDAsMGMxLjgzLTEuODMyLDIuOTU5LTQuMzUyLDIuOTYtNy4xNDZsMCwwICAgIGMtMC4wMDEtMi43OTUtMS4xMy01LjMxNC0yLjk2LTcuMTQ3bDAsMEMyMS4zMTQsNy4wMjIsMTguNzk0LDUuODk0LDE2LDUuODkzbDAsMGMtMi43OTQsMC01LjMxNCwxLjEyOS03LjE0NywyLjk2bDAsMCAgICBDNy4wMjEsMTAuNjg2LDUuODkzLDEzLjIwNSw1Ljg5MiwxNkw1Ljg5MiwxNkw1Ljg5MiwxNnoiLz4KICA8cGF0aCBkPSJNMTcuMzkxLDIyLjY4NmwtNi40NjgtNS44MjdjLTAuMjUtMC4yMjYtMC4zOTYtMC41NTItMC4zOTYtMC44'+
			'ODlsMCwwYzAtMC4zMzcsMC4xNDYtMC42NjMsMC4zOTYtMC44ODkgICAgbDAsMGw2LjQ2OC01LjgyNmMwLjQ5MS0wLjQ0MiwxLjI0Ny0wLjQwMywxLjY4OSwwLjA4OGwwLDBjMC40NDIsMC40OSwwLjQwMiwxLjI0Ny0wLjA4OCwxLjY4OWwwLDBsLTUuNDgxLDQuOTM4bDUuNDgxLDQuOTM4bDAsMCAgICBjMC40OSwwLjQ0MiwwLjUzLDEuMTk4LDAuMDg4LDEuNjg5bDAsMGMtMC4yMzYsMC4yNjMtMC41NjIsMC4zOTYtMC44ODksMC4zOTZsMCwwQzE3LjkwNiwyMi45OTMsMTcuNjIsMjIuODkxLDE3LjM5MSwyMi42ODYgICAgTDE3LjM5MSwyMi42ODZ6Ii8+CiA8L2c+Cjwvc3ZnPgo=';
		me._button_image_left__img.setAttribute('src',hs);
		hs ='';
		hs += 'position: absolute;top: 0px;left: 0px;width: 100%;height: 100%;-webkit-user-drag:none;pointer-events:none;;';
		els.setAttribute('style', hs);
		els['ondragstart']=function() { return false; };
		el.appendChild(els);
		el.ggSubElement = els;
		el.ggId="button_image_left";
		el.ggDx=0;
		el.ggDy=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_svg ";
		el.ggType='svg';
		hs ='';
		hs+='cursor : pointer;';
		hs+='height : 40px;';
		hs+='left : calc(50% - ((40px + 0px) / 2) + 0px);';
		hs+='position : absolute;';
		hs+='top : calc(50% - ((40px + 0px) / 2) + 0px);';
		hs+='visibility : inherit;';
		hs+='width : 40px;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.setAttribute('aria-keyshortcuts', 'Left');
		el.style.transformOrigin='50% 50%';
		me._button_image_left.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._button_image_left.logicBlock_scaling = function() {
			var newLogicStateScaling;
			if (
				((me.elementMouseOver['button_image_left'] == true))
			)
			{
				newLogicStateScaling = 0;
			}
			else {
				newLogicStateScaling = -1;
			}
			if (me._button_image_left.ggCurrentLogicStateScaling != newLogicStateScaling) {
				me._button_image_left.ggCurrentLogicStateScaling = newLogicStateScaling;
				me._button_image_left.style.transition='transform 0s';
				if (me._button_image_left.ggCurrentLogicStateScaling == 0) {
					me._button_image_left.ggParameter.sx = 1.1;
					me._button_image_left.ggParameter.sy = 1.1;
					me._button_image_left.style.transform=parameterToTransform(me._button_image_left.ggParameter);
					skin.updateSize(me._button_image_left);
				}
				else {
					me._button_image_left.ggParameter.sx = 1;
					me._button_image_left.ggParameter.sy = 1;
					me._button_image_left.style.transform=parameterToTransform(me._button_image_left.ggParameter);
					skin.updateSize(me._button_image_left);
				}
			}
		}
		me._button_image_left.logicBlock_scaling();
		me._button_image_left.onmouseenter=function (e) {
			me.elementMouseOver['button_image_left']=true;
			me._button_image_left.logicBlock_scaling();
		}
		me._button_image_left.onmouseleave=function (e) {
			me.elementMouseOver['button_image_left']=false;
			me._button_image_left.logicBlock_scaling();
		}
		me._button_image_left.ggUpdatePosition=function (useTransition) {
		}
		me.__4.appendChild(me._button_image_left);
		me._container_2.appendChild(me.__4);
		el=me._resim=document.createElement('div');
		el.ggId="resim";
		el.ggDx=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_rectangle ";
		el.ggType='rectangle';
		hs ='';
		hs+='background : #000000;';
		hs+='border : 2px solid #ffffff;';
		hs+='bottom : 2px;';
		hs+='cursor : pointer;';
		hs+='height : 36px;';
		hs+='left : calc(50% - ((56px + 4px) / 2) + 0px);';
		hs+='position : absolute;';
		hs+='visibility : inherit;';
		hs+='width : 56px;';
		hs+='pointer-events:auto;';
		hs+='border-radius: 7px 7px 7px 7px;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me._resim.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._resim.logicBlock_backgroundcolor = function() {
			var newLogicStateBackgroundColor;
			if (
				((me.elementMouseOver['resim'] == true))
			)
			{
				newLogicStateBackgroundColor = 0;
			}
			else {
				newLogicStateBackgroundColor = -1;
			}
			if (me._resim.ggCurrentLogicStateBackgroundColor != newLogicStateBackgroundColor) {
				me._resim.ggCurrentLogicStateBackgroundColor = newLogicStateBackgroundColor;
				me._resim.style.transition='background-color 0s';
				if (me._resim.ggCurrentLogicStateBackgroundColor == 0) {
					me._resim.style.backgroundColor="rgba(70,65,95,1)";
				}
				else {
					me._resim.style.backgroundColor="rgba(0,0,0,1)";
				}
			}
		}
		me._resim.logicBlock_backgroundcolor();
		me._resim.onclick=function (e) {
			player.setVariableValue('Sosyalmedya', false);
			player.setVariableValue('infoklasor', false);
			player.setVariableValue('altmenu', !player.getVariableValue('altmenu'));
			player.setVariableValue('solmenuklasor', false);
		}
		me._resim.onmouseenter=function (e) {
			me.elementMouseOver['resim']=true;
			me._resim.logicBlock_backgroundcolor();
		}
		me._resim.onmouseleave=function (e) {
			me.elementMouseOver['resim']=false;
			me._resim.logicBlock_backgroundcolor();
		}
		me._resim.ggUpdatePosition=function (useTransition) {
		}
		el=me._albm=document.createElement('div');
		els=me._albm__img=document.createElement('img');
		els.className='ggskin ggskin_albm';
		hs='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAX20lEQVR4nO3d3ZLbuBEGUE7K7//KkwtH2VlbmqEkAv13TtXeJLYFElD3R5CSPj4/Pw8AYJb/RA8AANhPAACAgQQAABhIAACAgQQAABhIAACAgQQAABhIAACAgQQAABhIAACAgQQAABhIAACAgQQAABhIAACAgQQAABhIAACAgQQAABhIAACAgQQAABhIAACAgQQAABhIAACAgQQAABhIAACAgQQAABhIAACAgQQAABhIAACAgQQAABhIAACAgQQAABhIAACAgQQAABhIAACAgQQAABhIAACAgQQAABhIAACAgQQAABhIAACAgQQAABhIAACAgQQAABhIAACAgQQAABhIAACAgQQAABjoV/QAAnxGDwAgiY/oARCnewDQ7AEeu1cjhYIhugUADR/gPb'+
			'c6Kgg01yEAaPoA1/taW4WBhqoGAE0fYB+7Ag1VCwAaP0AcQaCRKgFA4wfIQxBoIPv3AHwemj9AVupzYVl3ACwqgBrsBhSVbQfAFT9ATWp3MVkCgMYPUJ86XkiGAGDBAPShphcR+QyARQLQk+cCCojaAdD8AfpT6xOLCAAWBMAcan5SO28BWAQAkMSuHQDNH2AuPSChHQHAxAOgFySzOgCYcABu9IREVgYAEw3An/SGJFY9BNhpgn2OFaioUx1mgRUBoMqi09iBzr6rcdF1+vNQg8NdHQCiF9V3LDaA3271MLJmCwHBrgwAGZu/xQXw2NcambGGs9BVDwFmWzgfh+YP8IyImpmtd4xyxQ5AlgnU8AHek+HWAJu8uwOQYZG42ge41s6amqGPjPROAIieNI0fYB31tbmonwN+l4UJsN6uWht9QTnSqwEgarJc9QPspeY2'+
			'9UoAiGz+AOyn/jb0bACIaP6u+gHira7DbgNslv0ZAI0fIA81uZFnAsDudGahAcAiZwOA5g/Acaytz24DbJTxFoDmDwCLnQkAOxOZ5g+Qn1rdQKYdAAsKADb5KQDsuvrX/AFqWVW3PQewSYYdAM0fADb7LgDsSGGaPwAEiNwB0PwBalPHC/v14H93D+Y5zhc/iSqUZ9ZmZBH33uGee+tC2LjYowCwWvWJVLR41uexf92fXae3P5d1fHAcf6+X6n0k3Mfn51/vwdVvyqqTplhxhR3r/521mn18cE/VvhIqw6cAMvv88h9cIftayj4+uEedfsGfAcDV/28WEyutXFtX/NvZxwePqN1P2LkDUKH5WzzssmKdXflvZh8ffEctPyHqIcBsLBSAfqIecC3h6w7AyiaY+eRr/gC92RG4Y/JDgBYEwCxq/hc7AkDGq3+LgG6yr+'+
			'ns42MOa/F/bs8ATDkhU44TgMc8G3DMugWg+dNZ9kKWfXzMNLovrA4AWd70oycZgIfG9ocJOwBjJxeAU0b2if8c6w48w9X/yEkF4Gnj+kXnHYBxk0kpKwLylf9m9vHBCqP6RtcAMGoSKWdlI7zi384+PlhpTP9YFQAi3+RjJg+AJUb0Eb8FAPvsCsa313m2iGUfH3ChbrcAFBSyitgVe+Y1s48PdmvfTzrtALSfLErJ0tz+HEe2b0B7ND7I4PPI81653IoAEHGyMhWNtouFFrKvz+zjY69Mtb2dTjsAkRQtgOt9ra1RYaDtLkCHABC1KFouCICkIh8ebRkCqgeAiIXQbhEAFOJTJBfp9imA1TR/gBx21+N2gaPyDsDOydD4AfKxG/AGOwA/0/wBcttVp1sFjaoBYNckaP4ANajXT6oaAHawmABq2VG32+wCCAD3af4A'+
			'NanfJ1UMAKvTl8UDQHtXBwDNE4Boq3tRi9sA1XYAXP0DcIZ6/oNqAWAliwWAMQQAALpyYfcNAeA3iwSAZ5R/DqBSACh/sgHYzgXeA5UCwCoWBwDjCAAAdOdC747pAcCiAGCkyj8HzHU8XwHwvEe1s8TFZZUAoEG9x/kD2OenmpsiIFQJADxHwwfI688aHRIIJgeAFAnsQpo+QE1f6/e23jQ5AHSh8QP0cavpy4OAAFCXxg/Q1/IgIADUo/EDzLEsCEz/HoBqNH+AmS6v/3YAatD4Abh0N8AOQH6aPwBfXdIXBIDcNH8A7nm7PwgAeWn+AHznrT4hAOSk+QNwxufxYs8QAPLR/AF41tO9QwDIRfMHYAsBIA/NH4B3PNVHBIAcNH8ArnC6nwgA8TR/AK50qq8IALE0fwBW+LG/CAAAMJAAEMfVPwArfdtn/BhQjGzNf9'+
			'nvTQMMlKnGfx4ParwAMI9mD7DWvTqbKRQcx+EWQISoRfBxaP4AUSJr8N2+YwegP00fII9bTQ7fEbADsNfOCXfFD5DX7hr9V/8RAHrS+AFqCKvXAkA/mj9ALbvq9r92AQSAfXZs/2v+ADVtr98CQB+aP0BtW+u4ALDH6qt/zR+gh9X1/P/9SACoT/MH6GVLXRcAAGAgAaA2V/8APS2v7wLAeuHf9gQAX3wehwBQmat/gN6W1nkBAAAGEgBqcvUPMMOyei8AAMBAAgAADCQAAMBAAgAADCQAAMBAAgAADCQAAEBuSz4KKAAAwEACAAAMJAAAwEACAAAMJAAAwEACAAAMJAAAwEACAAAMJAAAwEACAAAMJAAAwEACAAAMJAAAwEACAAAMJAAAwEACAAAM9Ct6AABs9/nEn/1YNgpCCQAAvT3T7M/+faGgAQEAoJd3G/4r'+
			'ryEQFCQAAPSwo/GfeW1hoAgBAKCuyKb/yG1MgkByAgBAPRkb/58EgeR8DBCglgrN/6tq4x3DDgBADZUbqd2AhOwAAORXufl/1eU4WrADAJBXx4ZpNyAJOwAAOXVs/l91P770BACAfKY0xynHmZIAAJDLtKY47XjTEAAA8pjaDKcedygBACCH6U1w+vFvJwAAxNP8fnMeNhIAAGJpev/mfGwiAADAQAIAQBxXu/c5LxsIAAAxNLnvOT+LCQAAMJDfAgDYL8vV7Xffx59hjJ+H3wxYRgAA2CuysT7TTP/8s1HjFgIWEQAA+ruigd7+jQw7A1zAMwAA++xunh/H9VfPK/7NnwgdCwgAAD2tbtK25YtzCwCgl52N2W2BwuwAAOyxo0lGXZXveF0h42ICAEAP0Vvy0a/PkwQAgPVWX71mab6rx2EX4EICAAAMJAAA1Jbl6v'+
			'8m23h4QAAAqCtrs806Lr4QAADWct/6Ws7nRXwPAOxxtmi5cuKs7Gvl49CsUxMAYI1XC9+9v5e90AMFCQBwnVVXO1//XWGA46izDuwCJCYAwHt2F7fb61VpAEBSHgKE10Ve2XwGvz7nmKM1nNcL2AGA52UqPnYEgJfYAYDzMl91Zx0X16sW9qqNdwwBAM6p0GAzBxQgGQEAflatqVYbLxBAAIDvVW2mVccNbCIAwGPVm2j18QMLCQDwt0730rscB3AxAQD+rWPD7HhMk5lPLiEAwD86F9bOx0Zu1l5SAgD8NqFITThG4CQBAGY1xknHmoEvwVnDeb2AAMB0ExvixGPuxhzyNgGAySYX0cnHzj7WWWICAFMpTM4BjCYAME2nz/hfwbmoK/vcZR/feAIAkyhI9zkva3lg7VrO50V+RQ8ANsnU5O4VsOjxfR4Ka0VZ5y16'+
			'PXOCAMAEGYrRT0X66/8fNd6szYTvZZu3DO83TnALgO6ii9HH8XxxfuXvXCX6fHWVqUHDcRwCAL1FN7N3i74QwFlZ5mz1OASpCwkAdBVdEK8qVEIAZ0XPWfTr8yQBgG4yfMzv6qYtBPSwYx4jnx9ZzdX/xQQAOsnQsFYVKSGAs3aG4AyBmxcJAHQRXYR2PLgnBNS3cw5Xz9vOdeHqfwEBgA6iG9TO4iQE8IwVV+iu+psQAKguuhBFNGQhoLaI+fs83mvc7/79d7j6X8QXAVFZdEOKLEwfR/zxU9Of6ybjN1OygQBAVdEFKsNVSUQIyPatc1VlCnBZxnGPtbaQWwBUFF2wMhWlqO1koDgBgEoyPHyUqfnfCAE1ZVxLmTg/iwkAVJGh4WQuSEJATZnXVCTnZQMBgAqiG03kj/M8QwioqcLa2sn52EQAILvoBlOtGAkBwC'+
			'kCAJlFN5Zqzf9GCKin6lq7mvOwkQBAVtENpXohEgLqqb7m3jX9+LcTAMgoupEoRK+Lnrvqpq69qccdSgAgEx/zu5avDK6p0xo8Y9rxpiEAkEWGptGxEAkBNXVci/dMOc6UBAAyiG4WVT7m9yohoKbO67LzsZUhABAtuklMKUJCQF3d1mi34ylLACBSdHOYVoiEgLq6rNUux9GCAECU6KYwtRAJAXVV3javPPa2BAAiRDeD6YVICKitUjOtNNZxBAB2i24CitFvQkB9mZtr5rHxPwIAu/iMfz5CQA+Zmm2msfCDX9EDYIQMBV9Ruu/jiJmfz8OcXO3r+dw5p+axKAGA1aKbv+L0MyGgn9VhwLw1IACwkuZfhxDQ13fn97s5Ny/NCQCsovnXIwTM47wP5iFAVtD86/JgIAwhAHC16EKu+b9PCIABBACu4mN+vQgB0JwA'+
			'wBUyFG3N/3pCADQmAPCu6GLti0fWEgKgKQGAd0QXaY1/DyEAGhIAeFV0cdb89xICoBkBgFdEF2XNP4YQAI0IADwruhhr/rGEAGhCAOAZ0UVY889BCIAGBADO8Bl//mQ+oDgBgJ9kaPyaTU4R8xK9HqENAYDvRBdbjT8/IQCKEgB4JLrIav51CAFQkADAPdHFVfOvRwiAYgQA/hRdVDX/uoQAKEQA4KvoYqr51ycEQBECAMfhY35cSwiAAn5FD4BwGQqn5t/Px7F/bX0e1lIHz64bc/4iAWC26ObvjdubEMAZ766Re3/fGjhBAJhL86crISC/1fXn9u9bB9/wDMBMmj+7+N0Avtr9vNHnkeMZp5QEgHmi3wia/zxCABmacPTrpyMAzBL9BtD85xIC5so0BxmCSBoCwBzRi17zRwiYJXOzzTqurQSA/jK8CTV/boSAGS'+
			'qc7wy1MZQA0Fv04vZTvtwjBPRVsalWG+9lBIC+ohe1xs93hIB+Kp/bisHlbQJAT9ELWfPnDCGgjy7ntMtxnCIA9BO9gDV/niEE1Nbxyrnb8TwkAPQSvXA1f14hBNTU+fx1Prb/EwD6iF6wmj/vEALq6HjVf0/74xQA6suwSDV/riAE5DfxXLU9ZgGgtgwLU/PnSkJAXpPPUctjFwDqil6QPuPPKkJALhl2GTNodx4EgJqiF6HGz2pCQA7Ox9/anBMBgGdp/uwiBMRyHh5rcW4EAJ6h+bObELBfu63uRcqfJwGAszR/oggB+0w85neVPWe/ogdACZo/0T6OmEL7ecxY/1mb2KNzn228JdeJHQB+Um5R05adgDUyHt9PnzL6OPFndit3S0AA4JFsby44DiHgatmO65W6k61WZTunDwkA3JPpzQR/EgLel/Fq9d15zVS3'+
			'sp3buwQA/pTpTQSPWKevy9acrryCz7QuMoasfxEA+CrTmwd+ErFeUxf0E7KNf8UcuiVwkgDATaY3DJwlBJyT7Wp0R5POVNMynfv/EwA4jlxvFHiWEPC9bGPdOV+Zalu2ECYAkOoNAq8SAv6WruEcMfPklsADAsBsmd4U8C4h4B/ZxpWhCUe//lcp5kcAmCnDmxFWEALyjSdTrck0lvAdGgFgnkxvAFhhaggIbyh3ZKw32S6AwuZMAJgl06KHlaaFgIyNP3u9yTS+kPkTAObItNhhhykhIGPzryLTWLfv4FwdALItRH7LtMihu111MNuWf4Wr/nuyjXvbnNoB6C/Twobduv5uQKbGfxw96kymY9gyvwJAb5kWNETpFAKyXfUfR686k+lYls+1ANBTti0tiNYhBGRs/B3rTLbjWjbvAkA/mRYuZFI5BGRs/t1lOsYl8y'+
			'8A9JJpwUJG1UKALf9YrY9VAOij9UKFC1UJARkb/8Q60/a4VwSAbIt2gpaLExbKHgKy1VE1puE5sANQX7tFCZtkDAHZtvzbXv2+qNW5EABqa7UYIUCmEJCp8R+H+vJIm/OyKgBkW8gdtVmEECw6BGS76j8O9eUnLXZG7ADUVH7hQTLRISCLFo1to9LnamUAyLawAb5TuphfYPrxv6rsebMDAPCPssX8TVOP+yold07+c6wdtF0AoJpyhfwNJRtXYqXOpR0AgL+VKuQvmnCMEcqc1x0BwC4AUFGZQv4kV/3rlTjHtwCweqBCAFBR+iL+pG7Hk13q873zFoAQAFSUuog/octxVJP2vO9+BkAIACpKW8RPKLEd3VzKOfgaAHYNTggAKkpXwE+oOObOUs1H1KcAhACgolQF/AeVxjpJmnn5MwDsHFjG778G+EmaAv5Ayu1m'+
			'/iXFHGX4HgAhAKgmvHg/kHVc3Bc6X/cCQMSA7AYA1WRqtimuKHlJ2Lw92gGI/GUsQQCoIkPTzTAG3hMS4H7tfsGThACgio8jrmZp/r1sXUvfPQNgYQGco15ylW1r6aeHAC1qgHOinp+iny23BDJ8CgCgCyGAKy1dT2cCgF0AgPOEAK60bD2d3QEQAgDOEwK40pL19MwtACEA4DwhgNSefQZACADITQjglFceAhQCAM6J/FI1+NarnwIQAgDOEQJI6Z2PAQoBAOcIAaTz7vcACAEA5wgBpHLFFwEJAQDnCAGkcdU3AfopSoBzhABSuPqrgIUAgJ8JAYRb8VsAdgMAfiYEEGrljwEJAgDfEwIIs+PXAAUBgMeEAELs/DlgQQDgPiGA7XYGgJuPQxgA+JMQwFYRAeArYQDgH0IA20QHgK8+7vy3kgUPZCQEsEWmAHCP3Q'+
			'FgIiGA5bIHgBshAJhGCGCpKgEAYCIXPywzPQBIukB2ESFAbRxgegAAqEAI4HICgEUO1OB2AJeqFAAsfmA6dZDLVAoAK9kFAKoQAriEAABQjxDA2wSAf9gFACoRAnhLtQDg64EB/iEE8LJqAQCAfxMCeIkA8De7AEA1QgBPqxgAdix0IQCo5uraKFQ0VzEA7CIEANVo2pxWNQDsWuSfhyAA1HJFfRQkBqgaAHYTAoBK3mngmv8QlQPA7kVqNwCo5JUaqfkP8it6AAXdQoA3CpDdrU79dPGing1UPQB8HHFX5YIAUIU6xV8q3wK4iV7Yn4fbAwAUU30HIBshAIASOuwAHEf8LgAAlNIlAByHEAAAp3UKAMchBADAKd0CAABwQscAYBcAAH7QMQAchxAAAN/qGgCOQwgAgIc6B4DjEAIA4K7uAeA4hAAA+MuEAHAcv0OA'+
			'IAAA/zMlANwIAQBwzAsAxyEEAMDIAHAcbgkAMNzUAHAjBAAw0vQAcBx2AwAYSAD4hyAAwBgCwN8EAQDa+xU9gMS+hoDPsFEAwAICwDnCAACtCADPu3d7QCgAYJUlPUYAuMZ3zwwIBwCk4yFAABhIAACAgQQAABhIAACAgQSAmjxYCDDDsnovAADAQAIAAAwkAKy36ncF3AYA6G1Vnf84DgEAAEYSAGqzCwDQ0/L6LgDUJwQA9LKlrgsAe6x6DgAAnvH/fiQA9GAXAKCHbfVcAOhDCACobWsdFwD22XEbQAgAqGlH/f5XHxIA+hECAGoJqdsCwF67Hgb8PAQBgOx21uq/+s+vTS9MjNvC8ikEgDxSXKDZAdgvohnbEQCIF1WL7/YdOwCzfF14dgUA1kt78SUAxPg44hdF9OsDsN7Diz23AABgIAEgji14AFb6ts8IAL'+
			'GEAABW+LG/CADxhAAAthMAAKCXUxeWAkAOdgEAuMLpfiIA5CEEAPCOp/qIAJCLEADAK57uHwJAPkIAAM94qW8IADkJAQCc8XK/EADyEgIA+M5bfcJvAeR2m1zf2w/AzSUXiHYAarAbAMBxXNgP7ADUYTcAYK7LLwTtANRjNwBgliV13w5ATXYDAPpbesEnANQmCAD0s2WnVwDo4etiEQYA6tl+e1cA6EcYAKgh9JkuAaC3e4tLKADYL90D3ALAPOkWIQD7+RggAAwkAADAQAIAAAwkAADAQAIAAAwkAADAQAIAAAwkAADAQAIAAAwkAADAQAIAAAwkAADAQAIAAAwkAADAQAIAAAwkAADAQAIAAAwkAADAQAIAAAwkAADAQAIAAAwkAADAQAIAAAwkAADAQAIAAAwkAADAQAIAAAwkAADAQAIAAAwkAADAQAIAAAwk'+
			'AADAQAIAAAwkAADAQAIAAAwkAADAQAIAAAwkAADAQAIAAAwkAADAQAIAAAwkAADAQAIAAAwkAADAQAIAAAwkAADAQP8FRSwS79vy9xkAAAAASUVORK5CYII=';
		els.setAttribute('src',hs);
		els.ggNormalSrc=hs;
		hs ='';
		hs += 'position: absolute;top: 0px;left: 0px;width: 100%;height: 100%;-webkit-user-drag:none;pointer-events:none;;';
		els.setAttribute('style', hs);
		els.className='ggskin ggskin_image';
		els['ondragstart']=function() { return false; };
		player.checkLoaded.push(els);
		el.appendChild(els);
		el.ggSubElement = els;
		el.ggId="alb\xfcm";
		el.ggDx=0;
		el.ggDy=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_image ";
		el.ggType='image';
		hs ='';
		hs+='cursor : pointer;';
		hs+='height : 37px;';
		hs+='left : calc(50% - ((37px + 0px) / 2) + 0px);';
		hs+='position : absolute;';
		hs+='top : calc(50% - ((37px + 0px) / 2) + 0px);';
		hs+='visibility : inherit;';
		hs+='width : 37px;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me._albm.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._albm.logicBlock_scaling = function() {
			var newLogicStateScaling;
			if (
				((me.elementMouseOver['albm'] == true))
			)
			{
				newLogicStateScaling = 0;
			}
			else {
				newLogicStateScaling = -1;
			}
			if (me._albm.ggCurrentLogicStateScaling != newLogicStateScaling) {
				me._albm.ggCurrentLogicStateScaling = newLogicStateScaling;
				me._albm.style.transition='transform 0s';
				if (me._albm.ggCurrentLogicStateScaling == 0) {
					me._albm.ggParameter.sx = 1.1;
					me._albm.ggParameter.sy = 1.1;
					me._albm.style.transform=parameterToTransform(me._albm.ggParameter);
					skin.updateSize(me._albm);
				}
				else {
					me._albm.ggParameter.sx = 1;
					me._albm.ggParameter.sy = 1;
					me._albm.style.transform=parameterToTransform(me._albm.ggParameter);
					skin.updateSize(me._albm);
				}
			}
		}
		me._albm.logicBlock_scaling();
		me._albm.onmouseenter=function (e) {
			me.elementMouseOver['albm']=true;
			me._albm.logicBlock_scaling();
		}
		me._albm.onmouseleave=function (e) {
			me.elementMouseOver['albm']=false;
			me._albm.logicBlock_scaling();
		}
		me._albm.ggUpdatePosition=function (useTransition) {
		}
		me._resim.appendChild(me._albm);
		me._container_2.appendChild(me._resim);
		el=me.__2=document.createElement('div');
		el.ggId="2";
		el.ggDx=-60;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_rectangle ";
		el.ggType='rectangle';
		hs ='';
		hs+='background : #000000;';
		hs+='border : 2px solid #ffffff;';
		hs+='bottom : 2px;';
		hs+='cursor : pointer;';
		hs+='height : 36px;';
		hs+='left : calc(50% - ((36px + 4px) / 2) - 60px);';
		hs+='position : absolute;';
		hs+='visibility : inherit;';
		hs+='width : 36px;';
		hs+='pointer-events:auto;';
		hs+='border-radius: 7px 7px 7px 7px;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me.__2.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me.__2.logicBlock_backgroundcolor = function() {
			var newLogicStateBackgroundColor;
			if (
				((me.elementMouseOver['_2'] == true))
			)
			{
				newLogicStateBackgroundColor = 0;
			}
			else {
				newLogicStateBackgroundColor = -1;
			}
			if (me.__2.ggCurrentLogicStateBackgroundColor != newLogicStateBackgroundColor) {
				me.__2.ggCurrentLogicStateBackgroundColor = newLogicStateBackgroundColor;
				me.__2.style.transition='background-color 0s';
				if (me.__2.ggCurrentLogicStateBackgroundColor == 0) {
					me.__2.style.backgroundColor="rgba(70,65,95,1)";
				}
				else {
					me.__2.style.backgroundColor="rgba(0,0,0,1)";
				}
			}
		}
		me.__2.logicBlock_backgroundcolor();
		me.__2.onmouseenter=function (e) {
			me.elementMouseOver['_2']=true;
			me.__2.logicBlock_backgroundcolor();
		}
		me.__2.onmouseleave=function (e) {
			me.elementMouseOver['_2']=false;
			me.__2.logicBlock_backgroundcolor();
		}
		me.__2.ggUpdatePosition=function (useTransition) {
		}
		el=me._zoomout=document.createElement('div');
		els=me._zoomout__img=document.createElement('img');
		els.className='ggskin ggskin_svg';
		hs='data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0nMS4wJyBlbmNvZGluZz0ndXRmLTgnPz4KPCFET0NUWVBFIHN2ZyBQVUJMSUMgJy0vL1czQy8vRFREIFNWRyAxLjEgQmFzaWMvL0VOJyAnaHR0cDovL3d3dy53My5vcmcvR3JhcGhpY3MvU1ZHLzEuMS9EVEQvc3ZnMTEtYmFzaWMuZHRkJz4KPCEtLSBHYXJkZW4gR25vbWUgU29mdHdhcmUgLSBTa2luIEJ1dHRvbnMgLS0+CjxzdmcgaGVpZ2h0PSIzMnB4IiB5PSIwcHgiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDMyIDMyIiB3aWR0aD0iMzJweCIgYmFzZVByb2ZpbGU9ImJhc2ljIiBpZD0iTGF5ZXJfMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIi'+
			'B4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgeD0iMHB4Ij4KIDxnIG9wYWNpdHk9IjAuNCIgc3Ryb2tlLXdpZHRoPSIxLjUiIHN0cm9rZT0iIzNDM0MzQyI+CiAgPHBhdGggZD0iTTIxLjc1OCwxNC44MDRIMTAuMjQxYy0wLjY2LDAtMS4xOTYsMC41MzUtMS4xOTYsMS4xOTZjMCwwLjY2MSwwLjUzNiwxLjE5NiwxLjE5NiwxLjE5NmgxMS41MTcgICAgYzAuNjYxLDAsMS4xOTctMC41MzYsMS4xOTctMS4xOTZDMjIuOTU1LDE1LjMzOSwyMi40MTksMTQuODA0LDIxLjc1OCwxNC44MDR6IE0xNiwzLjVDOS4wOTYsMy41LDMuNSw5LjA5'+
			'NiwzLjUsMTYgICAgYzAsNi45MDMsNS41OTYsMTIuNDk5LDEyLjUsMTIuNWM2LjkwMy0wLjAwMSwxMi40OTktNS41OTcsMTIuNS0xMi41QzI4LjQ5OSw5LjA5NiwyMi45MDMsMy41LDE2LDMuNXogTTIzLjE0NiwyMy4xNDYgICAgYy0xLjgzMiwxLjgzMS00LjM1MiwyLjk2LTcuMTQ2LDIuOTZzLTUuMzE0LTEuMTI5LTcuMTQ2LTIuOTZDNy4wMjIsMjEuMzE0LDUuODk0LDE4Ljc5NSw1Ljg5MywxNiAgICBjMC4wMDEtMi43OTUsMS4xMjktNS4zMTQsMi45NjEtNy4xNDdjMS44MzMtMS44MzEsNC4zNTItMi45Niw3LjE0Ni0yLjk2MWMyLjc5NSwwLjAwMSw1LjMxMywxLjEzLDcuMTQ2LDIuOTYxICAgIG'+
			'MxLjgzMiwxLjgzMywyLjk2LDQuMzUyLDIuOTYxLDcuMTQ3QzI2LjEwNiwxOC43OTUsMjQuOTc5LDIxLjMxNCwyMy4xNDYsMjMuMTQ2eiIvPgogPC9nPgogPGcgc3Ryb2tlLXdpZHRoPSIwLjIiIHN0cm9rZT0iIzAwMDAwMCIgZmlsbD0iI0ZGRkZGRiI+CiAgPHBhdGggZD0iTTIxLjc1OCwxNC44MDRIMTAuMjQxYy0wLjY2LDAtMS4xOTYsMC41MzUtMS4xOTYsMS4xOTZjMCwwLjY2MSwwLjUzNiwxLjE5NiwxLjE5NiwxLjE5NmgxMS41MTcgICAgYzAuNjYxLDAsMS4xOTctMC41MzYsMS4xOTctMS4xOTZDMjIuOTU1LDE1LjMzOSwyMi40MTksMTQuODA0LDIxLjc1OCwxNC44MDR6IE0xNiwzLjVDOS4w'+
			'OTYsMy41LDMuNSw5LjA5NiwzLjUsMTYgICAgYzAsNi45MDMsNS41OTYsMTIuNDk5LDEyLjUsMTIuNWM2LjkwMy0wLjAwMSwxMi40OTktNS41OTcsMTIuNS0xMi41QzI4LjQ5OSw5LjA5NiwyMi45MDMsMy41LDE2LDMuNXogTTIzLjE0NiwyMy4xNDYgICAgYy0xLjgzMiwxLjgzMS00LjM1MiwyLjk2LTcuMTQ2LDIuOTZzLTUuMzE0LTEuMTI5LTcuMTQ2LTIuOTZDNy4wMjIsMjEuMzE0LDUuODk0LDE4Ljc5NSw1Ljg5MywxNiAgICBjMC4wMDEtMi43OTUsMS4xMjktNS4zMTQsMi45NjEtNy4xNDdjMS44MzMtMS44MzEsNC4zNTItMi45Niw3LjE0Ni0yLjk2MWMyLjc5NSwwLjAwMSw1LjMxMywxLjEzLD'+
			'cuMTQ2LDIuOTYxICAgIGMxLjgzMiwxLjgzMywyLjk2LDQuMzUyLDIuOTYxLDcuMTQ3QzI2LjEwNiwxOC43OTUsMjQuOTc5LDIxLjMxNCwyMy4xNDYsMjMuMTQ2eiIvPgogPC9nPgo8L3N2Zz4K';
		me._zoomout__img.setAttribute('src',hs);
		hs ='';
		hs += 'position: absolute;top: 0px;left: 0px;width: 100%;height: 100%;-webkit-user-drag:none;pointer-events:none;;';
		els.setAttribute('style', hs);
		els['ondragstart']=function() { return false; };
		el.appendChild(els);
		el.ggSubElement = els;
		el.ggId="zoomout";
		el.ggDx=0;
		el.ggDy=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_svg ";
		el.ggType='svg';
		hs ='';
		hs+='cursor : pointer;';
		hs+='height : 40px;';
		hs+='left : calc(50% - ((40px + 0px) / 2) + 0px);';
		hs+='position : absolute;';
		hs+='top : calc(50% - ((40px + 0px) / 2) + 0px);';
		hs+='visibility : inherit;';
		hs+='width : 40px;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.setAttribute('aria-keyshortcuts', '-');
		el.style.transformOrigin='50% 50%';
		me._zoomout.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._zoomout.logicBlock_scaling = function() {
			var newLogicStateScaling;
			if (
				((me.elementMouseOver['zoomout'] == true))
			)
			{
				newLogicStateScaling = 0;
			}
			else {
				newLogicStateScaling = -1;
			}
			if (me._zoomout.ggCurrentLogicStateScaling != newLogicStateScaling) {
				me._zoomout.ggCurrentLogicStateScaling = newLogicStateScaling;
				me._zoomout.style.transition='transform 0s';
				if (me._zoomout.ggCurrentLogicStateScaling == 0) {
					me._zoomout.ggParameter.sx = 1.1;
					me._zoomout.ggParameter.sy = 1.1;
					me._zoomout.style.transform=parameterToTransform(me._zoomout.ggParameter);
					skin.updateSize(me._zoomout);
				}
				else {
					me._zoomout.ggParameter.sx = 1;
					me._zoomout.ggParameter.sy = 1;
					me._zoomout.style.transform=parameterToTransform(me._zoomout.ggParameter);
					skin.updateSize(me._zoomout);
				}
			}
		}
		me._zoomout.logicBlock_scaling();
		me._zoomout.onmouseenter=function (e) {
			me.elementMouseOver['zoomout']=true;
			me._zoomout.logicBlock_scaling();
		}
		me._zoomout.onmousedown=function (e) {
			me.elementMouseDown['zoomout']=true;
		}
		me._zoomout.onmouseup=function (e) {
			me.elementMouseDown['zoomout']=false;
		}
		me._zoomout.onmouseleave=function (e) {
			me.elementMouseDown['zoomout']=false;
			me.elementMouseOver['zoomout']=false;
			me._zoomout.logicBlock_scaling();
		}
		me._zoomout.ggCurrentLogicStateScaling = -1;
		me._zoomout.ggUpdateConditionTimer=function () {
			if (me.elementMouseDown['zoomout']) {
				player.changeFovLog(1,true);
			}
		}
		me._zoomout.ggUpdatePosition=function (useTransition) {
		}
		me.__2.appendChild(me._zoomout);
		me._container_2.appendChild(me.__2);
		el=me.__1=document.createElement('div');
		el.ggId="1";
		el.ggDx=-110;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_rectangle ";
		el.ggType='rectangle';
		hs ='';
		hs+='background : #000000;';
		hs+='border : 2px solid #ffffff;';
		hs+='bottom : 2px;';
		hs+='cursor : pointer;';
		hs+='height : 36px;';
		hs+='left : calc(50% - ((36px + 4px) / 2) - 110px);';
		hs+='position : absolute;';
		hs+='visibility : inherit;';
		hs+='width : 36px;';
		hs+='pointer-events:auto;';
		hs+='border-radius: 7px 7px 7px 7px;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me.__1.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me.__1.logicBlock_backgroundcolor = function() {
			var newLogicStateBackgroundColor;
			if (
				((me.elementMouseOver['_1'] == true))
			)
			{
				newLogicStateBackgroundColor = 0;
			}
			else {
				newLogicStateBackgroundColor = -1;
			}
			if (me.__1.ggCurrentLogicStateBackgroundColor != newLogicStateBackgroundColor) {
				me.__1.ggCurrentLogicStateBackgroundColor = newLogicStateBackgroundColor;
				me.__1.style.transition='background-color 0s';
				if (me.__1.ggCurrentLogicStateBackgroundColor == 0) {
					me.__1.style.backgroundColor="rgba(70,65,95,1)";
				}
				else {
					me.__1.style.backgroundColor="rgba(0,0,0,1)";
				}
			}
		}
		me.__1.logicBlock_backgroundcolor();
		me.__1.onclick=function (e) {
			player.setVariableValue('Sosyalmedya', false);
			player.setVariableValue('infoklasor', false);
		}
		me.__1.onmouseenter=function (e) {
			me.elementMouseOver['_1']=true;
			me.__1.logicBlock_backgroundcolor();
		}
		me.__1.onmouseleave=function (e) {
			me.elementMouseOver['_1']=false;
			me.__1.logicBlock_backgroundcolor();
		}
		me.__1.ggUpdatePosition=function (useTransition) {
		}
		el=me._zoomin=document.createElement('div');
		els=me._zoomin__img=document.createElement('img');
		els.className='ggskin ggskin_svg';
		hs='data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0nMS4wJyBlbmNvZGluZz0ndXRmLTgnPz4KPCFET0NUWVBFIHN2ZyBQVUJMSUMgJy0vL1czQy8vRFREIFNWRyAxLjEgQmFzaWMvL0VOJyAnaHR0cDovL3d3dy53My5vcmcvR3JhcGhpY3MvU1ZHLzEuMS9EVEQvc3ZnMTEtYmFzaWMuZHRkJz4KPCEtLSBHYXJkZW4gR25vbWUgU29mdHdhcmUgLSBTa2luIEJ1dHRvbnMgLS0+CjxzdmcgaGVpZ2h0PSIzMnB4IiB5PSIwcHgiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDMyIDMyIiB3aWR0aD0iMzJweCIgYmFzZVByb2ZpbGU9ImJhc2ljIiBpZD0iTGF5ZXJfMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIi'+
			'B4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgeD0iMHB4Ij4KIDxnIG9wYWNpdHk9IjAuNCIgc3Ryb2tlLXdpZHRoPSIxLjUiIHN0cm9rZT0iIzNDM0MzQyI+CiAgPHBhdGggZD0iTTIyLjA2MSwxNC44MDNoLTQuODY0VjkuOTM4YzAtMC42NjEtMC41MzYtMS4xOTctMS4xOTctMS4xOTdjLTAuNjYsMC0xLjE5NiwwLjUzNi0xLjE5NiwxLjE5N3Y0Ljg2NSAgICBIOS45MzhjLTAuNjYxLDAtMS4xOTYsMC41MzYtMS4xOTYsMS4xOTdjMCwwLjY2LDAuNTM2LDEuMTk2LDEuMTk2LDEuMTk2aDQuODY2djQuODY1YzAsMC42NiwwLjUzNiwx'+
			'LjE5NiwxLjE5NiwxLjE5NiAgICBjMC42NjEsMCwxLjE5Ny0wLjUzNiwxLjE5Ny0xLjE5NnYtNC44NjVoNC44NjRjMC42NjEsMCwxLjE5Ni0wLjUzNiwxLjE5Ni0xLjE5NkMyMy4yNTcsMTUuMzM5LDIyLjcyMiwxNC44MDMsMjIuMDYxLDE0LjgwM3ogICAgIE0xNiwzLjVDOS4wOTYsMy41LDMuNSw5LjA5NiwzLjUsMTZjMCw2LjkwMyw1LjU5NiwxMi40OTksMTIuNSwxMi41YzYuOTAzLTAuMDAxLDEyLjQ5OS01LjU5NywxMi41LTEyLjUgICAgQzI4LjQ5OSw5LjA5NiwyMi45MDMsMy41LDE2LDMuNXogTTIzLjE0NiwyMy4xNDZjLTEuODMyLDEuODMxLTQuMzUyLDIuOTYtNy4xNDYsMi45NnMtNS4zMT'+
			'QtMS4xMjktNy4xNDYtMi45NiAgICBDNy4wMjIsMjEuMzE0LDUuODk0LDE4Ljc5NSw1Ljg5MywxNmMwLjAwMS0yLjc5NSwxLjEyOS01LjMxNCwyLjk2MS03LjE0N2MxLjgzMy0xLjgzMSw0LjM1Mi0yLjk2LDcuMTQ2LTIuOTYxICAgIGMyLjc5NSwwLjAwMSw1LjMxMywxLjEzLDcuMTQ2LDIuOTYxYzEuODMyLDEuODMzLDIuOTYsNC4zNTIsMi45NjEsNy4xNDdDMjYuMTA2LDE4Ljc5NSwyNC45NzksMjEuMzE0LDIzLjE0NiwyMy4xNDZ6Ii8+CiA8L2c+CiA8ZyBzdHJva2Utd2lkdGg9IjAuMiIgc3Ryb2tlPSIjMDAwMDAwIiBmaWxsPSIjRkZGRkZGIj4KICA8cGF0aCBkPSJNMjIuMDYxLDE0LjgwM2gt'+
			'NC44NjRWOS45MzhjMC0wLjY2MS0wLjUzNi0xLjE5Ny0xLjE5Ny0xLjE5N2MtMC42NiwwLTEuMTk2LDAuNTM2LTEuMTk2LDEuMTk3djQuODY1ICAgIEg5LjkzOGMtMC42NjEsMC0xLjE5NiwwLjUzNi0xLjE5NiwxLjE5N2MwLDAuNjYsMC41MzYsMS4xOTYsMS4xOTYsMS4xOTZoNC44NjZ2NC44NjVjMCwwLjY2LDAuNTM2LDEuMTk2LDEuMTk2LDEuMTk2ICAgIGMwLjY2MSwwLDEuMTk3LTAuNTM2LDEuMTk3LTEuMTk2di00Ljg2NWg0Ljg2NGMwLjY2MSwwLDEuMTk2LTAuNTM2LDEuMTk2LTEuMTk2QzIzLjI1NywxNS4zMzksMjIuNzIyLDE0LjgwMywyMi4wNjEsMTQuODAzeiAgICAgTTE2LDMuNUM5Lj'+
			'A5NiwzLjUsMy41LDkuMDk2LDMuNSwxNmMwLDYuOTAzLDUuNTk2LDEyLjQ5OSwxMi41LDEyLjVjNi45MDMtMC4wMDEsMTIuNDk5LTUuNTk3LDEyLjUtMTIuNSAgICBDMjguNDk5LDkuMDk2LDIyLjkwMywzLjUsMTYsMy41eiBNMjMuMTQ2LDIzLjE0NmMtMS44MzIsMS44MzEtNC4zNTIsMi45Ni03LjE0NiwyLjk2cy01LjMxNC0xLjEyOS03LjE0Ni0yLjk2ICAgIEM3LjAyMiwyMS4zMTQsNS44OTQsMTguNzk1LDUuODkzLDE2YzAuMDAxLTIuNzk1LDEuMTI5LTUuMzE0LDIuOTYxLTcuMTQ3YzEuODMzLTEuODMxLDQuMzUyLTIuOTYsNy4xNDYtMi45NjEgICAgYzIuNzk1LDAuMDAxLDUuMzEzLDEuMTMs'+
			'Ny4xNDYsMi45NjFjMS44MzIsMS44MzMsMi45Niw0LjM1MiwyLjk2MSw3LjE0N0MyNi4xMDYsMTguNzk1LDI0Ljk3OSwyMS4zMTQsMjMuMTQ2LDIzLjE0NnoiLz4KIDwvZz4KPC9zdmc+Cg==';
		me._zoomin__img.setAttribute('src',hs);
		hs ='';
		hs += 'position: absolute;top: 0px;left: 0px;width: 100%;height: 100%;-webkit-user-drag:none;pointer-events:none;;';
		els.setAttribute('style', hs);
		els['ondragstart']=function() { return false; };
		el.appendChild(els);
		el.ggSubElement = els;
		el.ggId="zoomin";
		el.ggDx=0;
		el.ggDy=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_svg ";
		el.ggType='svg';
		hs ='';
		hs+='cursor : pointer;';
		hs+='height : 40px;';
		hs+='left : calc(50% - ((40px + 0px) / 2) + 0px);';
		hs+='position : absolute;';
		hs+='top : calc(50% - ((40px + 0px) / 2) + 0px);';
		hs+='visibility : inherit;';
		hs+='width : 40px;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.setAttribute('aria-keyshortcuts', '+');
		el.style.transformOrigin='50% 50%';
		me._zoomin.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._zoomin.logicBlock_scaling = function() {
			var newLogicStateScaling;
			if (
				((me.elementMouseOver['zoomin'] == true))
			)
			{
				newLogicStateScaling = 0;
			}
			else {
				newLogicStateScaling = -1;
			}
			if (me._zoomin.ggCurrentLogicStateScaling != newLogicStateScaling) {
				me._zoomin.ggCurrentLogicStateScaling = newLogicStateScaling;
				me._zoomin.style.transition='transform 0s';
				if (me._zoomin.ggCurrentLogicStateScaling == 0) {
					me._zoomin.ggParameter.sx = 1.1;
					me._zoomin.ggParameter.sy = 1.1;
					me._zoomin.style.transform=parameterToTransform(me._zoomin.ggParameter);
					skin.updateSize(me._zoomin);
				}
				else {
					me._zoomin.ggParameter.sx = 1;
					me._zoomin.ggParameter.sy = 1;
					me._zoomin.style.transform=parameterToTransform(me._zoomin.ggParameter);
					skin.updateSize(me._zoomin);
				}
			}
		}
		me._zoomin.logicBlock_scaling();
		me._zoomin.onmouseenter=function (e) {
			me.elementMouseOver['zoomin']=true;
			me._zoomin.logicBlock_scaling();
		}
		me._zoomin.onmousedown=function (e) {
			me.elementMouseDown['zoomin']=true;
		}
		me._zoomin.onmouseup=function (e) {
			me.elementMouseDown['zoomin']=false;
		}
		me._zoomin.onmouseleave=function (e) {
			me.elementMouseDown['zoomin']=false;
			me.elementMouseOver['zoomin']=false;
			me._zoomin.logicBlock_scaling();
		}
		me._zoomin.ggCurrentLogicStateScaling = -1;
		me._zoomin.ggUpdateConditionTimer=function () {
			if (me.elementMouseDown['zoomin']) {
				player.changeFovLog(-1,true);
			}
		}
		me._zoomin.ggUpdatePosition=function (useTransition) {
		}
		me.__1.appendChild(me._zoomin);
		me._container_2.appendChild(me.__1);
		me._stbuttonlar_1.appendChild(me._container_2);
		me._kkresimler.appendChild(me._stbuttonlar_1);
		me._alt_men.appendChild(me._kkresimler);
		el=me._image_2=document.createElement('div');
		els=me._image_2__img=document.createElement('img');
		els.className='ggskin ggskin_image_2';
		hs='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAbUAAABkCAYAAAABv67jAAAQwUlEQVR4nO3dP2wbyRUG8I/yOTEuI1gUYBxwSHAGFUBlDNB9VFC9G6pN0lBlrqNKpSO7a8UmrsXmUotA7F4EfF0ExMwFBxxwuECU4YGgxPBtip3VkcshuTs7y5nd/X4A4T+ilmNJ3sc38+ZNLQgCmLqq1XYAPEv49Df7QXBj/GJERERr1NIEtata7SmAF+rxDMDjXEZl7nWO136lfn0D4BUDNBGRfxIFNRXMTgH8Id/hFMo3AL4C8DUDHBGRH1YGNTW9eArgz5saUAG9A3C6HwRfuR4IEVHVLQ1qKjv7GsDvNjieIvsGwIv9IPjW9UCIiKpKG9SuarVnCNeQfFsz8907AAf7QfDG9UCIiKpoIaipDO0NGNBMMbARETmypfm7r8GAlsVjAK9UtktERB'+
			's0F9SuarVTcA3NhscAXroeBBFR1dxPP6ppx3+5HEwJ/WU/CE5dD4KIqCpmM7VTV4MosS/VtggiItqALeB+Pxo3Vtv3GMCXrgdBRFQVUab2wukoyu2PrgdARFQVUVA7cDmIkvuClZBERJsRBTXedPN1YPFabwEEM4/umudfxp7fWvHcOoDrmee+1TynE7ve2ZrXb6gxxscRALhQH2uu+Pz46yV5XKwZExGVVBTUWMafL5tvGgaxP68KCE3Nx1cFtRbCwBYZphiXThdhYOxpxhG9Xg9hwGMgIqLMdJuvyb6nFq81iv25jflANEsXwNorrh1/fvy10ugiDFhJTTK8FhERAOAT1wOg1MbqMZv5tKDPqnQBrKE+d7zm+VOYB7U6FgPaSHO95sxrJs0KxwmeO014LSIqGQa1YhpiPqi1sXijb2D51GQLi0EtnvHFpznTiAfT'+
			'EYDDJc+tI1w3SxpAxwD6huMiopLbUp1EqFjiASDtNKPuY/EAqMvkkopPh66aWpyCQYqILNmC3fUe2owx5gNFHYuBavbPE8xnck2Emdyszszvp8hWJBIPYh2sr9IkIsqMhSLFFQ86s5lWfOpxCH2BScR21eMIi+taPYTl9pcIA9yqTHKVdSX+rKIkqjAGteKKB6nZTCseMIZYDFStJb/XXTutKYCjJR9rIgxw5/h5n9uqbQlERIkxqBVXPBuq4+fgMBukpginK+PVjLPZma2qx/j49rB+vayDn7M3IqJMWP1YbAPMB4M2wvWsVuw5kVHsY22EAa8Re46tkvgJgBP1aCEMui3oC1t6aizrAuq6kn6W8xNVGINascUrFFtYvKnPBokh5vePxdfS4s+3KdqnFmVuHTWW2ddvJ3h9lvQT0VIMasU2RBjEosDQxHyQiE8lTj'+
			'C/cbuFxfWsrEUiSQ0Qju985u/iFZlERKlkCmqPmk182mrhUbOJ7XbyYrb3wyHuxmPcjka4G2fZDjU/ls/Pz/GwYee+GI3xp+kUN4Ms+5BzN8R8kcjsF0A38NmN23UsVj3amr47QxhEV2VV8W8Wpw6JKBOjoPao2cSTXg+ftlb1xl1uu92+D4K3oxF+PDnJHNw+OzuzFtCA+TF+dnaGm8EA1/0+Pky8a1E4wnxQi38syd9F7LzDCINVNKYewuAa/8LVsVgckmTqs6n5PJ0oEySiCqn9IzwW5e9JP+HTVgu/ubC/Fei7w0PcjsyXcxpv31oNasv8eHKC637qJZ3X+0FwkMNwgDA4vMXi2tgUwO6Sz7mEvox+F+sDQQfzx80MABzHnnOG5YF2mTGA5wleL6k9sEkyUeWkKul/1GzmEtAA4DcXF3jU9H+70pNeL7evgaFl'+
			'Jfir1sZ0z4/K/m3QbfZe9/xlvSGJiBJLFdQ+OzN5w+zP9W35tNXybaxppxl1Ac9mgUjUwPg5wnJ+3bWn6mOHCDdqc6qQiDJLPP24bNrxdjTC++EwVTHFTqeDx52ONjMznYbUTT9e1WqprxPZbrfxsNHAbreLB3X9cWXfHx3h/TBRLMhz+pGIiJTEmdqvNEUh74dDfHd4mLo68GYwwL+fP9cWh+hex4X3wyGu+338c3cXPxzHl4xCT3ppzsAkIqK8JQ5qukpHg4KJObpgYVpRmaebwQDfHy22MnzYaHg5XiKiqkoc1OJThR+n08xl+HfjMT5O55dSfC0WWTbFmmZ/HhER5StxUIvvz0q4lpT6ugA2Uppv4p15UPvW9liIiGhR4qA2WxRx3e/jPycnVgbw07Q4RW+6zPJBvb60kGTGt3mNSUp5IaUMYg+v9hzoSCm7mn'+
			'EHrsdF/lrys16In3fanMQdRe7GY+26UtXcjkYL2dkvm81MG8dz0JJSdoUQXjb+lVJGZ6qZfO4F9F3+N2EkhFi6n87y2KJ9g9HRQWMAYyFEbu8CTcYvhDAvMU5B/cwsG1tLStkQQnCzPblvaLylyXJ8zt5006W/aDRw62Asa/SklCMhhK3WV1ZIKeuYb2JMerOLy/fvoqSU0fE8Q9++tzlb16Gmi8XONlRBzg8Jja+ffZxOF6b4fOLz2DTOVRDxyRnYjT+LqPflpZTyUkqZth1Z4UgpZ3uJLtNRz6OKcxrUHjWbC+tRnk3jJaLLNj3RgOE0Xx7UDZjlovY0AZxJKd+WPLglPRWdP1vkNqg97iz+PyxiUPNcx4cbXpZ1NFqrgTC4Xaivc2momYakwarr4cwEbZizoLbb7WInFtQ+TCa+n11WVD0PpmbOsHiSANnVAnDh'+
			'w5sYizpI/nNTR/rTIahkPgHwzOYFt9ttfH5uVgfA6srcRMUZuqNdciel7EF/1A3ZV0eYtTWEEHb23biVdOox0sHqg2mp5LYA7Ni62MNGwzig2TgolFZqquCyUVLKNtLfmCi7btEzNjX+tNl9o+j/bsrG6vRjlk4gWU7SpsS6UsqNfZHV+oZXZ/RUzFnBb/Cmb4b4JqrCrAa1rPvLPj8/97ZFVolsssz/HFxHc61XxOIRFYxNbwYNNUNAFWQ1qN2Nx/gxQ/usB/U6drt8k5WzjWx+llJ24a7zB/2sqNly1qBU5AyVMrBe/Xjd7+OqVlv5+O7wcGnw2+l0mK3lr6WCTi5Yvu+dZp7fb9vUFHnWN0StTU61kz+ctMm6HY3uH7++uFjYgL3dbmc+q43WyqWNlo9tsDbVn9DA0l6S6obcQFg12kb2adyulHKQZ+9Ii2wF4D'+
			'bClmJUIU43X9+Nx9rg5euZaiWUx/oa22BZIIQYCSEGQohjIcQuwr6GWQJSIfZwqf2UtjIsts6qIOe9H3XnsjGobYzVNlpsg5UfIcQAwB6ALN0JvA9qsF+5WJhpV7LDeVD7MJksNAku2pqaz6cKJGCljRbX0fInhJgKIY5hHtgaPldCJmxcnFaHrbOqxXlQA/RBIcHBm074Oq6MbLTRYhusDVGBzfToeZ+LJ/LK8ouQoZIliYPabreL3W53Y1mUr53vdf/+/2nOWCuYTMUdbIPlhOkam5dBTWVTeU0VstFxhaytfnxQr+OLy8v7m/mTXg+TvT3tYZk2+Tqlp+t68t9ytPdqSil7afsFFqENljrR2dSJj4dxCiGmUso+0k/5ehnUkK5xcVpRkQxLqitgbVD7ZbO5kJ3sdDqZNlnH6bIyHw/j1J3/5vuhpil1VZl/ojLo'+
			'ArXBynIj9/kd/hAG65iq2bFv0wt5TxEyqFXE2ulHXcZkcwryQb2+ECjyzgJN6c5/01VvFlyaMn+2wXJIBSaTLNKrSqyMLbGSYqPjilgb1HQBZrvdthbYdIHCx2792+32wvlvQCmDWqL1NbbB8kYZNhebTF+bvPNlUKuAtUHt43SqPY36SS979fbDRkPb69G3oLbT6WiP1PkwmZT1pO6VbbRYvu8Vk7lvb4p6ZjqnpHVs8DlNts4qv0TVj7psZLvdxheXl0YNiKNg1nj7Vlsi/86D06+3223sdrv47fU1PjvTLxulWFd8Y21gm6Pt7u5jGywqNJMsbaDWfU1uFF4XNVF2iXo/3gwG2nL+R80mHjWbVrK2yHW/b63wYj8IrFxH52YwSDP1eJPbQPJ1LqV8HusXyDZYZEWGxsXDmV/TTim2pJRNHytayY7E+9S+PzrKcx'+
			'wAwum8IjQyvh2N8MOxyexH4cy10WIbLLLM5GdpHFXnql9NghPX1koscVC7G4/x3aG2obgV0fV9L4//8eQk16+DhzpSyg7X0bxlsj7mPEvJ0BIrPuVoMgXJRscllqpN1u1ohMnenvWKv+t+H/9+/jxTKX/ewfBmMMBkb68QmWQOemAbLF95U/SRksna1lQ1dr6n/mzyn59rayWV+jy1D5MJvj86wsNG4760X1fqvsrH6fQ+ONgKEj8cH+Pz83NrWw3eD4e4G4/x03SKGw8KVxyro7g3z9JS2bPJD7zTTE0VG5lMPS67WZh0VmlLKU8Kcr4cpWB8SOjs+pcP60t34zEme3uuh1EUJ8h/KjHa6+C8hNrjQ0KzMpm+m3pwIzdtibXs3aVJZxW2ziopL7r002YJIfrId9PuFED+lUUVpioHTYKa042VGRoXLz21W3VWYXk/'+
			'AQiD2oHrQZATWU9SXnltD7KB0srYc9N1kUgbdrO0iMlCf52ts8qHmVpFqXe3ecwb94UQpesd5gsV0C5gvlfQ9ffGJDsardtXlqG8n9layRivqVHxCSGGUsoB7O3bmYBrFLlRx/xkqUIdu+zOn6FxcUtKmVcnhYaUshOvqqTiYqZGJzBrDqtzxGlH+6SUbXUmXNZTEVzfuH2d6mNDgRJhplZx6rDJIwCXGS/l5WGaRaKmFqOtE1G5vukaVNzEZTaiClt83RbSklK2kp4jSH77BGGz3d+7Hgi5I4QYSymzlPmPVEWllyxOXY2EEDbbyTRnTuXOey+g6++P72tXXZTjGJ/K20Jxm+0WifdfYxWUTDKtKfIpOKmCOsJ9fHlnMSPHWVoDHuxXXKPF1lnlsIViHotSKPtBUJSv8RHSl/kfuyw+oLWmCNdNXfI9S4sUZZy0wh'+
			'aAV64HUXLfuB5AUio4pbkBDli+771jl2udGRoXu8BGxyWwtR8ENyjQjbeAXrkeQBpqmipJoEobAGnzjj1401GUgBZhJWTBRSX9XzkdRbm9dD0AA8dYX+bP8n2/Hbvee6WqOYsW1Lpq3FRQnwDAfhC8vKrVTgF84XY4pfO6QOtp91SZ/zHCzhU6LN/31xR+ZGiAeePiIey082oifebFRscFN7tP7RTAXx2No6xOXQ/AlBBitKTMf+xz+X7FjeBX4Y7RKQKw1DtUZVwtpA+sDGoFdt9RZD8IXgJ47W4opfO3/SB45XoQWWjK/Nl9308ThIHg0JeAlqEl1tDWtLa6jknG2mCj4+KKt8l6AeCdi4GUzDsAf3Q9CEtmy/xPfLlpEoDwDcexEGLP9fqZhml5vO0MyfR6LO8vqLmgpiohD8DAltWB+loW3kyZ/9DDG2cVjRF+'+
			'P/aEEM99/J6oxsumWZrVN03qeiadQhrq30EFs9D7cT8I3lzVagcIS9Efb3pAJfCnIhaHrCKEGEgpfSg8qJIxwgx5oh5jhOuZRag4NZ26yytA92HW0aQD90f1UEq1INC3xbuq1XYAfA32hUzqHcIMrVQBjYioSJYePbMfBDf7QXAA4E/gdOQ6rwE8ZUAjInJraaY2S2VtLwB8CeB3eQ+qQF4DOC16lSMRUVkkCmqzrmq1pwCezTx2LIxjB8UJlt8gXG98ycyMiMgvqYNaUalg/DTDJW4YxIiI/FaZoEZEROW3tFCEiIioaBjUiIioNBjUiIioNBjUiIioNBjUiIioNBjUiIioNBjUiIioNBjUiIioNP4PaBUlC18e150AAAAASUVORK5CYII=';
		els.setAttribute('src',hs);
		els.ggNormalSrc=hs;
		hs ='';
		hs += 'position: absolute;top: 0px;left: 0px;width: 100%;height: 100%;-webkit-user-drag:none;pointer-events:none;;';
		els.setAttribute('style', hs);
		els.className='ggskin ggskin_image';
		els['ondragstart']=function() { return false; };
		player.checkLoaded.push(els);
		el.appendChild(els);
		el.ggSubElement = els;
		el.ggId="Image 2";
		el.ggDx=23;
		el.ggDy=-58;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_image ";
		el.ggType='image';
		hs ='';
		hs+='cursor : pointer;';
		hs+='height : 45px;';
		hs+='left : calc(50% - ((194px + 0px) / 2) + 23px);';
		hs+='position : absolute;';
		hs+='top : calc(50% - ((45px + 0px) / 2) - 58px);';
		hs+='visibility : inherit;';
		hs+='width : 194px;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me._image_2.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._image_2.onclick=function (e) {
			player.openUrl("https:\/\/3dwisemedia.com\/","_self");
		}
		me._image_2.ggUpdatePosition=function (useTransition) {
		}
		me._alt_men.appendChild(me._image_2);
		me.divSkin.appendChild(me._alt_men);
		el=me._audio2=document.createElement('div');
		el.ggId="Audio2";
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=false;
		el.className="ggskin ggskin_rectangle ";
		el.ggType='rectangle';
		hs ='';
		hs+='background : #151515;';
		hs+='border : 2px solid #ffffff;';
		hs+='border-radius : 7px;';
		hs+='cursor : pointer;';
		hs+='height : 36px;';
		hs+='position : absolute;';
		hs+='right : 120px;';
		hs+='top : 10px;';
		hs+='visibility : hidden;';
		hs+='width : 36px;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me._audio2.ggIsActive=function() {
			return false;
		}
		el.ggElementNodeId=function() {
			return player.getCurrentNode();
		}
		me._audio2.logicBlock_position = function() {
			var newLogicStatePosition;
			if (
				((player.getViewerSize(true).width < 480))
			)
			{
				newLogicStatePosition = 0;
			}
			else {
				newLogicStatePosition = -1;
			}
			if (me._audio2.ggCurrentLogicStatePosition != newLogicStatePosition) {
				me._audio2.ggCurrentLogicStatePosition = newLogicStatePosition;
				me._audio2.style.transition='right 0s, top 0s, transform 200ms ease 0ms, background-color 0s';
				if (me._audio2.ggCurrentLogicStatePosition == 0) {
					me._audio2.style.right='50px';
					me._audio2.style.top='10px';
				}
				else {
					me._audio2.style.right='120px';
					me._audio2.style.top='10px';
				}
			}
		}
		me._audio2.logicBlock_position();
		me._audio2.logicBlock_scaling = function() {
			var newLogicStateScaling;
			if (
				((me.elementMouseOver['audio2'] == true))
			)
			{
				newLogicStateScaling = 0;
			}
			else {
				newLogicStateScaling = -1;
			}
			if (me._audio2.ggCurrentLogicStateScaling != newLogicStateScaling) {
				me._audio2.ggCurrentLogicStateScaling = newLogicStateScaling;
				me._audio2.style.transition='right 0s, top 0s, transform 200ms ease 0ms, background-color 0s';
				if (me._audio2.ggCurrentLogicStateScaling == 0) {
					me._audio2.ggParameter.sx = 1.1;
					me._audio2.ggParameter.sy = 1.1;
					me._audio2.style.transform=parameterToTransform(me._audio2.ggParameter);
					setTimeout(function() {skin.updateSize(me._audio2);}, 250);
				}
				else {
					me._audio2.ggParameter.sx = 1;
					me._audio2.ggParameter.sy = 1;
					me._audio2.style.transform=parameterToTransform(me._audio2.ggParameter);
					setTimeout(function() {skin.updateSize(me._audio2);}, 250);
				}
			}
		}
		me._audio2.logicBlock_scaling();
		me._audio2.logicBlock_backgroundcolor = function() {
			var newLogicStateBackgroundColor;
			if (
				((me.elementMouseOver['audio2'] == true))
			)
			{
				newLogicStateBackgroundColor = 0;
			}
			else {
				newLogicStateBackgroundColor = -1;
			}
			if (me._audio2.ggCurrentLogicStateBackgroundColor != newLogicStateBackgroundColor) {
				me._audio2.ggCurrentLogicStateBackgroundColor = newLogicStateBackgroundColor;
				me._audio2.style.transition='right 0s, top 0s, transform 200ms ease 0ms, background-color 0s';
				if (me._audio2.ggCurrentLogicStateBackgroundColor == 0) {
					me._audio2.style.backgroundColor="rgba(70,65,95,1)";
				}
				else {
					me._audio2.style.backgroundColor="rgba(21,21,21,1)";
				}
			}
		}
		me._audio2.logicBlock_backgroundcolor();
		me._audio2.onclick=function (e) {
				player.playSound("RUDDA_BRAND_MUSIC_TELEPHONE_LOOP_VOCAL_01","-1");
		}
		me._audio2.onmouseenter=function (e) {
			me.elementMouseOver['audio2']=true;
			me._audio2.logicBlock_scaling();
			me._audio2.logicBlock_backgroundcolor();
		}
		me._audio2.onmouseleave=function (e) {
			me.elementMouseOver['audio2']=false;
			me._audio2.logicBlock_scaling();
			me._audio2.logicBlock_backgroundcolor();
		}
		me._audio2.ggUpdatePosition=function (useTransition) {
		}
		el=me._open=document.createElement('div');
		els=me._open__img=document.createElement('img');
		els.className='ggskin ggskin_open';
		hs=basePath + 'images/open.png';
		els.setAttribute('src',hs);
		els.ggNormalSrc=hs;
		hs ='';
		hs += 'position: absolute;top: 0px;left: 0px;width: 100%;height: 100%;-webkit-user-drag:none;pointer-events:none;;';
		els.setAttribute('style', hs);
		els.className='ggskin ggskin_image';
		els['ondragstart']=function() { return false; };
		player.checkLoaded.push(els);
		el.appendChild(els);
		el.ggSubElement = els;
		el.ggId="open";
		el.ggDx=0;
		el.ggDy=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=false;
		el.className="ggskin ggskin_image ";
		el.ggType='image';
		hs ='';
		hs+='height : 24px;';
		hs+='left : calc(50% - ((24px + 0px) / 2) + 0px);';
		hs+='position : absolute;';
		hs+='top : calc(50% - ((24px + 0px) / 2) + 0px);';
		hs+='visibility : hidden;';
		hs+='width : 24px;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me._open.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._open.ggUpdatePosition=function (useTransition) {
		}
		me._audio2.appendChild(me._open);
		me.divSkin.appendChild(me._audio2);
		el=me._audio=document.createElement('div');
		el.ggId="Audio";
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=false;
		el.className="ggskin ggskin_rectangle ";
		el.ggType='rectangle';
		hs ='';
		hs+='background : #151515;';
		hs+='border : 2px solid #ffffff;';
		hs+='border-radius : 7px;';
		hs+='cursor : pointer;';
		hs+='height : 36px;';
		hs+='position : absolute;';
		hs+='right : 80px;';
		hs+='top : 10px;';
		hs+='visibility : hidden;';
		hs+='width : 36px;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me._audio.ggIsActive=function() {
			return false;
		}
		el.ggElementNodeId=function() {
			return player.getCurrentNode();
		}
		me._audio.logicBlock_position = function() {
			var newLogicStatePosition;
			if (
				((player.getViewerSize(true).width < 480))
			)
			{
				newLogicStatePosition = 0;
			}
			else {
				newLogicStatePosition = -1;
			}
			if (me._audio.ggCurrentLogicStatePosition != newLogicStatePosition) {
				me._audio.ggCurrentLogicStatePosition = newLogicStatePosition;
				me._audio.style.transition='right 0s, top 0s, transform 200ms ease 0ms, background-color 0s';
				if (me._audio.ggCurrentLogicStatePosition == 0) {
					me._audio.style.right='50px';
					me._audio.style.top='10px';
				}
				else {
					me._audio.style.right='80px';
					me._audio.style.top='10px';
				}
			}
		}
		me._audio.logicBlock_position();
		me._audio.logicBlock_scaling = function() {
			var newLogicStateScaling;
			if (
				((me.elementMouseOver['audio'] == true))
			)
			{
				newLogicStateScaling = 0;
			}
			else {
				newLogicStateScaling = -1;
			}
			if (me._audio.ggCurrentLogicStateScaling != newLogicStateScaling) {
				me._audio.ggCurrentLogicStateScaling = newLogicStateScaling;
				me._audio.style.transition='right 0s, top 0s, transform 200ms ease 0ms, background-color 0s';
				if (me._audio.ggCurrentLogicStateScaling == 0) {
					me._audio.ggParameter.sx = 1.1;
					me._audio.ggParameter.sy = 1.1;
					me._audio.style.transform=parameterToTransform(me._audio.ggParameter);
					setTimeout(function() {skin.updateSize(me._audio);}, 250);
				}
				else {
					me._audio.ggParameter.sx = 1;
					me._audio.ggParameter.sy = 1;
					me._audio.style.transform=parameterToTransform(me._audio.ggParameter);
					setTimeout(function() {skin.updateSize(me._audio);}, 250);
				}
			}
		}
		me._audio.logicBlock_scaling();
		me._audio.logicBlock_backgroundcolor = function() {
			var newLogicStateBackgroundColor;
			if (
				((me.elementMouseOver['audio'] == true))
			)
			{
				newLogicStateBackgroundColor = 0;
			}
			else {
				newLogicStateBackgroundColor = -1;
			}
			if (me._audio.ggCurrentLogicStateBackgroundColor != newLogicStateBackgroundColor) {
				me._audio.ggCurrentLogicStateBackgroundColor = newLogicStateBackgroundColor;
				me._audio.style.transition='right 0s, top 0s, transform 200ms ease 0ms, background-color 0s';
				if (me._audio.ggCurrentLogicStateBackgroundColor == 0) {
					me._audio.style.backgroundColor="rgba(70,65,95,1)";
				}
				else {
					me._audio.style.backgroundColor="rgba(21,21,21,1)";
				}
			}
		}
		me._audio.logicBlock_backgroundcolor();
		me._audio.onclick=function (e) {
				player.stopSound("RUDDA_BRAND_MUSIC_TELEPHONE_LOOP_VOCAL_01");
		}
		me._audio.onmouseenter=function (e) {
			me.elementMouseOver['audio']=true;
			me._audio.logicBlock_scaling();
			me._audio.logicBlock_backgroundcolor();
		}
		me._audio.onmouseleave=function (e) {
			me.elementMouseOver['audio']=false;
			me._audio.logicBlock_scaling();
			me._audio.logicBlock_backgroundcolor();
		}
		me._audio.ggUpdatePosition=function (useTransition) {
		}
		el=me._close1=document.createElement('div');
		els=me._close1__img=document.createElement('img');
		els.className='ggskin ggskin_close1';
		hs='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAgAElEQVR4nO3de7BsaVkf4N93HCRDGCBgYhGDylUBEWaAgMN4IWguSJKKCferFcBUYYKK4KWsSirGKKAGkFKZ6B8gyMwZTIwIXmKK6wyEy2AQTWIUKRWMKJQMGlSo+fJH9x56ztnn7L17r+7vW996nioKHaD73bvX7vfX77vW6hKAztVa75Lk763/db8kd09ypyQ3Jflkkt9McmOSNya5vpTymWM+7k7qhV0qpUzzOJM8CsAO1Frvm+R5SZ6S5LbH/J99OMnLk/x4KeVPjnj80xUIDQgAwLBqrZcm+ddZNf9LtnyYjyb5jiSvLKUc2ukFAOZIAACGVGt9YJJrk3zJRA/5n5I8o5TyyUOea6KngP2ZKgCcmeRRACZQa/2mJO/MdM0/Sb4hyfW11r8x4W'+
			'PC7JkAAM3VWi9LcnWSJ+zwad6f5JGllI9vPO8Onw52wwoAGEKt9X5Jrsvq7P5de2OSxxycEyAAMEdWAMDsrUf+781+mn+SPDrJN+/puaBrJgDA3q1H/q9I8sQGT/8nSe5VSvmYCQBzZAIAzFKt9UFZfepv0fyT1Q2EntfouaEbJgDA3tRan5bkx5LcrnEpf5jkbkk+3bgOODETAGA2aq2X1Vpfm+SVad/8k+TzkzyqdRHQkgAA7NT6LP93ZreX+G3jq1oXAC0JAMDO1Fr/RfZ7lv9JPKx1AdDStvfYBrigxmf5H9cXtC4AWhIAgEnVWu+f5Gz6/NS/6S6tC4CWrACAyazP8n9X+m/+SXJp6wKgJRMA4NRmMvIHNggAwKnUWi/P6ut77926FuD4rACAra1H/m+P5g+zYwIAnJiRP8yfAACciJE/jMEKADg2I38YhwkA'+
			'cCQjfxiPAABclJE/jMkKALggI38YlwkAcB4jfxifAADcynrkfzbJvVrXAuyOFQBwi42Rv+YPgzMBAA5G/lcneULrWoD9EABg4Yz8YZmsAGDB1iP/66P5w+KYAMACGfkDAgAsjJE/kFgBwKIY+QMHTABgAYz8gXMJADA4I3/gMFYAMDAjf+BCTABgQEb+wFEEABiMkT9wHFYAMBAjf+C4TABgAEb+wEkJADBzRv7ANqwAYMaM/IFtmQDADBn5A6clAMDM1FqvSHJtfOoHTsEKAGZkPfJ/ezR/4JRMAGAGaq13TPITSf5Z61oGUloXAC2ZAEDn1iP/92Ss5n9Tkqc0rqE2fn5oSgCAjg068r8xyYOzOo8BaEQAgA7VWu9Qa31tklcmubR1PRP6qSRXlVJ+q3UhsHTOAYDODHqW/01Jnl1K8akfOmECAB0ZeeSv+UNfBA'+
			'DowHrkf03GG/lfneRKI3/ojxUANGbkD7RgAgANGfkDrQgA0ICRP9CaFQDsmZE/0AMTANijWuuzk9yQsZr/jUmu0PxhXgQA2IONkf8rkty2dT0TOhj5/3brQoCTsQKAHTPyB3pkAgA7ZOQP9EoAgB0w8gd6ZwUAE1uP/M8muWfrWiZ0U5JnlVLOti4EmIYJAExoY+Q/UvN/b1Yjf80fBiIAwASM/IG5sQKAUzLyB+bIBABOwcgfmCsBALZg5A/MnRUAnJCRPzACEwA4ASN/YBQCAByDkT8wGisAOIKRPzAiEwC4CCN/YFQCABxiPfK/Nkb+wKCsAOActdYHZ/X1vSN96r8pyTNLKde1LqQjpXUB0JIJAGwYeOR/ueYPbBIAIOeN/D+3dT0TOhj5f7B1IUBfrABYPCN/YIlMAFi0QUf+74mRP3AEAYBFGnTkX5O8LMkj'+
			'jPyBo1gBsDhG/gAmACyMkT/AigDAIhj5A9yaFQDDM/IHOJ8JAEMz8gc4nADAkIz8AS7OCoDhDDry/0RWI//XtS4EGIMJAEMZeOR/heYPTEkAYAjrkf/ZGPkDHIsVALNn5A9wciYAzJqRP8B2BABmycgf4HSsAJid9cj/bJJ7tK5lQkb+wF6ZADArGyP/kZq/kT+wdwIAs2DkDzAtKwC6Z+QPMD0TALo28Mj/cs0faEkAoEsLGPn/TutigGWzAqA7tdaHZHVjn5E+9Rv5A10xAaAbtdZSa31ukuszVvN/d4z8gc4IAHSh1nqHrD71vyTjjfyvMvIHemMFQHMDj/z/eSnlZ1oXAnAYEwCaWcDIX/MHuiUA0ISRP0BbVgDsnZE/QHsmAOyNkT9APwQA9qLWescY+QN0wwqAnRt05P+xJE8vpbyhdSEA2zABYGcGH/k/VP'+
			'MH5kwAYCfWI/+zMfIH6JIVAJMz8gfonwkAkzHyB5gPAYBJ1FrvnORnM97I/0VJrjTyH1JpXQC0ZAXAqdVaH57kmiRf1LqWCRn5A0MzAWBr65H/tyV5a8Zq/tdndWMfzR8YlgDAVjZG/j+U5DaNy5nKwcj/a0opv9e6GIBdsgLgxAYd+f9xViP/N7YuBGAfTAA4tsFH/ldo/sCSCAAcy8Aj/xfGyB9YICsAjmTkDzAeEwAuaD3yf17GHPlfrvkDSyYAcKj1yP+/JPnBjDny//3WxQC0ZAXAedb38j+b5O6ta5nQx5I8zad+NtTWBUBLJgDcYmPkf0PGav5vT/IgzZ9zuBUwiyYAkORWX9872sj/ZUn+jpE/hzABYNGsAEit9aFZfX3vSJ/6neUPcBEmAAu2MfK/PmM1/7fHWf4czQqARRMAFsrIH6wAWDYrgAUy8gfA'+
			'BGBB1iP/b894I/+3xcifk7MCYNEEgIXYGPm/OOON/B9l5M8WrABYNCuABTDyB+BcJgADG3zk78Y+nJYVAIsmAAxqPfK/LuOO/D/cuhhmzwqARbMCGJCRPxyLCQCLZgIwECN/AI5LABhErfUuSX4uY438b07y77O6sY+RP8CErAAGUGu9Mslrk3xh61om9EdJnlpK+aXWhQCMyARgxtYj/+cmeVPGav5vzerGPpo/wI4IADO1MfJ/SZLPbVzOVA5G/s7yB9gxK4AZWo/8r0lyt9a1TMjIH2CPTABmZD3yf36SN2es5m/kD7BnAsBMbIz8X5TxzvI38gfYs0lWALXWM0kuT/LIJF+W5L5J7prk9kn+2hTPwXCM/AEaOlUAqLU+LMnTkzwuyV0mqYgleGuSJ5ZSPtK6EICl2ioA1FofneR7knzFtOUwuJuTfH+Sf1NK+U'+
			'zrYgCW7EQBoNb6pUl+NKtRP5zER7Ma+f9y60IAOOZJgOuzz1+Q5H9E8+fk3pLVWf6aP0AnjgwAtdY7JXl9khdmnBvOsB83J/m+rM7yt+8H6MhFVwC11rsm+YUkD9xPOQzEyB+gYxcMAOvm/7Yk99xfOQziLUme5FM/QL8OXQGsx/6/GM2fk7k5yb+LkT9A986bANRaS5LXJPny/ZfDjH00yVNKKf+1dSEAHO2wFcALkjx634Uwa0b+ADNTNv+fWut9krw/yW3blMPM1CQ/kuTbSymfbl0M81JrvSRJy+PmU0lu1/D5YSullKP/S8dwywRgPfq/Opo/x2PkDzBjmyuARyf56laFMCtvTvJkI3+A+dq8CuB7mlXBXNyc5HuTfK3mDzBvlyRJrfXhSR7euBb6ZuQPMJCDFcAzWhZB996c1Vn+f9C6EACmcabW+jlJHtu6'+
			'ELq0OfLX/AEGckmSK5LcuXUhdOcPsxr5/0rrQgCY3iXx9b6c701ZneXvUz/AoM7ELX/5rJrV1z5/neYPMLZLknxp6yLowh9l9fW9v9S6EAB275Ikf7N1ETRn5M8STXM/VZipM0kua10Ezdyc5N/GyB9gcUqt9eZIwkv10VLK57cugmXq4MuA/jzJpQ2fH7Yy1ZcBnYnmDwCLc+bo/wrAkGrrAqAlAQAAFkgAAJbK+pNFEwCApbICYNEEAABYIAEAWCorABbtktYFlKkuaJyhWuvnJ/m/reuAhbICYNFMAIClWuyHD/rS6nOwAAAs1T4mAPWQf+3ruelfTZJaa5Njo/kKAKCRXX7sutib+Llv9CYRy3HYcVEP+b83/9nOjg8TAGCpdvVJ66SPu/npj3Ft+xrv7NgQAACmc5o3ayFgXKd9bXdybAgAbfmDh3YmG62uT+'+
			'Ka4u/Ze8J4pnpNJz82BACAU1qfxDXZw034WDTU+1XuAkBbfR8dMLaeG23PtXE8deJgmEx8XAgAbfkjh/nr5WRCOBEBAFiqqSZwrS4npE+7vqpjsscWAICl6vbkrD0/PtOZ1WslAABLNadzcGbVWBZqdq+RAAAwD7NrMAsyy9dGAACYj1k2mpH1fqnfxQgAbfljhvnbdwfwvtGPXVzqtzcCAMD8zLbp0A8BAGCehIB2Wn6B02QTJwEA4PRaLYKFgOVxHwCAzggB4+vhq5tNAAA6JASMq4ff8aTHlwAAMC0hYDCdXOo3eRECAMD0hIBx9HCp306OJwEAYDeEAKaws+NIAADYHSFgvoY64e8wAgDAbgkBbGPnx40A0JY/UFgGIWA+hv/kf0AAaKuLU0uBvRAC+tfD72pvx4kAALA/QkC/evgd7fX4EADa6uGAA/ZLCOhP'+
			'D7+bvR8XAgDA/gkB/ejhd9LkeBAAANoQAtrr4XfR7FwwAQCgHSFg2ZqeCC4AALQlBOzfYi71uxgBAKA9IWB/eviZmzf/RABorYcDEeiDELB7zX/W0slXCyYCAEBPhICxlfZfLPhZAgBAX4SA6dn5H0IAAOiPEDCdHn6m7pp/IgAA9EoIOL0efpYum38iAAD0TAjYXg8/Q7fNPxEAAHonBJxcD7V33fwTAQBgDoSA4+uh5u6bfyIAAMyFEDAPs2j+iQAAMCdCwIW51O+EBIC2Wh+swPwIAefrobZZNf9EAGhtdgcM0AUh4LN6qGmW7+UCQFs9HLjAPAkBfdQyy+afCACtzfbAAbqw5BDQQw2zfg8XANrq4QAG5m2JIaCH985ZN/9EAAAYwRJDQEuzb/6JAAAs1xBv4huWEAJc6jchAQBgHCOHgNaNPxmo+ScCAMBoRg'+
			'wBmv8OCAAA4xkpBGj+OyIAtNXDgQ2MaYQQ0MN75JDNPxEAWhv2wIIZ6KG57NqcQ0APr8/Q79ECQFs9HOCwVEO/uW+YcwhoafjjQwAAGN+cQoBL/fZEAABYhjmFgJYW0fwTAQBgSXoOAT7575kAACxV62bTSo8hoIfXYlHNPxEAgOVa3Bv+hp5CgObfiAAAsEw9hADNvyEBAGC5eggBLS22+ScCQGu9/BEAy7XUELDo5p8IAK0t/gCEhlo3oJ4s7b1oaT/voQQAAJLlNMWl/JxHEgDa8gkE2tEIzjf672T0n+9EBAAANo3aJEf9ubYmAABLZQJ3YaM1y9F+nkkIAAAcZpSmOcrPMTkBAFgqjeFoc/8dzb3+nRIAALiYuTbRuda9NwIAAEeZWzOdW71NCADAUjkJ8GTm0lTnUmdzAkBb3oCgHY3i5Hr/nfVeX1cEgLYc'+
			'rNCOAL6dXt+3eq2rWwIAACfVW7PtrZ5ZEADa8gkE2tE0TqeX318vdcyOAADANnr4AKP5n4IAAMBJ9dD8OSUBAIC5EkROQQAA4Lhq+mu6vdUzGwIAAMfRc6PtubZuCQBtOWiBOZjDe9UcauyKAADAxcypsc6p1uYEgLZcwgL0bI4NdY41NyEAtOVABXo15/enOde+NwIAALdSyhDDSSHgCAIAAJtqrXWU5jnKz7ETAgAAB0ZsmCP+TJMQAABIxm6UI/9sWxMAAFgCIeAcAgDAsvV4e99dWcrPeSwCQFsORqClJb4HLfFnPpQAALBMPTTCVtcb9vCzNycAACxPDw2wnPPv+9bD76ApAaCtIe62AcxKD43v3Pc+IaABAaCtRR98wN718J5zoWYvBOyZAADAvhzV5IWAPRIAAMbXw6V+x23uQsCeCAAAY+uhsZ20qQsBey'+
			'AAAIyrh4a2bTMXAnZMAAAYUw+N7LRNXAjYIQGgrUUcZMDe9fDeMlXzFgJ2RAAAGEsPjWvqpi0E7IAA0JYbAQGj2dX7mhAwMQGgrWEPLGDv5nSpX6+PfyGtf687IQAAzF8PDWpfzVkImIgAACzVKCu4HhrTvn+XQsAEBACA+eqhIbVqxkLAKQkAAPPUQyNqPUURAk5BAACWas5v4j3U3rr5HxACtiQAAEvVSwObo95+d0LAFgSAtmZ98AB7t4RL/bYlBJyQAADAcfXa/A8IAScgAAD0zyf/4xMCjkkAAOhbD41lLs3/gBBwDAIAQL96aChza/4HhIAjCAAAfeqhkcy1+R8QAi5CAADgMHNv/geEgAsQAAD64oS/6QkBhxAAANg0WvM/IAScQwAA6INP/rsnBGwQANrq8qAA9q6H94LRm/8BIWBNAABoq4fGsJTmf0AI'+
			'iAAA0FIPDWFpzf/A4kOAAACwXEtt/gcWHQIEAID9c8JfPxYbAgQAgP1q/sYfzf9ciwwBAgCwVC3efDX/fi0uBAgAwFItsREu8Wc+iUWFAAEAYPfs/OdjMSFAAACWal9vuK0bf6L5n9QiQoAAALA7mv98DR8CBIC2enhzgKXa9Rt8D3/fmv/pDB0CBACA6Wn+4xg2BAgAbfkDhXZ29Qar+Y9nyBAgALTVwxsFLNXkb+qldNF3uyhiQMOFAAEAYBq11to61Gv+uzVUCBAAAMag+e/HMCFAAAA4pQ5G/80LWJghft8CAMApNR79D9GMZqjF733S40wAAJgvzb+tWf/+BYC2Wp8wBJxeq7/jWTefgez7dZjseBMAAE6nRSPW/Psyy9dDAAA4nX1PAGbZbBZgdq+LAAAwH7NrMgszq9dHAACYh1k1lwWbzeskAAD0bzZNhS'+
			'Qzeb0EAIDT2fWb/SyaCefp/nUTAAD61X0T4aK6fv0EAIDT28UbfdfNg2Ob9HUsE953WgAAmMaUb/Sa/1imej3LlHedFgAApjPFG73mP6bTvq6THxcCQFtuBQzjOc0bteY/tm1f350cFwJAW/7YYUzb/G17P1iGk77OOzsuBACA3TjJG7fmvyzHer2nPOHvMJfs8sE5khUAjE1j50JuOTZKKamrs/vO/Wc7LaB5AKi7/gkBoGPrNlgO+Wc7ZQUAAAskAADAAgkAALBAAgAALJAAAAALJAAAwAKdiWvRAWBxziT5s9ZF0Mzn1Vq/r9ba/H4QAOzXmSR/2roImjmT5LuT/Lda6xe0LgaA/TmT5A9aF0FzX5XkV2ut/6B1IQDsx5kk/7t1EXTh85K8odb60lrrbVoXA8BunUnygdZF0I2S5F/FSoBl8EU9LNqZJG9pXQTd'+
			'+cqsVgKPbl0I7JAroFi0M0neFScCcr7PS/Lztdbvd5UAgzIBYNHOlFL+Msl/bl0IXSpJvjPJm2qtf6t1MQBM5+BOgK9uWgW9uyrJ+6wEGIwVAIt2EAB+JclvtCyE7h2sBH7ASoBBWAGwaGeSpJRyc5IfaFwL/StJviNWAgCzt/llQK9N8v5WhTArVgIAM3dLACilfCbJc2IvxvEcrAReaCUAMD+3+jrgUsrbk7y8US3MT0nygiRvrrXerXUxABzfeSfB1Fpvm+SGJFfsvxxm7GNJnl5KeUPrQpiH9eTo0w1L+HSSz234/LCVUqY5f/XMuf+glPIXSf5Jkg9P8gwsxV2SvN5KAGAeLhgjaq0PSPLmJHfeWzWM4oYkTyil/F7rQuiXCQBsZ2cTgI0n+LUkX53kI5M8E0tyZVZXCXx960IAONwFA0CSlFI+kOQRSW7cTz'+
			'kM5GAl8CJfLwzQn4sGgCQppXwoqxDwo3GJICdTkjw/q6sEvrB1MQB81pEBIElKKX9eSnlOViuBX99tSQzoyiQ31lof07oQAFaOFQAOlFLeluRBSZ6R5Dd3URDDukuSn6u1vthKAKC9rU8lrLV+TpKvTfLUJP84ye2nKorhvSOrqwR+t3UhtOMqANjOVFcBTPIo6090D0vyNUnun+Q+Se6a5LIIBhzu40meUUp5fetCaEMAgO10FQDYvVrrX0/yqiR/v3UtE6pJfjjJd5VSWjYCGhAAYDs7vw8AfSml/FGSRyf57iSfaVzOVEqS5yV5a631i1oXA7AkJgAzVGv9yqy+vvkLWtcyoY8n+cZSys+1LoT9MAGA7ZgALNj6aozLk/xi61omdOckP1tr/SFXCQDsngAwUxsrgW9J209RUypJvi3JDbXWe7QuhuG5sRmLJgDM'+
			'WCmlllJemuSqJB9qXM6UHpLVjYMe27oQgFEJAAMopbwryUOT/ELrWiZ0xyTX1lp/uNZqT8suOAeKRRMABlFK+eMkX5/kuzLWVQLfmtVVAl/cuBaAoUjAA6q1/u0k1yb54salTOmmJM8spVzXuhCm4SoA2I6rALigjZXAG1vXMqE7JDlba32FlQDA6QkAg1qvBB6T5DszzkogSZ6d5G1WAgCnYwWwAFYC9MgKALZjBcCxrVcCD4mVAABrAsBClFI+lrFXAndvXQjAnFgBLNDAK4FnlVLOti6E47ECgO1YAbC1jZXAG1rXMqE7ZHXjICsBgGMQABZqvRL4h0m+I+OtBN5uJQBwcQLAgq2/S+BFSR6R5Hda1zOhhyb51Vrr41oXAtArAYDNGweNuhK4betiAHojAJBkESsBXy8MsEEA4BYbK4ErM9ZK4CFJ3ldrfXzrQg'+
			'B6IQBwnlLKuzPmSuCaWuvLrAQABAAuYGMl8IKMtRL4l7ESABAAuLD1SuDFsRIAGI4AwJEGXwn8iJUAsEQCAMdyzkqg5e1bp/bNSa6vtd6zdSEA++S7ADixWuuVSa5JcrfWtUzoE1l9vfDrWheyFL4LALbjuwBoppRyQ5LLk/x861omdMck19VaX24lACyBAMBW1iuBf5Tk+RlrJfCcJDdYCQCjEwDY2voqgR9M8tVJfrd1PRO6Isl7a62PbV0IwK4IAJxaKeUdWTXN0VYCZ60EgFEJAExiYyXwLUn+snE5U3pOknfUWu/VuhCAKQkATGa9Enhpkqsy1o2DLk9yY631Ca0LAZiKAMDk1jcOujzJSJfUXZbktbXWV9Vab9e6GIDTEgDYiVLKJ5I8LuOtBJ6a1XcJWAkAsyYAsDMLWAk8sXUhANsSANi5gVcCP20lAMyV'+
			'AMBeLGAlcO/WhQCchADA3mysBB6R8VYC77USAOZEAGDvSinviZUAQFMCAE0MvhJ4d631/q0LAbgYAYBmzlkJfLB1PRO6X1Z3D7QSALolANDceiVwRawEAPZGAKALVgIA+yUA0I0FrASe1LoQgAMCAN0ZeCXwGisBoBcCAF2yEgDYLQGAbg2+EnhnrfXJrQsBlksAoHsbK4HrWtcyodsnebWVANCKAMAsrFcCj4+VAMAkBABmw0oAYDoCALOz8V0CVgIAWxIAmKVSyk0ZdyXwnlrrl7UuBBibAMBsDbwSuG9WNw6yEgB2RgBg9hawEvirrYsBxiMAMIRSyk2llMcl+aaMtxJ4t5UAMDUBgKGUUq5OcmXGWwm8q9b6zNaFAOMQABhOKeW9GW8lcGmS/2glAExFAGBIVgIAFycAMLSNlcBvt65lQlYCwKkJAAxvvRIY7b'+
			'sErASAUxEAWITBVwLvqbU+oHUhwLwIACzKoCuBL03y32utz2pdCDAfAgCLs7ESONu6lgldmuRqKwHguAQAFmm9Enh8rASAhRIAWLTBVwLPbl0I0C8BgMUbeCXwCisB4EIEAIiVwEKV1gVASwIAbBh8JfDc1oUA/RAA4BwDrwReYiUAHBAA4BDnrAT+onU9E7ISAJIIAHBRA68E3mUlAMsmAMARSik3ZrUSuLZ1LRP6K/nsSuD2rYsB9k8AgGNYrwSekHFXAl/euhBgvwQAOIFBVwJfElcJwOIIAHBCVgLACAQA2IKVADB3AgCcwsZK4Lda1zIhKwFYAAEATmm9EnhwxlwJ/JSVAIxJAIAJDLwSeEqsBGBIAgBMyEoAmAsBACZmJQDMgQAAO7CxEnh6kk+1rmdCByuBB7YuBDgdAQB2qJTyqiRXZbyVwDutBGDeBADY'+
			'scFXAq+rtd6xdTHAyQkAsAcDrwT+aVbfLGglADMjAMAeDboSuE+sBGB2BADYs43vErimdS0TshKAmREAoIFSyidLKU+MlQDQiAAADa1XAo+IlQCwZwIANFZKeV/GXQn8TK31Tq2LAc4nAEAHBl4JfENWtxF+UOtCgFsTAKAjA68E3mElAH0RAKAzVgLAPpTWBQAXVmt9WpIfT3Jp61om9H+SPC7JB5J8umEdn0lym4bPD1spZZrWbQIAHRv0xkH3TvKOJN/UuhBYMhMAmIFa62VJrk7yhNa1DMQEgFkyAYAFGfgqAaAREwCYmVrr5UnOJrlX61pmzgSAWTIBgIXauErgta1rAeZLAIAZWq8EnpTVSuD/ta4HmB8rAJi59Urg2qzOruf4rACYJSsAIMktK4EHx0oAOAEBAAZgJQCclBUADMZK4NisAJglKwDgUFYCwH'+
			'EIADAgKwHgKFYAMLha6/2zunHQ/VrX0hkrAGbJCgA4llLKryd5eKwEgA0CACyAlQBwLisAWJha6/2SXBcrASsAZskKANhKKeU3YiUAiycAwAJZCQBWALBwC14JWAEwS1YAwCQ2VgI/3boWYH8EAOBgJfDkWAnAYlgBALeyXgmcTXL/1rXsmBUAs2QFAOzEeiXwFbESgKEJAMB5rARgfFYAwEUNvBKwAmCWrACAvbASgDEJAMCRrARgPFYAwIkMtBKwAmCWrACAJjZuHPSa1rUA2xMAgBMrpfxpKeUpsRKA2bICAE5lxisBKwBmyQoA6IKVAMyTAACc2sZK4NlJPtW6nmMyAWXR/AEAk6q13jerrxfufSVwU5I7ti4CTsoKAOhSKeV/Zh4rgY+3LgBaEgCAyW2sBJ6VflcCH2ldALQkAAA7U0r5iSQPTvKB1rUc4l2t'+
			'C4CWBABgp9Yrga9IfyuBd7QuAFpyEiCwN7XWpyX5sSS3a1zKTUnuGjcxYoacBAjMTinlVVmdIPi/GpdyTSlF82fRTACAvau1XprkZUme2eDp/zLJfUspH6y1Nnh6OB0TAGC2SimfKqU8K6sAsO+rBP5DKeWDe35O6I4JANDU+sZBZ5N82WBUd8AAAADSSURBVB6e7j1Jriql/MX6uffwlDAtEwBgCBtXCbx6x0/1+0kee9D8YekEAKC59Y2DnprdrQQ+kuRRpZQP7eCxYZYEAKAbpZSfTPKwJL8x4cNen+ShpZTfnPAxYfYEAKArpZRfS3JFku9N8ulTPNSfJfmuJI8spbjtL5zDSYBAt2qt90zyrUm+Mce/edDHkvxkkpeVUj58xOOfrkBoYKqTAAUAoHu11suSfF2Sv5vkAUnukeS26//4piQfTPK+JL+c5C2llD'+
			'8/5uNOXyzs2FQB4P8D58YRFGRpyc4AAAAASUVORK5CYII=';
		els.setAttribute('src',hs);
		els.ggNormalSrc=hs;
		hs ='';
		hs += 'position: absolute;top: 0px;left: 0px;width: 100%;height: 100%;-webkit-user-drag:none;pointer-events:none;;';
		els.setAttribute('style', hs);
		els.className='ggskin ggskin_image';
		els['ondragstart']=function() { return false; };
		player.checkLoaded.push(els);
		el.appendChild(els);
		el.ggSubElement = els;
		el.ggId="close1";
		el.ggDx=0;
		el.ggDy=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=false;
		el.className="ggskin ggskin_image ";
		el.ggType='image';
		hs ='';
		hs+='height : 24px;';
		hs+='left : calc(50% - ((24px + 0px) / 2) + 0px);';
		hs+='position : absolute;';
		hs+='top : calc(50% - ((24px + 0px) / 2) + 0px);';
		hs+='visibility : hidden;';
		hs+='width : 24px;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me._close1.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._close1.ggUpdatePosition=function (useTransition) {
		}
		me._audio.appendChild(me._close1);
		me.divSkin.appendChild(me._audio);
		el=me._logo=document.createElement('div');
		els=me._logo__img=document.createElement('img');
		els.className='ggskin ggskin_external';
		hs ='';
		hs += 'position: absolute;-webkit-user-drag:none;pointer-events:none;;';
		els.setAttribute('style', hs);
		els.onload=function() {me._logo.ggUpdatePosition();}
		el.appendChild(els);
		el.ggSubElement = els;
		hs ='';
		el.ggAltText="";
		el.ggScrollbars=false;
		el.ggUpdateText = function() {
			me._logo.ggSubElement.setAttribute('alt', player._(me._logo.ggAltText));
			me._logo.ggUpdateImagePlaceholder();
		}
		el.ggSetImage = function(img) {
			me._logo.ggText_untranslated = img;
			me._logo.ggUpdateImageTranslation();
		}
		el.ggUpdateImage = function() {
			me._logo.ggSubElement.style.width = '0px';
			me._logo.ggSubElement.style.height = '0px';
			me._logo.ggSubElement.src='';
			me._logo.ggSubElement.src=me._logo.ggText;
		}
		el.ggUpdateImageTranslation = function() {
			if (me._logo.ggText != player._(me._logo.ggText_untranslated)) {
				me._logo.ggText = player._(me._logo.ggText_untranslated);
				me._logo.ggUpdateImage()
			}
		}
		player.addListener('', function() {
			me._logo.ggUpdateImagePlaceholder();
		});
		el.ggUpdateImagePlaceholder = function() {
			if (me._logo.ggText != "assets/"+player.getVariableValue('logo_img', me.hotspot ? me.hotspot.id : (player.hotspot ? player.hotspot.id : ''))+"") {
				me._logo.ggText="assets/"+player.getVariableValue('logo_img', me.hotspot ? me.hotspot.id : (player.hotspot ? player.hotspot.id : ''))+"";
				me._logo.ggUpdateImage()
			}
		}
		els['ondragstart']=function() { return false; };
		player.checkLoaded.push(els);
		el.ggUpdateText();
		el.ggId="Logo";
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=false;
		el.className="ggskin ggskin_external ";
		el.ggType='external';
		hs ='';
		hs+='border : 0px solid #000000;';
		hs+='cursor : pointer;';
		hs+='height : 95px;';
		hs+='left : 25px;';
		hs+='position : absolute;';
		hs+='top : 25px;';
		hs+='visibility : hidden;';
		hs+='width : 150px;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me._logo.ggIsActive=function() {
			return false;
		}
		el.ggElementNodeId=function() {
			return player.getCurrentNode();
		}
		me._logo.logicBlock_size = function() {
			var newLogicStateSize;
			if (
				((player.getVariableValue('logo_img') != "95"))
			)
			{
				newLogicStateSize = 0;
			}
			else {
				newLogicStateSize = -1;
			}
			if (me._logo.ggCurrentLogicStateSize != newLogicStateSize) {
				me._logo.ggCurrentLogicStateSize = newLogicStateSize;
				me._logo.style.transition='width 0s, height 0s, transform 500ms ease 0ms';
				if (me._logo.ggCurrentLogicStateSize == 0) {
					me._logo.style.width='150px';
					me._logo.style.height='95px';
					skin.updateSize(me._logo);
				}
				else {
					me._logo.style.width='150px';
					me._logo.style.height='95px';
					skin.updateSize(me._logo);
				}
			}
		}
		me._logo.logicBlock_size();
		me._logo.logicBlock_scaling = function() {
			var newLogicStateScaling;
			if (
				((me.elementMouseOver['logo'] == true))
			)
			{
				newLogicStateScaling = 0;
			}
			else {
				newLogicStateScaling = -1;
			}
			if (me._logo.ggCurrentLogicStateScaling != newLogicStateScaling) {
				me._logo.ggCurrentLogicStateScaling = newLogicStateScaling;
				me._logo.style.transition='width 0s, height 0s, transform 500ms ease 0ms';
				if (me._logo.ggCurrentLogicStateScaling == 0) {
					me._logo.ggParameter.sx = 1.1;
					me._logo.ggParameter.sy = 1.1;
					me._logo.style.transform=parameterToTransform(me._logo.ggParameter);
					setTimeout(function() {skin.updateSize(me._logo);}, 550);
				}
				else {
					me._logo.ggParameter.sx = 1;
					me._logo.ggParameter.sy = 1;
					me._logo.style.transform=parameterToTransform(me._logo.ggParameter);
					setTimeout(function() {skin.updateSize(me._logo);}, 550);
				}
			}
		}
		me._logo.logicBlock_scaling();
		me._logo.logicBlock_visible = function() {
			var newLogicStateVisible;
			if (
				((player.getVariableValue('logo_img') == "logo150.png"))
			)
			{
				newLogicStateVisible = 0;
			}
			else {
				newLogicStateVisible = -1;
			}
			if (me._logo.ggCurrentLogicStateVisible != newLogicStateVisible) {
				me._logo.ggCurrentLogicStateVisible = newLogicStateVisible;
				me._logo.style.transition='width 0s, height 0s, transform 500ms ease 0ms';
				if (me._logo.ggCurrentLogicStateVisible == 0) {
					me._logo.style.visibility=(Number(me._logo.style.opacity)>0||!me._logo.style.opacity)?'inherit':'hidden';
					me._logo.ggSubElement.src=me._logo.ggText;
					me._logo.ggVisible=true;
				}
				else {
					me._logo.style.visibility="hidden";
					me._logo.ggSubElement.src='';
					me._logo.ggVisible=false;
				}
			}
		}
		me._logo.logicBlock_visible();
		me._logo.onclick=function (e) {
			player.openUrl("https:\/\/"+player.getVariableValue('web_site', me.hotspot ? me.hotspot.id : (player.hotspot ? player.hotspot.id : '')),"_blank");
		}
		me._logo.onmouseenter=function (e) {
			me.elementMouseOver['logo']=true;
			me._logo.logicBlock_scaling();
		}
		me._logo.onmouseleave=function (e) {
			me.elementMouseOver['logo']=false;
			me._logo.logicBlock_scaling();
		}
		me._logo.ggUpdatePosition=function (useTransition) {
			var parentWidth = me._logo.clientWidth;
			var parentHeight = me._logo.clientHeight;
			var img = me._logo__img;
			var aspectRatioDiv = me._logo.clientWidth / me._logo.clientHeight;
			var aspectRatioImg = img.naturalWidth / img.naturalHeight;
			if (img.naturalWidth < parentWidth) parentWidth = img.naturalWidth;
			if (img.naturalHeight < parentHeight) parentHeight = img.naturalHeight;
			var currentWidth,currentHeight;
			if (aspectRatioDiv > aspectRatioImg) {
				currentHeight = parentHeight;
				currentWidth = Math.round(parentHeight * aspectRatioImg);
				img.style.width='';
				img.style.height=parentHeight + 'px';
			} else {
				currentWidth = parentWidth;
				currentHeight = Math.round(parentWidth / aspectRatioImg);
				img.style.width=parentWidth + 'px';
				img.style.height='';
			};
			if (!me._logo.ggScrollbars || currentWidth < me._logo.clientWidth) {
				img.style.right='';
				img.style.left='0px';
			} else {
				img.style.right='';
				img.style.left='0px';
				img.style.marginLeft='0px';
			}
			if (!me._logo.ggScrollbars || currentHeight < me._logo.clientHeight) {
				img.style.bottom='';
				img.style.top='0px';
			} else {
				img.style.bottom='';
				img.style.top='0px';
				img.style.marginTop='0px';
			}
		}
		me.divSkin.appendChild(me._logo);
		me.__6fullscreen.logicBlock_position();
		me.__6fullscreen.logicBlock_scaling();
		me.__6fullscreen.logicBlock_backgroundcolor();
		me.elementMouseOver['_6fullscreen']=false;
		me._fullscreenexit.style.transition='none';
		me._fullscreenexit.style.visibility='hidden';
		me._fullscreenexit.ggVisible=false;
		me._solmenu.logicBlock_position();
		me._solmenu.logicBlock_visible();
		me._image_10.logicBlock_angle();
		me._image_1.logicBlock_angle();
		me._tiefkhl_frische.logicBlock_scaling();
		me.elementMouseOver['tiefkhl_frische']=false;
		me._obst_gemse.logicBlock_scaling();
		me.elementMouseOver['obst_gemse']=false;
		me._kosmetik.logicBlock_scaling();
		me.elementMouseOver['kosmetik']=false;
		me._fleischwaren.logicBlock_scaling();
		me.elementMouseOver['fleischwaren']=false;
		me._weine_spirituosen.logicBlock_scaling();
		me.elementMouseOver['weine_spirituosen']=false;
		me._sosyalmedya.logicBlock_position();
		me._sosyalmedya.logicBlock_visible();
		me._sosyalmedyabuton.logicBlock_backgroundcolor();
		me.elementMouseOver['sosyalmedyabuton']=false;
		me._svg_7.logicBlock_scaling();
		me.elementMouseOver['svg_7']=false;
		me._svg_5.logicBlock_scaling();
		me.elementMouseOver['svg_5']=false;
		me._instagram.logicBlock_scaling();
		me.elementMouseOver['instagram']=false;
		me._infobilgileri.logicBlock_position();
		me._infobilgileri.logicBlock_visible();
		me._infokapat.logicBlock_backgroundcolor();
		me.elementMouseOver['infokapat']=false;
		me._zoomin0.logicBlock_scaling();
		me.elementMouseOver['zoomin0']=false;
		me._telefon.logicBlock_text();
		me._logo2.logicBlock_scaling();
		me._logo2.logicBlock_visible();
		me.elementMouseOver['logo2']=false;
		me._alt_men.logicBlock_position();
		me._thumbnail_menu.logicBlock_alpha();
		me.__5.logicBlock_backgroundcolor();
		me.elementMouseOver['_5']=false;
		me._button_image_right.logicBlock_scaling();
		me.elementMouseOver['button_image_right']=false;
		me.__4.logicBlock_backgroundcolor();
		me.elementMouseOver['_4']=false;
		me._button_image_left.logicBlock_scaling();
		me.elementMouseOver['button_image_left']=false;
		me._resim.logicBlock_backgroundcolor();
		me.elementMouseOver['resim']=false;
		me._albm.logicBlock_scaling();
		me.elementMouseOver['albm']=false;
		me.__2.logicBlock_backgroundcolor();
		me.elementMouseOver['_2']=false;
		me._zoomout.logicBlock_scaling();
		me.elementMouseOver['zoomout']=false;
		me.__1.logicBlock_backgroundcolor();
		me.elementMouseOver['_1']=false;
		me._zoomin.logicBlock_scaling();
		me.elementMouseOver['zoomin']=false;
		me._audio2.logicBlock_position();
		me._audio2.logicBlock_scaling();
		me._audio2.logicBlock_backgroundcolor();
		me.elementMouseOver['audio2']=false;
		me._audio.logicBlock_position();
		me._audio.logicBlock_scaling();
		me._audio.logicBlock_backgroundcolor();
		me.elementMouseOver['audio']=false;
		me._logo.logicBlock_size();
		me._logo.logicBlock_scaling();
		me._logo.logicBlock_visible();
		me.elementMouseOver['logo']=false;
		player.addListener('activehotspotchanged', function(event) {
			for(var i = 0; i < me._thumbnail_cloner.ggInstances.length; i++) {
				me._thumbnail_cloner.ggInstances[i].ggEvent_activehotspotchanged(event);
			}
		});
		player.addListener('changenode', function(event) {
			for(var i = 0; i < me._thumbnail_cloner.ggInstances.length; i++) {
				me._thumbnail_cloner.ggInstances[i].ggEvent_changenode(event);
			}
			if (hotspotTemplates.hasOwnProperty('ht_node')) {
				for(var i = 0; i < hotspotTemplates['ht_node'].length; i++) {
					hotspotTemplates['ht_node'][i].ggEvent_changenode();
				}
			}
			me._solmenu.logicBlock_position();
			me._solmenu.logicBlock_visible();
			me._image_10.logicBlock_angle();
			me._image_1.logicBlock_angle();
			me._sosyalmedya.logicBlock_position();
			me._sosyalmedya.logicBlock_visible();
			me._infobilgileri.logicBlock_position();
			me._infobilgileri.logicBlock_visible();
			me._telefon.logicBlock_text();
			me._logo2.logicBlock_visible();
			me._alt_men.logicBlock_position();
			me._thumbnail_menu.logicBlock_alpha();
			me._thumbnail_cloner.ggUpdateConditionNodeChange();
			me._logo.logicBlock_size();
			me._logo.logicBlock_visible();
		});
		player.addListener('changevisitednodes', function(event) {
			for(var i = 0; i < me._thumbnail_cloner.ggInstances.length; i++) {
				me._thumbnail_cloner.ggInstances[i].ggEvent_changevisitednodes(event);
			}
			if (hotspotTemplates.hasOwnProperty('ht_node')) {
				for(var i = 0; i < hotspotTemplates['ht_node'].length; i++) {
					hotspotTemplates['ht_node'][i].ggEvent_changevisitednodes();
				}
			}
		});
		player.addListener('configloaded', function(event) {
			for(var i = 0; i < me._thumbnail_cloner.ggInstances.length; i++) {
				me._thumbnail_cloner.ggInstances[i].ggEvent_configloaded(event);
			}
			if (hotspotTemplates.hasOwnProperty('ht_node')) {
				for(var i = 0; i < hotspotTemplates['ht_node'].length; i++) {
					hotspotTemplates['ht_node'][i].ggEvent_configloaded();
				}
			}
			me._solmenu.logicBlock_position();
			me._solmenu.logicBlock_visible();
			me._image_10.logicBlock_angle();
			me._image_1.logicBlock_angle();
			me._sosyalmedya.logicBlock_position();
			me._sosyalmedya.logicBlock_visible();
			me._infobilgileri.logicBlock_position();
			me._infobilgileri.logicBlock_visible();
			me._telefon.logicBlock_text();
			me._logo2.logicBlock_visible();
			me._alt_men.logicBlock_position();
			me._thumbnail_menu.ggUpdatePosition();
			me._thumbnail_menu.logicBlock_alpha();
			me._logo.logicBlock_size();
			me._logo.logicBlock_visible();
		});
		player.addListener('sizechanged', function(event) {
			me.__6fullscreen.logicBlock_position();
			me._telefon.logicBlock_text();
			me._thumbnail_menu.logicBlock_alpha();
			me._audio2.logicBlock_position();
			me._audio.logicBlock_position();
		});
		player.addListener('varchanged_Sosyalmedya', function(event) {
			me._sosyalmedya.logicBlock_position();
		});
		player.addListener('varchanged_altmenu', function(event) {
			me._alt_men.logicBlock_position();
		});
		player.addListener('varchanged_ht_ani', function(event) {
			if (hotspotTemplates.hasOwnProperty('ht_node')) {
				for(var i = 0; i < hotspotTemplates['ht_node'].length; i++) {
					hotspotTemplates['ht_node'][i].ggEvent_varchanged_ht_ani();
				}
			}
		});
		player.addListener('varchanged_ht_node_var', function(event) {
			if (hotspotTemplates.hasOwnProperty('ht_node')) {
				for(var i = 0; i < hotspotTemplates['ht_node'].length; i++) {
					hotspotTemplates['ht_node'][i].ggEvent_varchanged_ht_node_var();
				}
			}
		});
		player.addListener('varchanged_info', function(event) {
			me._sosyalmedya.logicBlock_visible();
			me._infobilgileri.logicBlock_visible();
		});
		player.addListener('varchanged_infoklasor', function(event) {
			me._infobilgileri.logicBlock_position();
		});
		player.addListener('varchanged_logo_img', function(event) {
			me._logo2.logicBlock_visible();
			me._logo.logicBlock_size();
			me._logo.logicBlock_visible();
		});
		player.addListener('varchanged_solmenu', function(event) {
			me._solmenu.logicBlock_visible();
			me._image_10.logicBlock_angle();
			me._image_1.logicBlock_angle();
		});
		player.addListener('varchanged_solmenuklasor', function(event) {
			me._solmenu.logicBlock_position();
		});
		player.addListener('viewerinit', function(event) {
			me._thumbnail_cloner.ggUpdate();
		});
	};
	function SkinCloner_thumbnail_cloner_Class(nodeId, parentScope, ggParent, parameter) {
		var me=this;
		var hs='';
		me.parentScope=parentScope;
		me.ggParent=ggParent;
		me.findElements=skin.findElements;
		me.ggIndex=parameter.index;
		me.ggNodeId=nodeId;
		me.ggTitle=parameter.title;
		me.ggUserdata=skin.player.getNodeUserdata(me.ggNodeId);
		me.ggUserdata.nodeid=me.ggNodeId;
		me.elementMouseDown={};
		me.elementMouseOver={};
			me.__div=document.createElement('div');
			me.__div.setAttribute('style','visibility: inherit; overflow: visible;');
			me.__div.style.position='absolute';
			me.__div.style.left=parameter.left;
			me.__div.style.top=parameter.top;
			me.__div.style.width='';
			me.__div.style.height='';
			me.__div.style.width=parameter.width;
			me.__div.style.height=parameter.height;
			me.__div.ggIsActive = function() {
				return player.getCurrentNode()==me.ggNodeId;
			}
			me.__div.ggElementNodeId=function() {
				return me.ggNodeId;
			}
		el=me._thumbnail_nodeimage=document.createElement('div');
		el.isDragging = function() {
			let scrollerParent = me._thumbnail_nodeimage;
			while ((scrollerParent = scrollerParent.parentNode) != null) {
				if (scrollerParent.hasOwnProperty('ggIsDragging') && scrollerParent.ggIsDragging == true) return true;
			}
			return false;
		}
		els=me._thumbnail_nodeimage__img=document.createElement('img');
		els.className='ggskin ggskin_nodeimage';
		if (nodeId) els.setAttribute('src',basePath + "images/thumbnail_nodeimage_" + nodeId + ".jpg");
		el.ggNodeId=nodeId;
		hs ='';
		hs += 'position: absolute;top: 0px;left: 0px;width: 100%;height: 100%;-webkit-user-drag:none;pointer-events:none;;';
		els.setAttribute('style', hs);
		els.className='ggskin ggskin_nodeimage';
		els['ondragstart']=function() { return false; };
		el.appendChild(els);
		el.ggSubElement = els;
		el.ggId="thumbnail_nodeImage";
		el.ggDx=-2;
		el.ggDy=5;
		el.ggParameter={ rx:0,ry:0,a:0,sx:0.62,sy:0.58,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_nodeimage ";
		el.ggType='nodeimage';
		hs ='';
		hs+='cursor : pointer;';
		hs+='height : 140px;';
		hs+='left : calc(50% - ((222px + 0px) / 2) - 2px);';
		hs+='position : absolute;';
		hs+='top : calc(50% - ((140px + 0px) / 2) + 5px);';
		hs+='visibility : inherit;';
		hs+='width : 222px;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		el.style.transform=parameterToTransform(el.ggParameter);
		me._thumbnail_nodeimage.ggIsActive=function() {
			return player.getCurrentNode()==this.ggElementNodeId();
		}
		el.ggElementNodeId=function() {
			return this.ggNodeId;
		}
		me._thumbnail_nodeimage.ggUpdatePosition=function (useTransition) {
		}
		me.__div.appendChild(me._thumbnail_nodeimage);
		el=me._thumbnail_active=document.createElement('div');
		el.isDragging = function() {
			let scrollerParent = me._thumbnail_active;
			while ((scrollerParent = scrollerParent.parentNode) != null) {
				if (scrollerParent.hasOwnProperty('ggIsDragging') && scrollerParent.ggIsDragging == true) return true;
			}
			return false;
		}
		el.ggId="thumbnail_active";
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_rectangle ";
		el.ggType='rectangle';
		hs ='';
		hs+=cssPrefix + 'background-clip : padding-box;';
		hs+='background-clip : padding-box;';
		hs+='border : 3px solid rgba(0,0,0,0.313726);';
		hs+='cursor : pointer;';
		hs+='height : 80px;';
		hs+='left : 0px;';
		hs+='position : absolute;';
		hs+='top : 0px;';
		hs+='visibility : inherit;';
		hs+='width : 140px;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me._thumbnail_active.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._thumbnail_active.logicBlock_bordercolor = function() {
			var newLogicStateBorderColor;
			if (
				((me._thumbnail_active.ggIsActive() == true))
			)
			{
				newLogicStateBorderColor = 0;
			}
			else if (
				((me.elementMouseOver['thumbnail_active'] == true))
			)
			{
				newLogicStateBorderColor = 1;
			}
			else {
				newLogicStateBorderColor = -1;
			}
			if (me._thumbnail_active.ggCurrentLogicStateBorderColor != newLogicStateBorderColor) {
				me._thumbnail_active.ggCurrentLogicStateBorderColor = newLogicStateBorderColor;
				me._thumbnail_active.style.transition='border-color 0s';
				if (me._thumbnail_active.ggCurrentLogicStateBorderColor == 0) {
					me._thumbnail_active.style.borderColor="rgba(255,255,255,1)";
				}
				else if (me._thumbnail_active.ggCurrentLogicStateBorderColor == 1) {
					me._thumbnail_active.style.borderColor="rgba(255,255,255,1)";
				}
				else {
					me._thumbnail_active.style.borderColor="rgba(0,0,0,0.313726)";
				}
			}
		}
		me._thumbnail_active.logicBlock_bordercolor();
		me._thumbnail_active.onclick=function (e) {
			if (me._thumbnail_active.isDragging()) return;
			if (
				(
					((me._thumbnail_active.ggIsActive() == false))
				)
			) {
				player.openNext("{"+me.ggNodeId+"}","");
			}
		}
		me._thumbnail_active.onmouseenter=function (e) {
			me.elementMouseOver['thumbnail_active']=true;
			me._checkmark_tick.logicBlock_alpha();
			me._thumbnail_active.logicBlock_bordercolor();
		}
		me._thumbnail_active.onmouseleave=function (e) {
			me.elementMouseOver['thumbnail_active']=false;
			me._checkmark_tick.logicBlock_alpha();
			me._thumbnail_active.logicBlock_bordercolor();
		}
		me._thumbnail_active.ggUpdatePosition=function (useTransition) {
		}
		el=me._checkmark_tick=document.createElement('div');
		el.isDragging = function() {
			let scrollerParent = me._checkmark_tick;
			while ((scrollerParent = scrollerParent.parentNode) != null) {
				if (scrollerParent.hasOwnProperty('ggIsDragging') && scrollerParent.ggIsDragging == true) return true;
			}
			return false;
		}
		els=me._checkmark_tick__img=document.createElement('img');
		els.className='ggskin ggskin_svg';
		hs='data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0nMS4wJyBlbmNvZGluZz0ndXRmLTgnPz4KPCFET0NUWVBFIHN2ZyBQVUJMSUMgJy0vL1czQy8vRFREIFNWRyAxLjEvL0VOJyAnaHR0cDovL3d3dy53My5vcmcvR3JhcGhpY3MvU1ZHLzEuMS9EVEQvc3ZnMTEuZHRkJz4KPCEtLSBHZW5lcmF0b3I6IEFkb2JlIElsbHVzdHJhdG9yIDE2LjAuMCwgU1ZHIEV4cG9ydCBQbHVnLUluIC4gU1ZHIFZlcnNpb246IDYuMDAgQnVpbGQgMCkgIC0tPgo8c3ZnIGhlaWdodD0iMzJweCIgeT0iMHB4IiB2ZXJzaW9uPSIxLjEiIHhtbG5zOmdyYXBoPSJodHRwOi8vbnMuYWRvYmUuY29tL0dyYXBocy8xLjAvIiB2aWV3Qm94PSItMzcyMiAtMj'+
			'YwNiAzMiAzMiIgd2lkdGg9IjMycHgiIGVuYWJsZS1iYWNrZ3JvdW5kPSJuZXcgLTM3MjIgLTI2MDYgMzIgMzIiIHhtbG5zOmk9Imh0dHA6Ly9ucy5hZG9iZS5jb20vQWRvYmVJbGx1c3RyYXRvci8xMC4wLyIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxuczp4PSJodHRwOi8vbnMuYWRvYmUuY29tL0V4dGVuc2liaWxpdHkvMS4wLyIgeG1sbnM6YT0iaHR0cDovL25zLmFkb2JlLmNvbS9BZG9iZVNWR1ZpZXdlckV4dGVuc2lvbnMvMy4wLyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjBweCI+CiA8'+
			'ZyBpZD0iTGF5ZXJfMSIvPgogPGcgaWQ9IkViZW5lXzEiLz4KIDxnIGlkPSJMYXllcl8yIj4KICA8Zz4KICAgPGc+CiAgICA8cGF0aCBkPSJNLTM2OTUuNDczLTI1OTguMTQ2Yy0wLjUxOS0wLjUxOS0xLjM2MS0wLjUxOS0xLjg3OSwwbC04Ljc4Nyw4Ljc4N2wtMi4yOTEtMi4yNDMgICAgIGMtMC41MjUtMC41MTMtMS4zNjYtMC41MDQtMS44OCwwLjAyYy0wLjUxMywwLjUyNS0wLjUwNCwxLjM2NywwLjAyMSwxLjg4bDMuMjMsMy4xNjNjMC4yNTksMC4yNTMsMC41OTQsMC4zNzksMC45MywwLjM3OSAgICAgYzAuMzQsMCwwLjY4LTAuMTMsMC45NC0wLjM5bDkuNzE3LTkuNzE3Qy0zNjk0Ljk1NC0yNT'+
			'k2Ljc4NS0zNjk0Ljk1NC0yNTk3LjYyNi0zNjk1LjQ3My0yNTk4LjE0NnoiIGZpbGw9IiNGRkZGRkYiLz4KICAgIDxwYXRoIGQ9Ik0tMzY5OS45Ni0yNTgzLjgzN2gtMTIuMzI1di0xMi4zMjZoMTEuODIxbDIuMjUyLTIuMjUyYy0wLjE2Ni0wLjA4Ni0wLjM1Mi0wLjE0MS0wLjU1Mi0wLjE0MWgtMTQuNzE4ICAgICBjLTAuNjYxLDAtMS4xOTYsMC41MzYtMS4xOTYsMS4xOTZ2MTQuNzE5YzAsMC42NiwwLjUzNSwxLjE5NiwxLjE5NiwxLjE5NmgxNC43MThjMC42NjEsMCwxLjE5Ny0wLjUzNiwxLjE5Ny0xLjE5NnYtMTAuNDAzICAgICBsLTIuMzkzLDIuMzkzVi0yNTgzLjgzN3oiIGZpbGw9IiNGRkZG'+
			'RkYiLz4KICAgPC9nPgogICA8ZyBhOmFkb2JlLWJsZW5kaW5nLW1vZGU9Im11bHRpcGx5IiBvcGFjaXR5PSIwLjQiPgogICAgPHBhdGggc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgYTphZG9iZS1ibGVuZGluZy1tb2RlPSJub3JtYWwiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgZD0iICAgICBNLTM2OTUuNDczLTI1OTguMTQ2Yy0wLjUxOS0wLjUxOS0xLjM2MS0wLjUxOS0xLjg3OSwwbC04Ljc4Nyw4Ljc4N2wtMi4yOTEtMi4yNDNjLTAuNTI1LTAuNTEzLTEuMzY2LTAuNTA0LTEuODgsMC4wMiAgICAgYy0wLjUxMywwLjUyNS0wLjUwNCwxLjM2NywwLjAyMSwxLjg4bDMuMjMsMy4xNjNjMC4yNTksMC'+
			'4yNTMsMC41OTQsMC4zNzksMC45MywwLjM3OWMwLjM0LDAsMC42OC0wLjEzLDAuOTQtMC4zOWw5LjcxNy05LjcxNyAgICAgQy0zNjk0Ljk1NC0yNTk2Ljc4NS0zNjk0Ljk1NC0yNTk3LjYyNi0zNjk1LjQ3My0yNTk4LjE0NnoiIHN0cm9rZS13aWR0aD0iMS41IiBzdHJva2U9IiMxQTE3MUIiIGZpbGw9Im5vbmUiLz4KICAgIDxwYXRoIHN0cm9rZS1saW5lam9pbj0icm91bmQiIGE6YWRvYmUtYmxlbmRpbmctbW9kZT0ibm9ybWFsIiBzdHJva2UtbGluZWNhcD0icm91bmQiIGQ9IiAgICAgTS0zNjk5Ljk2LTI1ODMuODM3aC0xMi4zMjV2LTEyLjMyNmgxMS44MjFsMi4yNTItMi4yNTJjLTAuMTY2LTAu'+
			'MDg2LTAuMzUyLTAuMTQxLTAuNTUyLTAuMTQxaC0xNC43MTggICAgIGMtMC42NjEsMC0xLjE5NiwwLjUzNi0xLjE5NiwxLjE5NnYxNC43MTljMCwwLjY2LDAuNTM1LDEuMTk2LDEuMTk2LDEuMTk2aDE0LjcxOGMwLjY2MSwwLDEuMTk3LTAuNTM2LDEuMTk3LTEuMTk2di0xMC40MDMgICAgIGwtMi4zOTMsMi4zOTNWLTI1ODMuODM3eiIgc3Ryb2tlLXdpZHRoPSIxLjUiIHN0cm9rZT0iIzFBMTcxQiIgZmlsbD0ibm9uZSIvPgogICA8L2c+CiAgIDxnPgogICAgPHBhdGggZD0iTS0zNjk1LjQ3My0yNTk4LjE0NmMtMC41MTktMC41MTktMS4zNjEtMC41MTktMS44NzksMGwtOC43ODcsOC43ODdsLTIuMj'+
			'kxLTIuMjQzICAgICBjLTAuNTI1LTAuNTEzLTEuMzY2LTAuNTA0LTEuODgsMC4wMmMtMC41MTMsMC41MjUtMC41MDQsMS4zNjcsMC4wMjEsMS44OGwzLjIzLDMuMTYzYzAuMjU5LDAuMjUzLDAuNTk0LDAuMzc5LDAuOTMsMC4zNzkgICAgIGMwLjM0LDAsMC42OC0wLjEzLDAuOTQtMC4zOWw5LjcxNy05LjcxN0MtMzY5NC45NTQtMjU5Ni43ODUtMzY5NC45NTQtMjU5Ny42MjYtMzY5NS40NzMtMjU5OC4xNDZ6IiBmaWxsPSIjRkZGRkZGIi8+CiAgICA8cGF0aCBkPSJNLTM2OTkuOTYtMjU4My44MzdoLTEyLjMyNXYtMTIuMzI2aDExLjgyMWwyLjI1Mi0yLjI1MmMtMC4xNjYtMC4wODYtMC4zNTItMC4x'+
			'NDEtMC41NTItMC4xNDFoLTE0LjcxOCAgICAgYy0wLjY2MSwwLTEuMTk2LDAuNTM2LTEuMTk2LDEuMTk2djE0LjcxOWMwLDAuNjYsMC41MzUsMS4xOTYsMS4xOTYsMS4xOTZoMTQuNzE4YzAuNjYxLDAsMS4xOTctMC41MzYsMS4xOTctMS4xOTZ2LTEwLjQwMyAgICAgbC0yLjM5MywyLjM5M1YtMjU4My44Mzd6IiBmaWxsPSIjRkZGRkZGIi8+CiAgIDwvZz4KICAgPGc+CiAgICA8cGF0aCBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2UtbGluZWNhcD0icm91bmQiIGQ9Ik0tMzY5NS40NzMtMjU5OC4xNDYgICAgIGMtMC41MTktMC41MTktMS4zNjEtMC41MTktMS44NzksMGwtOC43ODcsOC43OD'+
			'dsLTIuMjkxLTIuMjQzYy0wLjUyNS0wLjUxMy0xLjM2Ni0wLjUwNC0xLjg4LDAuMDIgICAgIGMtMC41MTMsMC41MjUtMC41MDQsMS4zNjcsMC4wMjEsMS44OGwzLjIzLDMuMTYzYzAuMjU5LDAuMjUzLDAuNTk0LDAuMzc5LDAuOTMsMC4zNzljMC4zNCwwLDAuNjgtMC4xMywwLjk0LTAuMzlsOS43MTctOS43MTcgICAgIEMtMzY5NC45NTQtMjU5Ni43ODUtMzY5NC45NTQtMjU5Ny42MjYtMzY5NS40NzMtMjU5OC4xNDZ6IiBzdHJva2Utd2lkdGg9IjAuMiIgc3Ryb2tlPSIjMUExNzFCIiBmaWxsPSJub25lIi8+CiAgICA8cGF0aCBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2UtbGluZWNhcD0i'+
			'cm91bmQiIGQ9Ik0tMzY5OS45Ni0yNTgzLjgzNyAgICAgaC0xMi4zMjV2LTEyLjMyNmgxMS44MjFsMi4yNTItMi4yNTJjLTAuMTY2LTAuMDg2LTAuMzUyLTAuMTQxLTAuNTUyLTAuMTQxaC0xNC43MThjLTAuNjYxLDAtMS4xOTYsMC41MzYtMS4xOTYsMS4xOTZ2MTQuNzE5ICAgICBjMCwwLjY2LDAuNTM1LDEuMTk2LDEuMTk2LDEuMTk2aDE0LjcxOGMwLjY2MSwwLDEuMTk3LTAuNTM2LDEuMTk3LTEuMTk2di0xMC40MDNsLTIuMzkzLDIuMzkzVi0yNTgzLjgzN3oiIHN0cm9rZS13aWR0aD0iMC4yIiBzdHJva2U9IiMxQTE3MUIiIGZpbGw9Im5vbmUiLz4KICAgPC9nPgogIDwvZz4KIDwvZz4KPC9zdm'+
			'c+Cg==';
		me._checkmark_tick__img.setAttribute('src',hs);
		hs ='';
		hs += 'position: absolute;top: 0px;left: 0px;width: 100%;height: 100%;-webkit-user-drag:none;pointer-events:none;;';
		els.setAttribute('style', hs);
		els['ondragstart']=function() { return false; };
		el.appendChild(els);
		el.ggSubElement = els;
		el.ggId="checkmark_tick";
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=false;
		el.className="ggskin ggskin_svg ";
		el.ggType='svg';
		hs ='';
		hs+='height : 24px;';
		hs+='position : absolute;';
		hs+='right : -4px;';
		hs+='top : -5px;';
		hs+='visibility : hidden;';
		hs+='width : 24px;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me._checkmark_tick.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return player.getCurrentNode();
		}
		me._checkmark_tick.logicBlock_visible = function() {
			var newLogicStateVisible;
			if (
				((player.nodeVisited(me._checkmark_tick.ggElementNodeId()) == true)) || 
				((me._checkmark_tick.ggIsActive() == true))
			)
			{
				newLogicStateVisible = 0;
			}
			else {
				newLogicStateVisible = -1;
			}
			if (me._checkmark_tick.ggCurrentLogicStateVisible != newLogicStateVisible) {
				me._checkmark_tick.ggCurrentLogicStateVisible = newLogicStateVisible;
				me._checkmark_tick.style.transition='opacity 500ms ease 0ms';
				if (me._checkmark_tick.ggCurrentLogicStateVisible == 0) {
					me._checkmark_tick.style.visibility=(Number(me._checkmark_tick.style.opacity)>0||!me._checkmark_tick.style.opacity)?'inherit':'hidden';
					me._checkmark_tick.ggVisible=true;
				}
				else {
					me._checkmark_tick.style.visibility="hidden";
					me._checkmark_tick.ggVisible=false;
				}
			}
		}
		me._checkmark_tick.logicBlock_visible();
		me._checkmark_tick.logicBlock_alpha = function() {
			var newLogicStateAlpha;
			if (
				((me.elementMouseOver['thumbnail_active'] == true)) && 
				((player._(me.ggUserdata.title) != ""))
			)
			{
				newLogicStateAlpha = 0;
			}
			else {
				newLogicStateAlpha = -1;
			}
			if (me._checkmark_tick.ggCurrentLogicStateAlpha != newLogicStateAlpha) {
				me._checkmark_tick.ggCurrentLogicStateAlpha = newLogicStateAlpha;
				me._checkmark_tick.style.transition='opacity 500ms ease 0ms';
				if (me._checkmark_tick.ggCurrentLogicStateAlpha == 0) {
					setTimeout(function() { if (me._checkmark_tick.style.opacity == 0.0) { me._checkmark_tick.style.visibility="hidden"; } }, 505);
					me._checkmark_tick.style.opacity=0;
				}
				else {
					me._checkmark_tick.style.visibility=me._checkmark_tick.ggVisible?'inherit':'hidden';
					me._checkmark_tick.style.opacity=1;
				}
			}
		}
		me._checkmark_tick.logicBlock_alpha();
		me._checkmark_tick.ggUpdatePosition=function (useTransition) {
		}
		me._thumbnail_active.appendChild(me._checkmark_tick);
		me.__div.appendChild(me._thumbnail_active);
		me._thumbnail_active.logicBlock_bordercolor();
		me.elementMouseOver['thumbnail_active']=false;
		me._checkmark_tick.logicBlock_visible();
		me._checkmark_tick.logicBlock_alpha();
			me.ggEvent_activehotspotchanged=function(event) {
				me._checkmark_tick.logicBlock_alpha();
			};
			me.ggEvent_changenode=function(event) {
				me._thumbnail_active.logicBlock_bordercolor();
				me._checkmark_tick.logicBlock_visible();
				me._checkmark_tick.logicBlock_visible();
				me._checkmark_tick.logicBlock_alpha();
			};
			me.ggEvent_changevisitednodes=function(event) {
				me._checkmark_tick.logicBlock_visible();
			};
			me.ggEvent_configloaded=function(event) {
				me._checkmark_tick.logicBlock_alpha();
			};
	};
	function SkinHotspotClass_ht_node(parentScope,hotspot) {
		var me=this;
		var flag=false;
		var hs='';
		me.parentScope=parentScope;
		me.hotspot=hotspot;
		var nodeId=String(hotspot.url);
		nodeId=(nodeId.charAt(0)=='{')?nodeId.substr(1, nodeId.length - 2):''; // }
		me.ggUserdata=skin.player.getNodeUserdata(nodeId);
		me.elementMouseDown={};
		me.elementMouseOver={};
		me.findElements=function(id,regex) {
			return skin.findElements(id,regex);
		}
		el=me._ht_node=document.createElement('div');
		el.ggId="ht_node";
		el.ggDx=0;
		el.ggDy=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_hotspot ";
		el.ggType='hotspot';
		hs ='';
		hs+='cursor : pointer;';
		hs+='height : 0px;';
		hs+='left : calc(50% - ((0px + 0px) / 2) + 0px);';
		hs+='position : absolute;';
		hs+='top : calc(50% - ((0px + 0px) / 2) + 0px);';
		hs+='visibility : inherit;';
		hs+='width : 0px;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me._ht_node.ggIsActive=function() {
			return player.getCurrentNode()==this.ggElementNodeId();
		}
		el.ggElementNodeId=function() {
			if (me.hotspot.url!='' && me.hotspot.url.charAt(0)=='{') { // }
				return me.hotspot.url.substr(1, me.hotspot.url.length - 2);
			} else {
				if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
					return this.parentNode.ggElementNodeId();
				} else {
					return player.getCurrentNode();
				}
			}
		}
		me._ht_node.onclick=function (e) {
			player.openNext(player._(me.hotspot.url),player._(me.hotspot.target));
			player.triggerEvent('hsproxyclick', {'id': me.hotspot.id, 'url': me.hotspot.url});
		}
		me._ht_node.ondblclick=function (e) {
			player.triggerEvent('hsproxydblclick', {'id': me.hotspot.id, 'url': me.hotspot.url});
		}
		me._ht_node.onmouseenter=function (e) {
			player.setActiveHotspot(me.hotspot);
			player.setVariableValue('ht_node_var', true);
			player.setVariableValue('Hotspotbasli', false);
			me.elementMouseOver['ht_node']=true;
			me._hedefarayuzu.logicBlock_visible();
			player.triggerEvent('hsproxyover', {'id': me.hotspot.id, 'url': me.hotspot.url});
		}
		me._ht_node.onmouseleave=function (e) {
			player.setActiveHotspot(null);
			player.setVariableValue('ht_node_var', false);
			player.setVariableValue('Hotspotbasli', true);
			me.elementMouseOver['ht_node']=false;
			me._hedefarayuzu.logicBlock_visible();
			player.triggerEvent('hsproxyout', {'id': me.hotspot.id, 'url': me.hotspot.url});
		}
		me._ht_node.ggUpdatePosition=function (useTransition) {
		}
		el=me._katmangidis=document.createElement('div');
		el.ggId="KATMAN-gidis";
		el.ggDx=0;
		el.ggDy=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_container ";
		el.ggType='container';
		hs ='';
		hs+='cursor : pointer;';
		hs+='height : 52px;';
		hs+='left : calc(50% - ((52px + 0px) / 2) + 0px);';
		hs+='position : absolute;';
		hs+='top : calc(50% - ((52px + 0px) / 2) + 0px);';
		hs+='visibility : inherit;';
		hs+='width : 52px;';
		hs+='pointer-events:none;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me._katmangidis.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return me.ggNodeId;
		}
		me._katmangidis.logicBlock_visible = function() {
			var newLogicStateVisible;
			if (
				((player.nodeVisited(me._katmangidis.ggElementNodeId()) == true))
			)
			{
				newLogicStateVisible = 0;
			}
			else {
				newLogicStateVisible = -1;
			}
			if (me._katmangidis.ggCurrentLogicStateVisible != newLogicStateVisible) {
				me._katmangidis.ggCurrentLogicStateVisible = newLogicStateVisible;
				me._katmangidis.style.transition='';
				if (me._katmangidis.ggCurrentLogicStateVisible == 0) {
					me._katmangidis.style.visibility=(Number(me._katmangidis.style.opacity)>0||!me._katmangidis.style.opacity)?'inherit':'hidden';
					me._katmangidis.ggVisible=true;
				}
				else {
					me._katmangidis.style.visibility=(Number(me._katmangidis.style.opacity)>0||!me._katmangidis.style.opacity)?'inherit':'hidden';
					me._katmangidis.ggVisible=true;
				}
			}
		}
		me._katmangidis.logicBlock_visible();
		me._katmangidis.ggUpdatePosition=function (useTransition) {
		}
		el=me._cembergri=document.createElement('div');
		el.ggId="CEMBER-GRI";
		el.ggDx=0;
		el.ggDy=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:0.4,sy:0.4,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_rectangle ";
		el.ggType='rectangle';
		hs ='';
		hs+='border : 4px solid #000000;';
		hs+='border-radius : 999px;';
		hs+='cursor : pointer;';
		hs+='height : 20px;';
		hs+='left : calc(50% - ((20px + 8px) / 2) + 0px);';
		hs+='position : absolute;';
		hs+='top : calc(50% - ((20px + 8px) / 2) + 0px);';
		hs+='visibility : inherit;';
		hs+='width : 20px;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		el.style.transform=parameterToTransform(el.ggParameter);
		me._cembergri.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return me.ggNodeId;
		}
		me._cembergri.logicBlock_scaling = function() {
			var newLogicStateScaling;
			if (
				((player.getVariableValue('ht_ani') == true))
			)
			{
				newLogicStateScaling = 0;
			}
			else {
				newLogicStateScaling = -1;
			}
			if (me._cembergri.ggCurrentLogicStateScaling != newLogicStateScaling) {
				me._cembergri.ggCurrentLogicStateScaling = newLogicStateScaling;
				me._cembergri.style.transition='transform 1000ms ease 0ms, opacity 1000ms ease 0ms';
				if (me._cembergri.ggCurrentLogicStateScaling == 0) {
					me._cembergri.ggParameter.sx = 1;
					me._cembergri.ggParameter.sy = 1;
					me._cembergri.style.transform=parameterToTransform(me._cembergri.ggParameter);
					setTimeout(function() {skin.updateSize(me._cembergri);}, 1050);
				}
				else {
					me._cembergri.ggParameter.sx = 0.4;
					me._cembergri.ggParameter.sy = 0.4;
					me._cembergri.style.transform=parameterToTransform(me._cembergri.ggParameter);
					setTimeout(function() {skin.updateSize(me._cembergri);}, 1050);
				}
			}
		}
		me._cembergri.logicBlock_scaling();
		me._cembergri.logicBlock_alpha = function() {
			var newLogicStateAlpha;
			if (
				((player.getVariableValue('ht_ani') == true))
			)
			{
				newLogicStateAlpha = 0;
			}
			else {
				newLogicStateAlpha = -1;
			}
			if (me._cembergri.ggCurrentLogicStateAlpha != newLogicStateAlpha) {
				me._cembergri.ggCurrentLogicStateAlpha = newLogicStateAlpha;
				me._cembergri.style.transition='transform 1000ms ease 0ms, opacity 1000ms ease 0ms';
				if (me._cembergri.ggCurrentLogicStateAlpha == 0) {
					setTimeout(function() { if (me._cembergri.style.opacity == 0.0) { me._cembergri.style.visibility="hidden"; } }, 1005);
					me._cembergri.style.opacity=0;
				}
				else {
					me._cembergri.style.visibility=me._cembergri.ggVisible?'inherit':'hidden';
					me._cembergri.style.opacity=1;
				}
			}
		}
		me._cembergri.logicBlock_alpha();
		me._cembergri.ggUpdatePosition=function (useTransition) {
		}
		me._katmangidis.appendChild(me._cembergri);
		el=me._cemberkirmizi=document.createElement('div');
		el.ggId="CEMBER-KIRMIZI";
		el.ggDx=0;
		el.ggDy=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:0.55,sy:0.55,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_rectangle ";
		el.ggType='rectangle';
		hs ='';
		hs+='border : 4px solid #ff0000;';
		hs+='border-radius : 999px;';
		hs+='cursor : pointer;';
		hs+='height : 30px;';
		hs+='left : calc(50% - ((30px + 8px) / 2) + 0px);';
		hs+='position : absolute;';
		hs+='top : calc(50% - ((30px + 8px) / 2) + 0px);';
		hs+='visibility : inherit;';
		hs+='width : 30px;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		el.style.transform=parameterToTransform(el.ggParameter);
		me._cemberkirmizi.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return me.ggNodeId;
		}
		me._cemberkirmizi.logicBlock_scaling = function() {
			var newLogicStateScaling;
			if (
				((player.getVariableValue('ht_ani') == true))
			)
			{
				newLogicStateScaling = 0;
			}
			else {
				newLogicStateScaling = -1;
			}
			if (me._cemberkirmizi.ggCurrentLogicStateScaling != newLogicStateScaling) {
				me._cemberkirmizi.ggCurrentLogicStateScaling = newLogicStateScaling;
				me._cemberkirmizi.style.transition='transform 1000ms ease 0ms, opacity 1000ms ease 0ms';
				if (me._cemberkirmizi.ggCurrentLogicStateScaling == 0) {
					me._cemberkirmizi.ggParameter.sx = 1;
					me._cemberkirmizi.ggParameter.sy = 1;
					me._cemberkirmizi.style.transform=parameterToTransform(me._cemberkirmizi.ggParameter);
					setTimeout(function() {skin.updateSize(me._cemberkirmizi);}, 1050);
				}
				else {
					me._cemberkirmizi.ggParameter.sx = 0.55;
					me._cemberkirmizi.ggParameter.sy = 0.55;
					me._cemberkirmizi.style.transform=parameterToTransform(me._cemberkirmizi.ggParameter);
					setTimeout(function() {skin.updateSize(me._cemberkirmizi);}, 1050);
				}
			}
		}
		me._cemberkirmizi.logicBlock_scaling();
		me._cemberkirmizi.logicBlock_alpha = function() {
			var newLogicStateAlpha;
			if (
				((player.getVariableValue('ht_ani') == true))
			)
			{
				newLogicStateAlpha = 0;
			}
			else {
				newLogicStateAlpha = -1;
			}
			if (me._cemberkirmizi.ggCurrentLogicStateAlpha != newLogicStateAlpha) {
				me._cemberkirmizi.ggCurrentLogicStateAlpha = newLogicStateAlpha;
				me._cemberkirmizi.style.transition='transform 1000ms ease 0ms, opacity 1000ms ease 0ms';
				if (me._cemberkirmizi.ggCurrentLogicStateAlpha == 0) {
					setTimeout(function() { if (me._cemberkirmizi.style.opacity == 0.0) { me._cemberkirmizi.style.visibility="hidden"; } }, 1005);
					me._cemberkirmizi.style.opacity=0;
				}
				else {
					me._cemberkirmizi.style.visibility=me._cemberkirmizi.ggVisible?'inherit':'hidden';
					me._cemberkirmizi.style.opacity=1;
				}
			}
		}
		me._cemberkirmizi.logicBlock_alpha();
		me._cemberkirmizi.ggUpdatePosition=function (useTransition) {
		}
		me._katmangidis.appendChild(me._cemberkirmizi);
		el=me._cemberbeyaz=document.createElement('div');
		el.ggId="CEMBER-BEYAZ";
		el.ggDx=0;
		el.ggDy=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:0.8,sy:0.8,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_rectangle ";
		el.ggType='rectangle';
		hs ='';
		hs+='border : 3px solid #ffffff;';
		hs+='border-radius : 999px;';
		hs+='cursor : pointer;';
		hs+='height : 40px;';
		hs+='left : calc(50% - ((40px + 6px) / 2) + 0px);';
		hs+='position : absolute;';
		hs+='top : calc(50% - ((40px + 6px) / 2) + 0px);';
		hs+='visibility : inherit;';
		hs+='width : 40px;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		el.style.transform=parameterToTransform(el.ggParameter);
		me._cemberbeyaz.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return me.ggNodeId;
		}
		me._cemberbeyaz.logicBlock_scaling = function() {
			var newLogicStateScaling;
			if (
				((player.getVariableValue('ht_ani') == true))
			)
			{
				newLogicStateScaling = 0;
			}
			else {
				newLogicStateScaling = -1;
			}
			if (me._cemberbeyaz.ggCurrentLogicStateScaling != newLogicStateScaling) {
				me._cemberbeyaz.ggCurrentLogicStateScaling = newLogicStateScaling;
				me._cemberbeyaz.style.transition='transform 1000ms ease 0ms, opacity 1000ms ease 0ms';
				if (me._cemberbeyaz.ggCurrentLogicStateScaling == 0) {
					me._cemberbeyaz.ggParameter.sx = 1;
					me._cemberbeyaz.ggParameter.sy = 1;
					me._cemberbeyaz.style.transform=parameterToTransform(me._cemberbeyaz.ggParameter);
					setTimeout(function() {skin.updateSize(me._cemberbeyaz);}, 1050);
				}
				else {
					me._cemberbeyaz.ggParameter.sx = 0.8;
					me._cemberbeyaz.ggParameter.sy = 0.8;
					me._cemberbeyaz.style.transform=parameterToTransform(me._cemberbeyaz.ggParameter);
					setTimeout(function() {skin.updateSize(me._cemberbeyaz);}, 1050);
				}
			}
		}
		me._cemberbeyaz.logicBlock_scaling();
		me._cemberbeyaz.logicBlock_alpha = function() {
			var newLogicStateAlpha;
			if (
				((player.getVariableValue('ht_ani') == true))
			)
			{
				newLogicStateAlpha = 0;
			}
			else {
				newLogicStateAlpha = -1;
			}
			if (me._cemberbeyaz.ggCurrentLogicStateAlpha != newLogicStateAlpha) {
				me._cemberbeyaz.ggCurrentLogicStateAlpha = newLogicStateAlpha;
				me._cemberbeyaz.style.transition='transform 1000ms ease 0ms, opacity 1000ms ease 0ms';
				if (me._cemberbeyaz.ggCurrentLogicStateAlpha == 0) {
					setTimeout(function() { if (me._cemberbeyaz.style.opacity == 0.0) { me._cemberbeyaz.style.visibility="hidden"; } }, 1005);
					me._cemberbeyaz.style.opacity=0;
				}
				else {
					me._cemberbeyaz.style.visibility=me._cemberbeyaz.ggVisible?'inherit':'hidden';
					me._cemberbeyaz.style.opacity=1;
				}
			}
		}
		me._cemberbeyaz.logicBlock_alpha();
		me._cemberbeyaz.ggUpdatePosition=function (useTransition) {
		}
		me._katmangidis.appendChild(me._cemberbeyaz);
		me._ht_node.appendChild(me._katmangidis);
		el=me._katmandonus=document.createElement('div');
		el.ggId="KATMAN-donus";
		el.ggDx=0;
		el.ggDy=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=false;
		el.className="ggskin ggskin_container ";
		el.ggType='container';
		hs ='';
		hs+='cursor : pointer;';
		hs+='height : 52px;';
		hs+='left : calc(50% - ((52px + 0px) / 2) + 0px);';
		hs+='position : absolute;';
		hs+='top : calc(50% - ((52px + 0px) / 2) + 0px);';
		hs+='visibility : hidden;';
		hs+='width : 52px;';
		hs+='pointer-events:none;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me._katmandonus.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return me.ggNodeId;
		}
		me._katmandonus.logicBlock_visible = function() {
			var newLogicStateVisible;
			if (
				((player.nodeVisited(me._katmandonus.ggElementNodeId()) == true))
			)
			{
				newLogicStateVisible = 0;
			}
			else {
				newLogicStateVisible = -1;
			}
			if (me._katmandonus.ggCurrentLogicStateVisible != newLogicStateVisible) {
				me._katmandonus.ggCurrentLogicStateVisible = newLogicStateVisible;
				me._katmandonus.style.transition='';
				if (me._katmandonus.ggCurrentLogicStateVisible == 0) {
					me._katmandonus.style.visibility="hidden";
					me._katmandonus.ggVisible=false;
				}
				else {
					me._katmandonus.style.visibility="hidden";
					me._katmandonus.ggVisible=false;
				}
			}
		}
		me._katmandonus.logicBlock_visible();
		me._katmandonus.ggUpdatePosition=function (useTransition) {
		}
		el=me._cembergri2v=document.createElement('div');
		el.ggId="CEMBER-GRI-2V";
		el.ggDx=0;
		el.ggDy=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:0.4,sy:0.4,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_rectangle ";
		el.ggType='rectangle';
		hs ='';
		hs+='border : 4px solid #008236;';
		hs+='border-radius : 999px;';
		hs+='cursor : pointer;';
		hs+='height : 20px;';
		hs+='left : calc(50% - ((20px + 8px) / 2) + 0px);';
		hs+='position : absolute;';
		hs+='top : calc(50% - ((20px + 8px) / 2) + 0px);';
		hs+='visibility : inherit;';
		hs+='width : 20px;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		el.style.transform=parameterToTransform(el.ggParameter);
		me._cembergri2v.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return me.ggNodeId;
		}
		me._cembergri2v.logicBlock_scaling = function() {
			var newLogicStateScaling;
			if (
				((player.getVariableValue('ht_ani') == true))
			)
			{
				newLogicStateScaling = 0;
			}
			else {
				newLogicStateScaling = -1;
			}
			if (me._cembergri2v.ggCurrentLogicStateScaling != newLogicStateScaling) {
				me._cembergri2v.ggCurrentLogicStateScaling = newLogicStateScaling;
				me._cembergri2v.style.transition='transform 1000ms ease 0ms, opacity 1000ms ease 0ms';
				if (me._cembergri2v.ggCurrentLogicStateScaling == 0) {
					me._cembergri2v.ggParameter.sx = 0.26;
					me._cembergri2v.ggParameter.sy = 0.26;
					me._cembergri2v.style.transform=parameterToTransform(me._cembergri2v.ggParameter);
					setTimeout(function() {skin.updateSize(me._cembergri2v);}, 1050);
				}
				else {
					me._cembergri2v.ggParameter.sx = 0.4;
					me._cembergri2v.ggParameter.sy = 0.4;
					me._cembergri2v.style.transform=parameterToTransform(me._cembergri2v.ggParameter);
					setTimeout(function() {skin.updateSize(me._cembergri2v);}, 1050);
				}
			}
		}
		me._cembergri2v.logicBlock_scaling();
		me._cembergri2v.logicBlock_alpha = function() {
			var newLogicStateAlpha;
			if (
				((player.getVariableValue('ht_ani') == true))
			)
			{
				newLogicStateAlpha = 0;
			}
			else {
				newLogicStateAlpha = -1;
			}
			if (me._cembergri2v.ggCurrentLogicStateAlpha != newLogicStateAlpha) {
				me._cembergri2v.ggCurrentLogicStateAlpha = newLogicStateAlpha;
				me._cembergri2v.style.transition='transform 1000ms ease 0ms, opacity 1000ms ease 0ms';
				if (me._cembergri2v.ggCurrentLogicStateAlpha == 0) {
					setTimeout(function() { if (me._cembergri2v.style.opacity == 0.0) { me._cembergri2v.style.visibility="hidden"; } }, 1005);
					me._cembergri2v.style.opacity=0;
				}
				else {
					me._cembergri2v.style.visibility=me._cembergri2v.ggVisible?'inherit':'hidden';
					me._cembergri2v.style.opacity=1;
				}
			}
		}
		me._cembergri2v.logicBlock_alpha();
		me._cembergri2v.ggUpdatePosition=function (useTransition) {
		}
		me._katmandonus.appendChild(me._cembergri2v);
		el=me._cemberkirmizi2v=document.createElement('div');
		el.ggId="CEMBER-KIRMIZI-2V";
		el.ggDx=0;
		el.ggDy=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:0.55,sy:0.55,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_rectangle ";
		el.ggType='rectangle';
		hs ='';
		hs+='border : 4px solid #3aa33b;';
		hs+='border-radius : 999px;';
		hs+='cursor : pointer;';
		hs+='height : 30px;';
		hs+='left : calc(50% - ((30px + 8px) / 2) + 0px);';
		hs+='position : absolute;';
		hs+='top : calc(50% - ((30px + 8px) / 2) + 0px);';
		hs+='visibility : inherit;';
		hs+='width : 30px;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		el.style.transform=parameterToTransform(el.ggParameter);
		me._cemberkirmizi2v.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return me.ggNodeId;
		}
		me._cemberkirmizi2v.logicBlock_scaling = function() {
			var newLogicStateScaling;
			if (
				((player.getVariableValue('ht_ani') == true))
			)
			{
				newLogicStateScaling = 0;
			}
			else {
				newLogicStateScaling = -1;
			}
			if (me._cemberkirmizi2v.ggCurrentLogicStateScaling != newLogicStateScaling) {
				me._cemberkirmizi2v.ggCurrentLogicStateScaling = newLogicStateScaling;
				me._cemberkirmizi2v.style.transition='transform 1000ms ease 0ms, opacity 1000ms ease 0ms';
				if (me._cemberkirmizi2v.ggCurrentLogicStateScaling == 0) {
					me._cemberkirmizi2v.ggParameter.sx = 0.24;
					me._cemberkirmizi2v.ggParameter.sy = 0.24;
					me._cemberkirmizi2v.style.transform=parameterToTransform(me._cemberkirmizi2v.ggParameter);
					setTimeout(function() {skin.updateSize(me._cemberkirmizi2v);}, 1050);
				}
				else {
					me._cemberkirmizi2v.ggParameter.sx = 0.55;
					me._cemberkirmizi2v.ggParameter.sy = 0.55;
					me._cemberkirmizi2v.style.transform=parameterToTransform(me._cemberkirmizi2v.ggParameter);
					setTimeout(function() {skin.updateSize(me._cemberkirmizi2v);}, 1050);
				}
			}
		}
		me._cemberkirmizi2v.logicBlock_scaling();
		me._cemberkirmizi2v.logicBlock_alpha = function() {
			var newLogicStateAlpha;
			if (
				((player.getVariableValue('ht_ani') == true))
			)
			{
				newLogicStateAlpha = 0;
			}
			else {
				newLogicStateAlpha = -1;
			}
			if (me._cemberkirmizi2v.ggCurrentLogicStateAlpha != newLogicStateAlpha) {
				me._cemberkirmizi2v.ggCurrentLogicStateAlpha = newLogicStateAlpha;
				me._cemberkirmizi2v.style.transition='transform 1000ms ease 0ms, opacity 1000ms ease 0ms';
				if (me._cemberkirmizi2v.ggCurrentLogicStateAlpha == 0) {
					setTimeout(function() { if (me._cemberkirmizi2v.style.opacity == 0.0) { me._cemberkirmizi2v.style.visibility="hidden"; } }, 1005);
					me._cemberkirmizi2v.style.opacity=0;
				}
				else {
					me._cemberkirmizi2v.style.visibility=me._cemberkirmizi2v.ggVisible?'inherit':'hidden';
					me._cemberkirmizi2v.style.opacity=1;
				}
			}
		}
		me._cemberkirmizi2v.logicBlock_alpha();
		me._cemberkirmizi2v.ggUpdatePosition=function (useTransition) {
		}
		me._katmandonus.appendChild(me._cemberkirmizi2v);
		el=me._cemberbeyaz2v=document.createElement('div');
		el.ggId="CEMBER-BEYAZ-2V";
		el.ggDx=0;
		el.ggDy=0;
		el.ggParameter={ rx:0,ry:0,a:0,sx:0.8,sy:0.8,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_rectangle ";
		el.ggType='rectangle';
		hs ='';
		hs+='border : 3px solid #83bb27;';
		hs+='border-radius : 999px;';
		hs+='cursor : pointer;';
		hs+='height : 40px;';
		hs+='left : calc(50% - ((40px + 6px) / 2) + 0px);';
		hs+='position : absolute;';
		hs+='top : calc(50% - ((40px + 6px) / 2) + 0px);';
		hs+='visibility : inherit;';
		hs+='width : 40px;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		el.style.transform=parameterToTransform(el.ggParameter);
		me._cemberbeyaz2v.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return me.ggNodeId;
		}
		me._cemberbeyaz2v.logicBlock_scaling = function() {
			var newLogicStateScaling;
			if (
				((player.getVariableValue('ht_ani') == true))
			)
			{
				newLogicStateScaling = 0;
			}
			else {
				newLogicStateScaling = -1;
			}
			if (me._cemberbeyaz2v.ggCurrentLogicStateScaling != newLogicStateScaling) {
				me._cemberbeyaz2v.ggCurrentLogicStateScaling = newLogicStateScaling;
				me._cemberbeyaz2v.style.transition='transform 1000ms ease 0ms, opacity 1000ms ease 0ms';
				if (me._cemberbeyaz2v.ggCurrentLogicStateScaling == 0) {
					me._cemberbeyaz2v.ggParameter.sx = 1;
					me._cemberbeyaz2v.ggParameter.sy = 1;
					me._cemberbeyaz2v.style.transform=parameterToTransform(me._cemberbeyaz2v.ggParameter);
					setTimeout(function() {skin.updateSize(me._cemberbeyaz2v);}, 1050);
				}
				else {
					me._cemberbeyaz2v.ggParameter.sx = 0.8;
					me._cemberbeyaz2v.ggParameter.sy = 0.8;
					me._cemberbeyaz2v.style.transform=parameterToTransform(me._cemberbeyaz2v.ggParameter);
					setTimeout(function() {skin.updateSize(me._cemberbeyaz2v);}, 1050);
				}
			}
		}
		me._cemberbeyaz2v.logicBlock_scaling();
		me._cemberbeyaz2v.logicBlock_alpha = function() {
			var newLogicStateAlpha;
			if (
				((player.getVariableValue('ht_ani') == true))
			)
			{
				newLogicStateAlpha = 0;
			}
			else {
				newLogicStateAlpha = -1;
			}
			if (me._cemberbeyaz2v.ggCurrentLogicStateAlpha != newLogicStateAlpha) {
				me._cemberbeyaz2v.ggCurrentLogicStateAlpha = newLogicStateAlpha;
				me._cemberbeyaz2v.style.transition='transform 1000ms ease 0ms, opacity 1000ms ease 0ms';
				if (me._cemberbeyaz2v.ggCurrentLogicStateAlpha == 0) {
					setTimeout(function() { if (me._cemberbeyaz2v.style.opacity == 0.0) { me._cemberbeyaz2v.style.visibility="hidden"; } }, 1005);
					me._cemberbeyaz2v.style.opacity=0;
				}
				else {
					me._cemberbeyaz2v.style.visibility=me._cemberbeyaz2v.ggVisible?'inherit':'hidden';
					me._cemberbeyaz2v.style.opacity=1;
				}
			}
		}
		me._cemberbeyaz2v.logicBlock_alpha();
		me._cemberbeyaz2v.ggUpdatePosition=function (useTransition) {
		}
		me._katmandonus.appendChild(me._cemberbeyaz2v);
		me._ht_node.appendChild(me._katmandonus);
		el=me._hedefarayuzu=document.createElement('div');
		el.ggId="HEDEF-ARAYUZU";
		el.ggDx=0;
		el.ggDy=-80;
		el.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1,def:'' };
		el.ggVisible=false;
		el.className="ggskin ggskin_container ";
		el.ggType='container';
		hs ='';
		hs+='z-index: 100;';
		hs+='cursor : pointer;';
		hs+='height : 32px;';
		hs+='left : calc(50% - ((50px + 0px) / 2) + 0px);';
		hs+='position : absolute;';
		hs+='top : calc(50% - ((32px + 0px) / 2) - 80px);';
		hs+='visibility : hidden;';
		hs+='width : 50px;';
		hs+='pointer-events:none;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		me._hedefarayuzu.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return me.ggNodeId;
		}
		me._hedefarayuzu.logicBlock_visible = function() {
			var newLogicStateVisible;
			if (
				((me.elementMouseOver['ht_node'] == true))
			)
			{
				newLogicStateVisible = 0;
			}
			else {
				newLogicStateVisible = -1;
			}
			if (me._hedefarayuzu.ggCurrentLogicStateVisible != newLogicStateVisible) {
				me._hedefarayuzu.ggCurrentLogicStateVisible = newLogicStateVisible;
				me._hedefarayuzu.style.transition='';
				if (me._hedefarayuzu.ggCurrentLogicStateVisible == 0) {
					me._hedefarayuzu.style.visibility=(Number(me._hedefarayuzu.style.opacity)>0||!me._hedefarayuzu.style.opacity)?'inherit':'hidden';
					me._hedefarayuzu.ggVisible=true;
				}
				else {
					me._hedefarayuzu.style.visibility="hidden";
					me._hedefarayuzu.ggVisible=false;
				}
			}
		}
		me._hedefarayuzu.logicBlock_visible();
		me._hedefarayuzu.ggUpdatePosition=function (useTransition) {
		}
		el=me._hedeftablo=document.createElement('div');
		el.ggId="HEDEF-TABLO";
		el.ggDx=0;
		el.ggDy=80;
		el.ggParameter={ rx:0,ry:0,a:0,sx:0.8,sy:0.8,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_rectangle ";
		el.ggType='rectangle';
		hs ='';
		hs+=cssPrefix + 'background-clip : padding-box;';
		hs+='background-clip : padding-box;';
		hs+='border : 3px solid rgba(255,0,4,0.588235);';
		hs+='border-radius : 999px;';
		hs+='cursor : pointer;';
		hs+='height : 60px;';
		hs+='left : calc(50% - ((60px + 6px) / 2) + 0px);';
		hs+='opacity : 0.5;';
		hs+='position : absolute;';
		hs+='top : calc(50% - ((60px + 6px) / 2) + 80px);';
		hs+='visibility : inherit;';
		hs+='width : 60px;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		el.style.transform=parameterToTransform(el.ggParameter);
		me._hedeftablo.ggIsActive=function() {
			if ((this.parentNode) && (this.parentNode.ggIsActive)) {
				return this.parentNode.ggIsActive();
			}
			return false;
		}
		el.ggElementNodeId=function() {
			if ((this.parentNode) && (this.parentNode.ggElementNodeId)) {
				return this.parentNode.ggElementNodeId();
			}
			return me.ggNodeId;
		}
		me._hedeftablo.logicBlock_scaling = function() {
			var newLogicStateScaling;
			if (
				((player.getVariableValue('ht_node_var') == true))
			)
			{
				newLogicStateScaling = 0;
			}
			else {
				newLogicStateScaling = -1;
			}
			if (me._hedeftablo.ggCurrentLogicStateScaling != newLogicStateScaling) {
				me._hedeftablo.ggCurrentLogicStateScaling = newLogicStateScaling;
				me._hedeftablo.style.transition='transform 500ms ease 0ms, opacity 200ms ease 0ms, background-color 0s';
				if (me._hedeftablo.ggCurrentLogicStateScaling == 0) {
					me._hedeftablo.ggParameter.sx = 1;
					me._hedeftablo.ggParameter.sy = 1;
					me._hedeftablo.style.transform=parameterToTransform(me._hedeftablo.ggParameter);
					setTimeout(function() {skin.updateSize(me._hedeftablo);}, 550);
				}
				else {
					me._hedeftablo.ggParameter.sx = 0.8;
					me._hedeftablo.ggParameter.sy = 0.8;
					me._hedeftablo.style.transform=parameterToTransform(me._hedeftablo.ggParameter);
					setTimeout(function() {skin.updateSize(me._hedeftablo);}, 550);
				}
			}
		}
		me._hedeftablo.logicBlock_scaling();
		me._hedeftablo.logicBlock_alpha = function() {
			var newLogicStateAlpha;
			if (
				((player.getVariableValue('ht_node_var') == true))
			)
			{
				newLogicStateAlpha = 0;
			}
			else {
				newLogicStateAlpha = -1;
			}
			if (me._hedeftablo.ggCurrentLogicStateAlpha != newLogicStateAlpha) {
				me._hedeftablo.ggCurrentLogicStateAlpha = newLogicStateAlpha;
				me._hedeftablo.style.transition='transform 500ms ease 0ms, opacity 200ms ease 0ms, background-color 0s';
				if (me._hedeftablo.ggCurrentLogicStateAlpha == 0) {
					me._hedeftablo.style.visibility=me._hedeftablo.ggVisible?'inherit':'hidden';
					me._hedeftablo.style.opacity=1;
				}
				else {
					me._hedeftablo.style.visibility=me._hedeftablo.ggVisible?'inherit':'hidden';
					me._hedeftablo.style.opacity=0.5;
				}
			}
		}
		me._hedeftablo.logicBlock_alpha();
		me._hedeftablo.logicBlock_backgroundcolor = function() {
			var newLogicStateBackgroundColor;
			if (
				((player.nodeVisited(me._hedeftablo.ggElementNodeId()) == true))
			)
			{
				newLogicStateBackgroundColor = 0;
			}
			else {
				newLogicStateBackgroundColor = -1;
			}
			if (me._hedeftablo.ggCurrentLogicStateBackgroundColor != newLogicStateBackgroundColor) {
				me._hedeftablo.ggCurrentLogicStateBackgroundColor = newLogicStateBackgroundColor;
				me._hedeftablo.style.transition='transform 500ms ease 0ms, opacity 200ms ease 0ms, background-color 0s';
				if (me._hedeftablo.ggCurrentLogicStateBackgroundColor == 0) {
					me._hedeftablo.style.backgroundColor="rgba(254,254,254,1)";
				}
				else {
					me._hedeftablo.style.backgroundColor="rgba(255,0,4,1)";
				}
			}
		}
		me._hedeftablo.logicBlock_backgroundcolor();
		me._hedeftablo.ggUpdatePosition=function (useTransition) {
		}
		me._hedefarayuzu.appendChild(me._hedeftablo);
		el=me._hedefarkaopak=document.createElement('div');
		els=me._hedefarkaopak__img=document.createElement('img');
		els.className='ggskin ggskin_nodeimage';
		if (nodeId) els.setAttribute('src',basePath + "images/hedefarkaopak_" + nodeId + ".png");
		el.ggNodeId=nodeId;
		hs ='';
		hs += 'position: absolute;top: 0px;left: 0px;width: 100%;height: 100%;-webkit-user-drag:none;pointer-events:none;;';
		els.setAttribute('style', hs);
		els.className='ggskin ggskin_nodeimage';
		els['ondragstart']=function() { return false; };
		el.appendChild(els);
		el.ggSubElement = els;
		el.ggId="HEDEF-ARKA-OPAK";
		el.ggDx=0;
		el.ggDy=80;
		el.ggParameter={ rx:0,ry:0,a:0,sx:0.8,sy:0.8,def:'' };
		el.ggVisible=true;
		el.className="ggskin ggskin_nodeimage ";
		el.ggType='nodeimage';
		hs ='';
		hs+='cursor : pointer;';
		hs+='height : 60px;';
		hs+='left : calc(50% - ((60px + 0px) / 2) + 0px);';
		hs+='opacity : 0.5;';
		hs+='position : absolute;';
		hs+='top : calc(50% - ((60px + 0px) / 2) + 80px);';
		hs+='visibility : inherit;';
		hs+='width : 60px;';
		hs+='pointer-events:auto;';
		el.setAttribute('style',hs);
		el.style.transformOrigin='50% 50%';
		el.style.transform=parameterToTransform(el.ggParameter);
		me._hedefarkaopak.ggIsActive=function() {
			return player.getCurrentNode()==this.ggElementNodeId();
		}
		el.ggElementNodeId=function() {
			return this.ggNodeId;
		}
		me._hedefarkaopak.logicBlock_scaling = function() {
			var newLogicStateScaling;
			if (
				((player.getVariableValue('ht_node_var') == true))
			)
			{
				newLogicStateScaling = 0;
			}
			else {
				newLogicStateScaling = -1;
			}
			if (me._hedefarkaopak.ggCurrentLogicStateScaling != newLogicStateScaling) {
				me._hedefarkaopak.ggCurrentLogicStateScaling = newLogicStateScaling;
				me._hedefarkaopak.style.transition='transform 500ms ease 0ms, opacity 200ms ease 0ms';
				if (me._hedefarkaopak.ggCurrentLogicStateScaling == 0) {
					me._hedefarkaopak.ggParameter.sx = 1;
					me._hedefarkaopak.ggParameter.sy = 1;
					me._hedefarkaopak.style.transform=parameterToTransform(me._hedefarkaopak.ggParameter);
					setTimeout(function() {skin.updateSize(me._hedefarkaopak);}, 550);
				}
				else {
					me._hedefarkaopak.ggParameter.sx = 0.8;
					me._hedefarkaopak.ggParameter.sy = 0.8;
					me._hedefarkaopak.style.transform=parameterToTransform(me._hedefarkaopak.ggParameter);
					setTimeout(function() {skin.updateSize(me._hedefarkaopak);}, 550);
				}
			}
		}
		me._hedefarkaopak.logicBlock_scaling();
		me._hedefarkaopak.logicBlock_alpha = function() {
			var newLogicStateAlpha;
			if (
				((player.getVariableValue('ht_node_var') == true))
			)
			{
				newLogicStateAlpha = 0;
			}
			else {
				newLogicStateAlpha = -1;
			}
			if (me._hedefarkaopak.ggCurrentLogicStateAlpha != newLogicStateAlpha) {
				me._hedefarkaopak.ggCurrentLogicStateAlpha = newLogicStateAlpha;
				me._hedefarkaopak.style.transition='transform 500ms ease 0ms, opacity 200ms ease 0ms';
				if (me._hedefarkaopak.ggCurrentLogicStateAlpha == 0) {
					me._hedefarkaopak.style.visibility=me._hedefarkaopak.ggVisible?'inherit':'hidden';
					me._hedefarkaopak.style.opacity=1;
				}
				else {
					me._hedefarkaopak.style.visibility=me._hedefarkaopak.ggVisible?'inherit':'hidden';
					me._hedefarkaopak.style.opacity=0.5;
				}
			}
		}
		me._hedefarkaopak.logicBlock_alpha();
		me._hedefarkaopak.ggUpdatePosition=function (useTransition) {
		}
		me._hedefarayuzu.appendChild(me._hedefarkaopak);
		me._ht_node.appendChild(me._hedefarayuzu);
		me.elementMouseOver['ht_node']=false;
		me._katmangidis.logicBlock_visible();
		me._cembergri.logicBlock_scaling();
		me._cembergri.logicBlock_alpha();
		me._cemberkirmizi.logicBlock_scaling();
		me._cemberkirmizi.logicBlock_alpha();
		me._cemberbeyaz.logicBlock_scaling();
		me._cemberbeyaz.logicBlock_alpha();
		me._katmandonus.logicBlock_visible();
		me._cembergri2v.logicBlock_scaling();
		me._cembergri2v.logicBlock_alpha();
		me._cemberkirmizi2v.logicBlock_scaling();
		me._cemberkirmizi2v.logicBlock_alpha();
		me._cemberbeyaz2v.logicBlock_scaling();
		me._cemberbeyaz2v.logicBlock_alpha();
		me._hedefarayuzu.logicBlock_visible();
		me._hedeftablo.logicBlock_scaling();
		me._hedeftablo.logicBlock_alpha();
		me._hedeftablo.logicBlock_backgroundcolor();
		me._hedefarkaopak.logicBlock_scaling();
		me._hedefarkaopak.logicBlock_alpha();
			me.ggEvent_changenode=function() {
				me._katmangidis.logicBlock_visible();
				me._cembergri.logicBlock_scaling();
				me._cembergri.logicBlock_alpha();
				me._cemberkirmizi.logicBlock_scaling();
				me._cemberkirmizi.logicBlock_alpha();
				me._cemberbeyaz.logicBlock_scaling();
				me._cemberbeyaz.logicBlock_alpha();
				me._katmandonus.logicBlock_visible();
				me._cembergri2v.logicBlock_scaling();
				me._cembergri2v.logicBlock_alpha();
				me._cemberkirmizi2v.logicBlock_scaling();
				me._cemberkirmizi2v.logicBlock_alpha();
				me._cemberbeyaz2v.logicBlock_scaling();
				me._cemberbeyaz2v.logicBlock_alpha();
				me._hedeftablo.logicBlock_scaling();
				me._hedeftablo.logicBlock_alpha();
				me._hedeftablo.logicBlock_backgroundcolor();
				me._hedefarkaopak.logicBlock_scaling();
				me._hedefarkaopak.logicBlock_alpha();
			};
			me.ggEvent_changevisitednodes=function() {
				me._katmangidis.logicBlock_visible();
				me._katmandonus.logicBlock_visible();
				me._hedeftablo.logicBlock_backgroundcolor();
			};
			me.ggEvent_configloaded=function() {
				me._cembergri.logicBlock_scaling();
				me._cembergri.logicBlock_alpha();
				me._cemberkirmizi.logicBlock_scaling();
				me._cemberkirmizi.logicBlock_alpha();
				me._cemberbeyaz.logicBlock_scaling();
				me._cemberbeyaz.logicBlock_alpha();
				me._cembergri2v.logicBlock_scaling();
				me._cembergri2v.logicBlock_alpha();
				me._cemberkirmizi2v.logicBlock_scaling();
				me._cemberkirmizi2v.logicBlock_alpha();
				me._cemberbeyaz2v.logicBlock_scaling();
				me._cemberbeyaz2v.logicBlock_alpha();
				me._hedeftablo.logicBlock_scaling();
				me._hedeftablo.logicBlock_alpha();
				me._hedefarkaopak.logicBlock_scaling();
				me._hedefarkaopak.logicBlock_alpha();
			};
			me.ggEvent_varchanged_ht_ani=function() {
				me._cembergri.logicBlock_scaling();
				me._cembergri.logicBlock_alpha();
				me._cemberkirmizi.logicBlock_scaling();
				me._cemberkirmizi.logicBlock_alpha();
				me._cemberbeyaz.logicBlock_scaling();
				me._cemberbeyaz.logicBlock_alpha();
				me._cembergri2v.logicBlock_scaling();
				me._cembergri2v.logicBlock_alpha();
				me._cemberkirmizi2v.logicBlock_scaling();
				me._cemberkirmizi2v.logicBlock_alpha();
				me._cemberbeyaz2v.logicBlock_scaling();
				me._cemberbeyaz2v.logicBlock_alpha();
			};
			me.ggEvent_varchanged_ht_node_var=function() {
				me._hedeftablo.logicBlock_scaling();
				me._hedeftablo.logicBlock_alpha();
				me._hedefarkaopak.logicBlock_scaling();
				me._hedefarkaopak.logicBlock_alpha();
			};
			me.__div = me._ht_node;
	};
	me.addSkinHotspot=function(hotspot) {
		var hsinst = null;
		{
				hotspot.skinid = 'ht_node';
				hsinst = new SkinHotspotClass_ht_node(me, hotspot);
			if (!hotspotTemplates.hasOwnProperty(hotspot.skinid)) {
				hotspotTemplates[hotspot.skinid] = [];
			}
			hotspotTemplates[hotspot.skinid].push(hsinst);
		}
		return hsinst;
	}
	me.removeSkinHotspots=function() {
		hotspotTemplates = {};
	}
	player.addListener('hotspotsremoved',function() {
			me.removeSkinHotspots();
	});
	player.addListener('changenode', function() {
		me.ggUserdata=player.userdata;
	});
	me.skinTimerEvent=function() {
		if (player.isInVR()) return;
		me.ggCurrentTime=new Date().getTime();
		if (me._node_hareket.ggLastIsActive!=me._node_hareket.ggIsActive()) {
			me._node_hareket.ggLastIsActive=me._node_hareket.ggIsActive();
			if (me._node_hareket.ggLastIsActive) {
				player.setVariableValue('ht_ani', true);
			} else {
				player.setVariableValue('ht_ani', false);
			}
		}
		me.__5.ggUpdateConditionTimer();
		me.__4.ggUpdateConditionTimer();
		me._zoomout.ggUpdateConditionTimer();
		me._zoomin.ggUpdateConditionTimer();
		if (!player.getLockedKeyboard()) {
			switch(me.skinKeyPressedText) {
			}
			switch(me.skinKeyPressedKey) {
				case 107:
					player.changeFovLog(-1,true);
					break;
				case 109:
					player.changeFovLog(1,true);
					break;
			}
		}
		for (const id in hotspotTemplates) {
			const tmpl=hotspotTemplates[id];
			tmpl.forEach(function(hotspot) {
				if (hotspot.hotspotTimerEvent) {
					hotspot.hotspotTimerEvent();
				}
			});
		};
	};
	player.addListener('timer', me.skinTimerEvent);
	me.addSkin();
	var style = document.createElement('style');
	style.type = 'text/css';
	style.appendChild(document.createTextNode('.ggskin { font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px;}'));
	document.head.appendChild(style);
	document.addEventListener('keydown', function(e) {
		var keyText = e.key;
		var keyCode = e.which || e.keyCode;
		me.skinKeyPressedKey = e.keyCode;
		me.skinKeyPressedText = e.key;
	});
	document.addEventListener('keyup', function(e) {
		var keyText = e.key;
		var keyCode = e.which || e.keyCode;
		me.skinKeyPressedKey = 0;
		me.skinKeyPressedText = '';
	});
	document.addEventListener('keyup', function(e) {
		if (e.key === 'Enter' || e.key === ' ') {
			let activeElement = document.activeElement;
			if (activeElement.classList.contains('ggskin') && activeElement.onclick) activeElement.onclick();
		}
	});
	document.addEventListener('keydown', function(e) {
		if (e.key === 'Enter' || e.key === ' ') {
			let activeElement = document.activeElement;
			if (activeElement.classList.contains('ggskin') && activeElement.onmousedown) activeElement.onmousedown();
		}
	});
	document.addEventListener('keyup', function(e) {
		if (e.key === 'Enter' || e.key === ' ') {
			let activeElement = document.activeElement;
			if (activeElement.classList.contains('ggskin') && activeElement.onmouseup) activeElement.onmouseup();
		}
	});
	me.skinTimerEvent();
	document.fonts.onloadingdone = () => {
		me.updateSize(me.divSkin);
	}
};